SET session_replication_role = 'replica';

--
-- PostgreSQL database dump
--

\restrict G0vmWqXIGidXA9bHOroSXrSpnp57sIBEDCKMZD74CW2vGmTl55rshjhGJOS6ixb

-- Dumped from database version 16.13 (Debian 16.13-1.pgdg13+1)
-- Dumped by pg_dump version 16.13 (Debian 16.13-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: se_users; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.se_users VALUES ('admin', '!!', 'en', '', false, true, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'admin@example.com', 2, '2026-06-27 18:41:53', '2026-06-27 18:41:53', 4, NULL, NULL);


--
-- Data for Name: ac_activities; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:39:12', '6a4018d06e80e5.74893111', NULL, 'tags', '27', NULL, NULL, 'cap-theorem', NULL, 'sulu.settings.tags', NULL, '27', 45, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:39:12', '6a4018d0702226.12730325', NULL, 'tags', '28', NULL, NULL, 'consistency', NULL, 'sulu.settings.tags', NULL, '28', 46, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:39:12', '6a4018d0705f68.50793235', NULL, 'tags', '29', NULL, NULL, 'availability', NULL, 'sulu.settings.tags', NULL, '29', 47, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:39:12', '6a4018d0709c33.00964781', NULL, 'tags', '30', NULL, NULL, 'partition-tolerance', NULL, 'sulu.settings.tags', NULL, '30', 48, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:39:12', '6a4018d070da16.90466223', NULL, 'tags', '31', NULL, NULL, 'event-driven', NULL, 'sulu.settings.tags', NULL, '31', 49, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:39:12', '6a4018d0710d46.38577112', NULL, 'tags', '32', NULL, NULL, 'event-sourcing', NULL, 'sulu.settings.tags', NULL, '32', 50, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:39:12', '6a4018d0714a66.07070390', NULL, 'tags', '33', NULL, NULL, 'microservices', NULL, 'sulu.settings.tags', NULL, '33', 51, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:39:12', '6a4018d0717ec8.34914158', NULL, 'tags', '34', NULL, NULL, 'saga', NULL, 'sulu.settings.tags', NULL, '34', 52, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:39:12', '6a4018d071afe0.63973334', NULL, 'tags', '35', NULL, NULL, 'outbox', NULL, 'sulu.settings.tags', NULL, '35', 53, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:39:12', '6a4018d071e312.56106039', NULL, 'tags', '36', NULL, NULL, 'cqrs', NULL, 'sulu.settings.tags', NULL, '36', 54, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:39:12', '6a4018d0722439.06071884', NULL, 'tags', '37', NULL, NULL, 'monolith', NULL, 'sulu.settings.tags', NULL, '37', 55, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:39:12', '6a4018d0725cb4.19340901', NULL, 'tags', '38', NULL, NULL, 'distributed-systems', NULL, 'sulu.settings.tags', NULL, '38', 56, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:39:12', '6a4018d07294e7.85161548', NULL, 'tags', '39', NULL, NULL, 'ddd', NULL, 'sulu.settings.tags', NULL, '39', 57, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:39:12', '6a4018d072c8b2.49317857', NULL, 'tags', '40', NULL, NULL, 'aggregates', NULL, 'sulu.settings.tags', NULL, '40', 58, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:39:12', '6a4018d072f917.56124281', NULL, 'tags', '41', NULL, NULL, 'bounded-context', NULL, 'sulu.settings.tags', NULL, '41', 59, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:39:12', '6a4018d0733466.09491115', NULL, 'tags', '42', NULL, NULL, 'value-objects', NULL, 'sulu.settings.tags', NULL, '42', 60, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:39:12', '6a4018d0737026.85275504', NULL, 'tags', '43', NULL, NULL, 'design-patterns', NULL, 'sulu.settings.tags', NULL, '43', 61, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:39:12', '6a4018d073a947.93427944', NULL, 'tags', '44', NULL, NULL, 'hexagonal', NULL, 'sulu.settings.tags', NULL, '44', 62, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:39:12', '6a4018d0740f86.44398809', NULL, 'tags', '45', NULL, NULL, 'clean-architecture', NULL, 'sulu.settings.tags', NULL, '45', 63, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:39:12', '6a4018d0744b09.98810777', NULL, 'tags', '46', NULL, NULL, 'circuit-breaker', NULL, 'sulu.settings.tags', NULL, '46', 64, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:39:12', '6a4018d0748745.58557565', NULL, 'tags', '47', NULL, NULL, 'repository-pattern', NULL, 'sulu.settings.tags', NULL, '47', 65, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:39:12', '6a4018d074c686.61430561', NULL, 'tags', '48', NULL, NULL, 'factory-pattern', NULL, 'sulu.settings.tags', NULL, '48', 66, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:39:12', '6a4018d07500e6.42737434', NULL, 'tags', '49', NULL, NULL, 'strategy-pattern', NULL, 'sulu.settings.tags', NULL, '49', 67, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:39:12', '6a4018d0753945.56102421', NULL, 'tags', '50', NULL, NULL, 'observer-pattern', NULL, 'sulu.settings.tags', NULL, '50', 68, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:39:12', '6a4018d0756eb6.07627064', NULL, 'tags', '51', NULL, NULL, 'dependency-injection', NULL, 'sulu.settings.tags', NULL, '51', 69, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:39:12', '6a4018d075a858.06396609', NULL, 'tags', '52', NULL, NULL, 'api-gateway', NULL, 'sulu.settings.tags', NULL, '52', 70, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:39:12', '6a4018d079e3c0.35381727', NULL, 'categories', '6', 'en', NULL, 'Distributed Systems', 'en', 'sulu.settings.categories', NULL, '6', 71, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:39:12', '6a4018d09b2a76.17037242', NULL, 'categories', '7', 'en', NULL, 'Design Patterns', 'en', 'sulu.settings.categories', NULL, '7', 72, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:39:12', '6a4018d09d34b4.01223687', NULL, 'categories', '8', 'en', NULL, 'Domain-Driven Design', 'en', 'sulu.settings.categories', NULL, '8', 73, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:39:12', '6a4018d09f55d1.02374371', NULL, 'categories', '9', 'en', NULL, 'Architecture Styles', 'en', 'sulu.settings.categories', NULL, '9', 74, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:39:12', '6a4018d0a11b54.48455952', NULL, 'categories', '10', 'en', NULL, 'Messaging Patterns', 'en', 'sulu.settings.categories', NULL, '10', 75, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:41:53', '6a401971f01cc9.80268959', NULL, 'collections', '7', 'en', NULL, 'System', 'en', 'sulu.media.collections', 'Sulu\Bundle\MediaBundle\Entity\Collection', '7', 76, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:41:54', '6a4019721e94f1.42845749', NULL, 'collections', '8', 'en', NULL, 'Sulu media', 'en', 'sulu.media.collections', 'Sulu\Bundle\MediaBundle\Entity\Collection', '8', 77, NULL);
INSERT INTO public.ac_activities VALUES ('translation_added', '[]', '2026-06-27 18:41:54', '6a401972239807.17500964', NULL, 'collections', '8', 'de', NULL, 'Sulu Medien', 'de', 'sulu.media.collections', 'Sulu\Bundle\MediaBundle\Entity\Collection', '8', 78, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:41:54', '6a4019722696d5.11486620', NULL, 'collections', '9', 'en', NULL, 'Preview images', 'en', 'sulu.media.collections', 'Sulu\Bundle\MediaBundle\Entity\Collection', '9', 79, NULL);
INSERT INTO public.ac_activities VALUES ('translation_added', '[]', '2026-06-27 18:41:54', '6a4019722d57f6.27882020', NULL, 'collections', '9', 'de', NULL, 'Vorschaubilder', 'de', 'sulu.media.collections', 'Sulu\Bundle\MediaBundle\Entity\Collection', '9', 80, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:41:54', '6a4019722f1260.51458504', NULL, 'collections', '10', 'en', NULL, 'Sulu contacts', 'en', 'sulu.media.collections', 'Sulu\Bundle\MediaBundle\Entity\Collection', '10', 81, NULL);
INSERT INTO public.ac_activities VALUES ('translation_added', '[]', '2026-06-27 18:41:54', '6a40197233e6d9.60416011', NULL, 'collections', '10', 'de', NULL, 'Sulu Kontakte', 'de', 'sulu.media.collections', 'Sulu\Bundle\MediaBundle\Entity\Collection', '10', 82, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:41:54', '6a401972369b79.78266396', NULL, 'collections', '11', 'en', NULL, 'People', 'en', 'sulu.media.collections', 'Sulu\Bundle\MediaBundle\Entity\Collection', '11', 83, NULL);
INSERT INTO public.ac_activities VALUES ('translation_added', '[]', '2026-06-27 18:41:54', '6a4019723e68e0.25461622', NULL, 'collections', '11', 'de', NULL, 'Personen', 'de', 'sulu.media.collections', 'Sulu\Bundle\MediaBundle\Entity\Collection', '11', 84, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:41:54', '6a401972425835.10924126', NULL, 'collections', '12', 'en', NULL, 'Organizations', 'en', 'sulu.media.collections', 'Sulu\Bundle\MediaBundle\Entity\Collection', '12', 85, NULL);
INSERT INTO public.ac_activities VALUES ('translation_added', '[]', '2026-06-27 18:41:54', '6a40197248b656.35396691', NULL, 'collections', '12', 'de', NULL, 'Organisationen', 'de', 'sulu.media.collections', 'Sulu\Bundle\MediaBundle\Entity\Collection', '12', 86, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:41:54', '6a4019725a1039.51815319', NULL, 'pages', '019f0a63-6686-71f2-a8c9-b4e7f0c6ff6e', 'en', 'architecture-hub', 'Architecture Hub', 'en', 'sulu.webspaces.architecture-hub', NULL, '019f0a63-6686-71f2-a8c9-b4e7f0c6ff6e', 87, NULL);
INSERT INTO public.ac_activities VALUES ('workflow_transition.publish', '[]', '2026-06-27 18:41:54', '6a4019726122b5.61966051', NULL, 'pages', '019f0a63-6686-71f2-a8c9-b4e7f0c6ff6e', 'en', 'architecture-hub', 'Architecture Hub', 'en', 'sulu.webspaces.architecture-hub', NULL, '019f0a63-6686-71f2-a8c9-b4e7f0c6ff6e', 88, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:42:00', '6a40197851f4e3.34691888', NULL, 'articles', '019f0a63-7da5-7277-98ce-4c75280acfbf', 'en', NULL, 'Understanding the CAP Theorem', 'en', 'sulu.article.articles', NULL, '019f0a63-7da5-7277-98ce-4c75280acfbf', 89, NULL);
INSERT INTO public.ac_activities VALUES ('workflow_transition.publish', '[]', '2026-06-27 18:42:00', '6a401978741454.93875061', NULL, 'articles', '019f0a63-7da5-7277-98ce-4c75280acfbf', 'en', NULL, 'Understanding the CAP Theorem', 'en', 'sulu.article.articles', NULL, '019f0a63-7da5-7277-98ce-4c75280acfbf', 90, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:42:00', '6a4019787f6283.89555819', NULL, 'articles', '019f0a63-7ec1-797f-9a50-9fd0ee001098', 'en', NULL, 'Eventual Consistency in Practice', 'en', 'sulu.article.articles', NULL, '019f0a63-7ec1-797f-9a50-9fd0ee001098', 91, NULL);
INSERT INTO public.ac_activities VALUES ('workflow_transition.publish', '[]', '2026-06-27 18:42:00', '6a401978841366.25767973', NULL, 'articles', '019f0a63-7ec1-797f-9a50-9fd0ee001098', 'en', NULL, 'Eventual Consistency in Practice', 'en', 'sulu.article.articles', NULL, '019f0a63-7ec1-797f-9a50-9fd0ee001098', 92, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:42:00', '6a401978899397.51882549', NULL, 'articles', '019f0a63-7eec-7e3e-922e-19b253d0ba27', 'en', NULL, 'Domain-Driven Design: Strategic Patterns', 'en', 'sulu.article.articles', NULL, '019f0a63-7eec-7e3e-922e-19b253d0ba27', 93, NULL);
INSERT INTO public.ac_activities VALUES ('workflow_transition.publish', '[]', '2026-06-27 18:42:00', '6a4019788d4b33.38207087', NULL, 'articles', '019f0a63-7eec-7e3e-922e-19b253d0ba27', 'en', NULL, 'Domain-Driven Design: Strategic Patterns', 'en', 'sulu.article.articles', NULL, '019f0a63-7eec-7e3e-922e-19b253d0ba27', 94, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:42:00', '6a401978932ff6.73293670', NULL, 'articles', '019f0a63-7f13-76a6-9820-09063579be68', 'en', NULL, 'Domain-Driven Design: Aggregates & Invariants', 'en', 'sulu.article.articles', NULL, '019f0a63-7f13-76a6-9820-09063579be68', 95, NULL);
INSERT INTO public.ac_activities VALUES ('workflow_transition.publish', '[]', '2026-06-27 18:42:00', '6a401978970d62.59198180', NULL, 'articles', '019f0a63-7f13-76a6-9820-09063579be68', 'en', NULL, 'Domain-Driven Design: Aggregates & Invariants', 'en', 'sulu.article.articles', NULL, '019f0a63-7f13-76a6-9820-09063579be68', 96, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:42:00', '6a4019789ce9a4.35127178', NULL, 'articles', '019f0a63-7f3b-7053-816a-4e409ce7fff1', 'en', NULL, 'Value Objects in Domain-Driven Design', 'en', 'sulu.article.articles', NULL, '019f0a63-7f3b-7053-816a-4e409ce7fff1', 97, NULL);
INSERT INTO public.ac_activities VALUES ('workflow_transition.publish', '[]', '2026-06-27 18:42:00', '6a401978a0cbc3.30212849', NULL, 'articles', '019f0a63-7f3b-7053-816a-4e409ce7fff1', 'en', NULL, 'Value Objects in Domain-Driven Design', 'en', 'sulu.article.articles', NULL, '019f0a63-7f3b-7053-816a-4e409ce7fff1', 98, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:42:00', '6a401978a68440.03107078', NULL, 'articles', '019f0a63-7f62-72e1-8f42-8c89ac4ed8c8', 'en', NULL, 'CQRS: Command Query Responsibility Segregation', 'en', 'sulu.article.articles', NULL, '019f0a63-7f62-72e1-8f42-8c89ac4ed8c8', 99, NULL);
INSERT INTO public.ac_activities VALUES ('workflow_transition.publish', '[]', '2026-06-27 18:42:00', '6a401978aa55f0.53317687', NULL, 'articles', '019f0a63-7f62-72e1-8f42-8c89ac4ed8c8', 'en', NULL, 'CQRS: Command Query Responsibility Segregation', 'en', 'sulu.article.articles', NULL, '019f0a63-7f62-72e1-8f42-8c89ac4ed8c8', 100, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:42:00', '6a401978b07490.29506651', NULL, 'articles', '019f0a63-7f89-7c70-83fa-c4d99f423e05', 'en', NULL, 'Event Sourcing: Storing State as a Sequence of Events', 'en', 'sulu.article.articles', NULL, '019f0a63-7f89-7c70-83fa-c4d99f423e05', 101, NULL);
INSERT INTO public.ac_activities VALUES ('workflow_transition.publish', '[]', '2026-06-27 18:42:00', '6a401978b59cc5.36609772', NULL, 'articles', '019f0a63-7f89-7c70-83fa-c4d99f423e05', 'en', NULL, 'Event Sourcing: Storing State as a Sequence of Events', 'en', 'sulu.article.articles', NULL, '019f0a63-7f89-7c70-83fa-c4d99f423e05', 102, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:42:00', '6a401978bc9452.03440376', NULL, 'articles', '019f0a63-7fba-7c70-b040-3e7e9ce94909', 'en', NULL, 'Microservices Architecture: Promises & Pitfalls', 'en', 'sulu.article.articles', NULL, '019f0a63-7fba-7c70-b040-3e7e9ce94909', 103, NULL);
INSERT INTO public.ac_activities VALUES ('workflow_transition.publish', '[]', '2026-06-27 18:42:00', '6a401978c11037.98425011', NULL, 'articles', '019f0a63-7fba-7c70-b040-3e7e9ce94909', 'en', NULL, 'Microservices Architecture: Promises & Pitfalls', 'en', 'sulu.article.articles', NULL, '019f0a63-7fba-7c70-b040-3e7e9ce94909', 104, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:42:00', '6a401978c755e7.60590677', NULL, 'articles', '019f0a63-7fe7-7f84-9b23-0603fcc7155e', 'en', NULL, 'Hexagonal Architecture: Ports and Adapters', 'en', 'sulu.article.articles', NULL, '019f0a63-7fe7-7f84-9b23-0603fcc7155e', 105, NULL);
INSERT INTO public.ac_activities VALUES ('workflow_transition.publish', '[]', '2026-06-27 18:42:00', '6a401978cb20a8.15743013', NULL, 'articles', '019f0a63-7fe7-7f84-9b23-0603fcc7155e', 'en', NULL, 'Hexagonal Architecture: Ports and Adapters', 'en', 'sulu.article.articles', NULL, '019f0a63-7fe7-7f84-9b23-0603fcc7155e', 106, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:42:00', '6a401978d19651.43751357', NULL, 'articles', '019f0a63-8011-7c5b-9a45-6195911b5536', 'en', NULL, 'Clean Architecture: The Dependency Rule', 'en', 'sulu.article.articles', NULL, '019f0a63-8011-7c5b-9a45-6195911b5536', 107, NULL);
INSERT INTO public.ac_activities VALUES ('workflow_transition.publish', '[]', '2026-06-27 18:42:00', '6a401978d5aa70.57339054', NULL, 'articles', '019f0a63-8011-7c5b-9a45-6195911b5536', 'en', NULL, 'Clean Architecture: The Dependency Rule', 'en', 'sulu.article.articles', NULL, '019f0a63-8011-7c5b-9a45-6195911b5536', 108, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:42:00', '6a401978dc5c37.41252090', NULL, 'articles', '019f0a63-803d-758c-a68a-55f5ee38d8b5', 'en', NULL, 'Monolith vs Microservices: When to Split', 'en', 'sulu.article.articles', NULL, '019f0a63-803d-758c-a68a-55f5ee38d8b5', 109, NULL);
INSERT INTO public.ac_activities VALUES ('workflow_transition.publish', '[]', '2026-06-27 18:42:00', '6a401978e0a6d5.73344680', NULL, 'articles', '019f0a63-803d-758c-a68a-55f5ee38d8b5', 'en', NULL, 'Monolith vs Microservices: When to Split', 'en', 'sulu.article.articles', NULL, '019f0a63-803d-758c-a68a-55f5ee38d8b5', 110, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:42:00', '6a401978e78fc3.87877773', NULL, 'articles', '019f0a63-806b-75d3-9bb4-31d0fdf95812', 'en', NULL, 'The API Gateway Pattern', 'en', 'sulu.article.articles', NULL, '019f0a63-806b-75d3-9bb4-31d0fdf95812', 111, NULL);
INSERT INTO public.ac_activities VALUES ('workflow_transition.publish', '[]', '2026-06-27 18:42:00', '6a401978ec86a0.54073577', NULL, 'articles', '019f0a63-806b-75d3-9bb4-31d0fdf95812', 'en', NULL, 'The API Gateway Pattern', 'en', 'sulu.article.articles', NULL, '019f0a63-806b-75d3-9bb4-31d0fdf95812', 112, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:42:01', '6a40197902d5b8.70736983', NULL, 'articles', '019f0a63-80a8-73fa-ad9e-30557ace8490', 'en', NULL, 'The Saga Pattern: Distributed Transactions Without 2PC', 'en', 'sulu.article.articles', NULL, '019f0a63-80a8-73fa-ad9e-30557ace8490', 113, NULL);
INSERT INTO public.ac_activities VALUES ('workflow_transition.publish', '[]', '2026-06-27 18:42:01', '6a401979081e47.31363668', NULL, 'articles', '019f0a63-80a8-73fa-ad9e-30557ace8490', 'en', NULL, 'The Saga Pattern: Distributed Transactions Without 2PC', 'en', 'sulu.article.articles', NULL, '019f0a63-80a8-73fa-ad9e-30557ace8490', 114, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:42:01', '6a401979137f54.89236474', NULL, 'articles', '019f0a63-80e4-7806-83b8-8991df317fa6', 'en', NULL, 'The Circuit Breaker Pattern', 'en', 'sulu.article.articles', NULL, '019f0a63-80e4-7806-83b8-8991df317fa6', 115, NULL);
INSERT INTO public.ac_activities VALUES ('workflow_transition.publish', '[]', '2026-06-27 18:42:01', '6a401979187ce9.21218567', NULL, 'articles', '019f0a63-80e4-7806-83b8-8991df317fa6', 'en', NULL, 'The Circuit Breaker Pattern', 'en', 'sulu.article.articles', NULL, '019f0a63-80e4-7806-83b8-8991df317fa6', 116, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:42:01', '6a4019791fbdb9.80344335', NULL, 'articles', '019f0a63-811e-7863-bee3-31d130b66430', 'en', NULL, 'The Outbox Pattern for Reliable Messaging', 'en', 'sulu.article.articles', NULL, '019f0a63-811e-7863-bee3-31d130b66430', 117, NULL);
INSERT INTO public.ac_activities VALUES ('workflow_transition.publish', '[]', '2026-06-27 18:42:01', '6a4019792490e3.52668610', NULL, 'articles', '019f0a63-811e-7863-bee3-31d130b66430', 'en', NULL, 'The Outbox Pattern for Reliable Messaging', 'en', 'sulu.article.articles', NULL, '019f0a63-811e-7863-bee3-31d130b66430', 118, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:42:01', '6a4019792c0cf0.08447565', NULL, 'articles', '019f0a63-8150-7804-9c6f-f6c154f95cd1', 'en', NULL, 'The Repository Pattern', 'en', 'sulu.article.articles', NULL, '019f0a63-8150-7804-9c6f-f6c154f95cd1', 119, NULL);
INSERT INTO public.ac_activities VALUES ('workflow_transition.publish', '[]', '2026-06-27 18:42:01', '6a40197930bce1.04688244', NULL, 'articles', '019f0a63-8150-7804-9c6f-f6c154f95cd1', 'en', NULL, 'The Repository Pattern', 'en', 'sulu.article.articles', NULL, '019f0a63-8150-7804-9c6f-f6c154f95cd1', 120, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:42:01', '6a401979382e10.75008280', NULL, 'articles', '019f0a63-8184-76a6-979c-4683b7807a4f', 'en', NULL, 'The Factory Pattern: Centralising Object Creation', 'en', 'sulu.article.articles', NULL, '019f0a63-8184-76a6-979c-4683b7807a4f', 121, NULL);
INSERT INTO public.ac_activities VALUES ('workflow_transition.publish', '[]', '2026-06-27 18:42:01', '6a4019793c5bc2.39078028', NULL, 'articles', '019f0a63-8184-76a6-979c-4683b7807a4f', 'en', NULL, 'The Factory Pattern: Centralising Object Creation', 'en', 'sulu.article.articles', NULL, '019f0a63-8184-76a6-979c-4683b7807a4f', 122, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:42:01', '6a401979431bc6.01075530', NULL, 'articles', '019f0a63-81b0-7060-8257-0ddd2bb95a71', 'en', NULL, 'The Strategy Pattern: Encapsulating Algorithms', 'en', 'sulu.article.articles', NULL, '019f0a63-81b0-7060-8257-0ddd2bb95a71', 123, NULL);
INSERT INTO public.ac_activities VALUES ('workflow_transition.publish', '[]', '2026-06-27 18:42:01', '6a401979477499.45348205', NULL, 'articles', '019f0a63-81b0-7060-8257-0ddd2bb95a71', 'en', NULL, 'The Strategy Pattern: Encapsulating Algorithms', 'en', 'sulu.article.articles', NULL, '019f0a63-81b0-7060-8257-0ddd2bb95a71', 124, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:42:01', '6a4019794e2fe9.97467281', NULL, 'articles', '019f0a63-81dc-7e9b-9d96-64555bce8199', 'en', NULL, 'The Observer Pattern and Event-Driven Design', 'en', 'sulu.article.articles', NULL, '019f0a63-81dc-7e9b-9d96-64555bce8199', 125, NULL);
INSERT INTO public.ac_activities VALUES ('workflow_transition.publish', '[]', '2026-06-27 18:42:01', '6a40197952caf3.36944372', NULL, 'articles', '019f0a63-81dc-7e9b-9d96-64555bce8199', 'en', NULL, 'The Observer Pattern and Event-Driven Design', 'en', 'sulu.article.articles', NULL, '019f0a63-81dc-7e9b-9d96-64555bce8199', 126, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:42:01', '6a40197959e904.73713422', NULL, 'articles', '019f0a63-820c-7902-9100-98c04b1f89bd', 'en', NULL, 'Dependency Injection and IoC Containers', 'en', 'sulu.article.articles', NULL, '019f0a63-820c-7902-9100-98c04b1f89bd', 127, NULL);
INSERT INTO public.ac_activities VALUES ('workflow_transition.publish', '[]', '2026-06-27 18:42:01', '6a4019795e8e53.24345236', NULL, 'articles', '019f0a63-820c-7902-9100-98c04b1f89bd', 'en', NULL, 'Dependency Injection and IoC Containers', 'en', 'sulu.article.articles', NULL, '019f0a63-820c-7902-9100-98c04b1f89bd', 128, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:42:01', '6a401979669688.06357432', NULL, 'pages', '019f0a63-823f-7d92-94b7-223065cae0d8', 'en', 'architecture-hub', 'Adam Ministrator', 'en', 'sulu.webspaces.architecture-hub', NULL, '019f0a63-823f-7d92-94b7-223065cae0d8', 129, NULL);
INSERT INTO public.ac_activities VALUES ('workflow_transition.publish', '[]', '2026-06-27 18:42:01', '6a4019796b7244.79301193', NULL, 'pages', '019f0a63-823f-7d92-94b7-223065cae0d8', 'en', 'architecture-hub', 'Adam Ministrator', 'en', 'sulu.webspaces.architecture-hub', NULL, '019f0a63-823f-7d92-94b7-223065cae0d8', 130, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:42:01', '6a4019796fcdd1.23811754', NULL, 'pages', '019f0a63-826d-77e6-adcf-e37b657311ed', 'en', 'architecture-hub', 'Jane Kowalski', 'en', 'sulu.webspaces.architecture-hub', NULL, '019f0a63-826d-77e6-adcf-e37b657311ed', 131, NULL);
INSERT INTO public.ac_activities VALUES ('workflow_transition.publish', '[]', '2026-06-27 18:42:01', '6a401979730501.76161313', NULL, 'pages', '019f0a63-826d-77e6-adcf-e37b657311ed', 'en', 'architecture-hub', 'Jane Kowalski', 'en', 'sulu.webspaces.architecture-hub', NULL, '019f0a63-826d-77e6-adcf-e37b657311ed', 132, NULL);
INSERT INTO public.ac_activities VALUES ('modified', '[]', '2026-06-27 18:45:07', '6a401a33a35866.79030461', NULL, 'pages', '019f0a63-823f-7d92-94b7-223065cae0d8', 'en', 'architecture-hub', 'Adam Ministrator', 'en', 'sulu.webspaces.architecture-hub', NULL, '019f0a63-823f-7d92-94b7-223065cae0d8', 133, NULL);
INSERT INTO public.ac_activities VALUES ('workflow_transition.publish', '[]', '2026-06-27 18:45:07', '6a401a33d892c6.97647539', NULL, 'pages', '019f0a63-823f-7d92-94b7-223065cae0d8', 'en', 'architecture-hub', 'Adam Ministrator', 'en', 'sulu.webspaces.architecture-hub', NULL, '019f0a63-823f-7d92-94b7-223065cae0d8', 134, NULL);
INSERT INTO public.ac_activities VALUES ('modified', '[]', '2026-06-27 18:45:07', '6a401a33e44ed4.10086809', NULL, 'pages', '019f0a63-826d-77e6-adcf-e37b657311ed', 'en', 'architecture-hub', 'Jane Kowalski', 'en', 'sulu.webspaces.architecture-hub', NULL, '019f0a63-826d-77e6-adcf-e37b657311ed', 135, NULL);
INSERT INTO public.ac_activities VALUES ('workflow_transition.publish', '[]', '2026-06-27 18:45:07', '6a401a33e998f0.74942682', NULL, 'pages', '019f0a63-826d-77e6-adcf-e37b657311ed', 'en', 'architecture-hub', 'Jane Kowalski', 'en', 'sulu.webspaces.architecture-hub', NULL, '019f0a63-826d-77e6-adcf-e37b657311ed', 136, NULL);
INSERT INTO public.ac_activities VALUES ('modified', '[]', '2026-06-27 18:57:47', '6a401d2ba3da63.86714030', NULL, 'pages', '019f0a63-826d-77e6-adcf-e37b657311ed', 'en', 'architecture-hub', 'Jane Kowalski', 'en', 'sulu.webspaces.architecture-hub', NULL, '019f0a63-826d-77e6-adcf-e37b657311ed', 137, NULL);
INSERT INTO public.ac_activities VALUES ('workflow_transition.publish', '[]', '2026-06-27 18:57:48', '6a401d2c18f1a7.58433843', NULL, 'pages', '019f0a63-826d-77e6-adcf-e37b657311ed', 'en', 'architecture-hub', 'Jane Kowalski', 'en', 'sulu.webspaces.architecture-hub', NULL, '019f0a63-826d-77e6-adcf-e37b657311ed', 138, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 18:57:48', '6a401d2c4992b3.20992426', NULL, 'pages', '019f0a71-f47f-7c8e-9018-5bfe524ddb81', 'en', 'architecture-hub', 'Authors', 'en', 'sulu.webspaces.architecture-hub', NULL, '019f0a71-f47f-7c8e-9018-5bfe524ddb81', 139, NULL);
INSERT INTO public.ac_activities VALUES ('workflow_transition.publish', '[]', '2026-06-27 18:57:48', '6a401d2c55cf93.67186624', NULL, 'pages', '019f0a71-f47f-7c8e-9018-5bfe524ddb81', 'en', 'architecture-hub', 'Authors', 'en', 'sulu.webspaces.architecture-hub', NULL, '019f0a71-f47f-7c8e-9018-5bfe524ddb81', 140, NULL);
INSERT INTO public.ac_activities VALUES ('modified', '[]', '2026-06-27 19:35:39', '6a40260b20b332.62181553', NULL, 'pages', '019f0a63-826d-77e6-adcf-e37b657311ed', 'en', 'architecture-hub', 'Jane Kowalski', 'en', 'sulu.webspaces.architecture-hub', NULL, '019f0a63-826d-77e6-adcf-e37b657311ed', 141, NULL);
INSERT INTO public.ac_activities VALUES ('workflow_transition.publish', '[]', '2026-06-27 19:35:39', '6a40260b801f80.61455286', NULL, 'pages', '019f0a63-826d-77e6-adcf-e37b657311ed', 'en', 'architecture-hub', 'Jane Kowalski', 'en', 'sulu.webspaces.architecture-hub', NULL, '019f0a63-826d-77e6-adcf-e37b657311ed', 142, NULL);
INSERT INTO public.ac_activities VALUES ('modified', '[]', '2026-06-27 19:35:39', '6a40260b8d90b4.05388846', NULL, 'pages', '019f0a71-f47f-7c8e-9018-5bfe524ddb81', 'en', 'architecture-hub', 'Authors', 'en', 'sulu.webspaces.architecture-hub', NULL, '019f0a71-f47f-7c8e-9018-5bfe524ddb81', 143, NULL);
INSERT INTO public.ac_activities VALUES ('workflow_transition.publish', '[]', '2026-06-27 19:35:39', '6a40260b91e0d9.22056278', NULL, 'pages', '019f0a71-f47f-7c8e-9018-5bfe524ddb81', 'en', 'architecture-hub', 'Authors', 'en', 'sulu.webspaces.architecture-hub', NULL, '019f0a71-f47f-7c8e-9018-5bfe524ddb81', 144, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 19:35:39', '6a40260b96a0e8.57351644', NULL, 'pages', '019f0a94-9d57-7cad-b9d7-fb66234cc944', 'en', 'architecture-hub', 'Distributed Systems Fundamentals', 'en', 'sulu.webspaces.architecture-hub', NULL, '019f0a94-9d57-7cad-b9d7-fb66234cc944', 145, NULL);
INSERT INTO public.ac_activities VALUES ('workflow_transition.publish', '[]', '2026-06-27 19:35:39', '6a40260b9b7aa6.36141885', NULL, 'pages', '019f0a94-9d57-7cad-b9d7-fb66234cc944', 'en', 'architecture-hub', 'Distributed Systems Fundamentals', 'en', 'sulu.webspaces.architecture-hub', NULL, '019f0a94-9d57-7cad-b9d7-fb66234cc944', 146, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 19:35:39', '6a40260ba11ce3.62685466', NULL, 'pages', '019f0a94-9d85-74e2-9529-c565160fb66d', 'en', 'architecture-hub', 'Domain-Driven Design', 'en', 'sulu.webspaces.architecture-hub', NULL, '019f0a94-9d85-74e2-9529-c565160fb66d', 147, NULL);
INSERT INTO public.ac_activities VALUES ('workflow_transition.publish', '[]', '2026-06-27 19:35:39', '6a40260ba54ee3.50592244', NULL, 'pages', '019f0a94-9d85-74e2-9529-c565160fb66d', 'en', 'architecture-hub', 'Domain-Driven Design', 'en', 'sulu.webspaces.architecture-hub', NULL, '019f0a94-9d85-74e2-9529-c565160fb66d', 148, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 19:35:39', '6a40260bab7608.69944574', NULL, 'pages', '019f0a94-9daf-7dc1-b7cd-8354981cfe04', 'en', 'architecture-hub', 'Architecture Patterns', 'en', 'sulu.webspaces.architecture-hub', NULL, '019f0a94-9daf-7dc1-b7cd-8354981cfe04', 149, NULL);
INSERT INTO public.ac_activities VALUES ('workflow_transition.publish', '[]', '2026-06-27 19:35:39', '6a40260baf7111.16791702', NULL, 'pages', '019f0a94-9daf-7dc1-b7cd-8354981cfe04', 'en', 'architecture-hub', 'Architecture Patterns', 'en', 'sulu.webspaces.architecture-hub', NULL, '019f0a94-9daf-7dc1-b7cd-8354981cfe04', 150, NULL);
INSERT INTO public.ac_activities VALUES ('created', '[]', '2026-06-27 19:35:39', '6a40260bb50ca4.70029206', NULL, 'pages', '019f0a94-9dd7-7c35-935d-5f56d43baf7e', 'en', 'architecture-hub', 'Learning Paths', 'en', 'sulu.webspaces.architecture-hub', NULL, '019f0a94-9dd7-7c35-935d-5f56d43baf7e', 151, NULL);
INSERT INTO public.ac_activities VALUES ('workflow_transition.publish', '[]', '2026-06-27 19:35:39', '6a40260bb88829.26429887', NULL, 'pages', '019f0a94-9dd7-7c35-935d-5f56d43baf7e', 'en', 'architecture-hub', 'Learning Paths', 'en', 'sulu.webspaces.architecture-hub', NULL, '019f0a94-9dd7-7c35-935d-5f56d43baf7e', 152, NULL);


--
-- Data for Name: ar_articles; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.ar_articles VALUES ('019f0a63-7da5-7277-98ce-4c75280acfbf', '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, NULL);
INSERT INTO public.ar_articles VALUES ('019f0a63-7ec1-797f-9a50-9fd0ee001098', '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, NULL);
INSERT INTO public.ar_articles VALUES ('019f0a63-7eec-7e3e-922e-19b253d0ba27', '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, NULL);
INSERT INTO public.ar_articles VALUES ('019f0a63-7f13-76a6-9820-09063579be68', '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, NULL);
INSERT INTO public.ar_articles VALUES ('019f0a63-7f3b-7053-816a-4e409ce7fff1', '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, NULL);
INSERT INTO public.ar_articles VALUES ('019f0a63-7f62-72e1-8f42-8c89ac4ed8c8', '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, NULL);
INSERT INTO public.ar_articles VALUES ('019f0a63-7f89-7c70-83fa-c4d99f423e05', '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, NULL);
INSERT INTO public.ar_articles VALUES ('019f0a63-7fba-7c70-b040-3e7e9ce94909', '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, NULL);
INSERT INTO public.ar_articles VALUES ('019f0a63-7fe7-7f84-9b23-0603fcc7155e', '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, NULL);
INSERT INTO public.ar_articles VALUES ('019f0a63-8011-7c5b-9a45-6195911b5536', '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, NULL);
INSERT INTO public.ar_articles VALUES ('019f0a63-803d-758c-a68a-55f5ee38d8b5', '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, NULL);
INSERT INTO public.ar_articles VALUES ('019f0a63-806b-75d3-9bb4-31d0fdf95812', '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, NULL);
INSERT INTO public.ar_articles VALUES ('019f0a63-80a8-73fa-ad9e-30557ace8490', '2026-06-27 18:42:01', '2026-06-27 18:42:01', NULL, NULL);
INSERT INTO public.ar_articles VALUES ('019f0a63-80e4-7806-83b8-8991df317fa6', '2026-06-27 18:42:01', '2026-06-27 18:42:01', NULL, NULL);
INSERT INTO public.ar_articles VALUES ('019f0a63-811e-7863-bee3-31d130b66430', '2026-06-27 18:42:01', '2026-06-27 18:42:01', NULL, NULL);
INSERT INTO public.ar_articles VALUES ('019f0a63-8150-7804-9c6f-f6c154f95cd1', '2026-06-27 18:42:01', '2026-06-27 18:42:01', NULL, NULL);
INSERT INTO public.ar_articles VALUES ('019f0a63-8184-76a6-979c-4683b7807a4f', '2026-06-27 18:42:01', '2026-06-27 18:42:01', NULL, NULL);
INSERT INTO public.ar_articles VALUES ('019f0a63-81b0-7060-8257-0ddd2bb95a71', '2026-06-27 18:42:01', '2026-06-27 18:42:01', NULL, NULL);
INSERT INTO public.ar_articles VALUES ('019f0a63-81dc-7e9b-9d96-64555bce8199', '2026-06-27 18:42:01', '2026-06-27 18:42:01', NULL, NULL);
INSERT INTO public.ar_articles VALUES ('019f0a63-820c-7902-9100-98c04b1f89bd', '2026-06-27 18:42:01', '2026-06-27 18:42:01', NULL, NULL);


--
-- Data for Name: co_contact_titles; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: me_collection_types; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.me_collection_types VALUES ('Default', 'collection.default', NULL, 1);
INSERT INTO public.me_collection_types VALUES ('System Collections', 'collection.system', NULL, 2);


--
-- Data for Name: me_collections; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.me_collections VALUES (NULL, 2, 5, 1, 'sulu_media', 8, '2026-06-27 18:41:54', '2026-06-27 18:41:54', 13, 2, 7, NULL, NULL);
INSERT INTO public.me_collections VALUES (NULL, 3, 4, 2, 'sulu_media.preview_image', 9, '2026-06-27 18:41:54', '2026-06-27 18:41:54', 15, 2, 8, NULL, NULL);
INSERT INTO public.me_collections VALUES (NULL, 7, 8, 2, 'sulu_contact.contact', 11, '2026-06-27 18:41:54', '2026-06-27 18:41:54', 19, 2, 10, NULL, NULL);
INSERT INTO public.me_collections VALUES (NULL, 1, 12, 0, 'system_collections', 7, '2026-06-27 18:41:53', '2026-06-27 18:41:53', 12, 2, NULL, NULL, NULL);
INSERT INTO public.me_collections VALUES (NULL, 6, 11, 1, 'sulu_contact', 10, '2026-06-27 18:41:54', '2026-06-27 18:41:54', 17, 2, 7, NULL, NULL);
INSERT INTO public.me_collections VALUES (NULL, 9, 10, 2, 'sulu_contact.account', 12, '2026-06-27 18:41:54', '2026-06-27 18:41:54', 21, 2, 10, NULL, NULL);


--
-- Data for Name: me_media; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: co_contacts; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.co_contacts VALUES ('Jane', NULL, 'Kowalski', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, '2026-06-27 18:39:12', '2026-06-27 18:39:12', NULL, NULL, NULL, NULL);
INSERT INTO public.co_contacts VALUES ('Adam', NULL, 'Ministrator', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, '2026-06-27 18:41:53', '2026-06-27 18:41:53', NULL, NULL, NULL, NULL);


--
-- Data for Name: ro_routes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.ro_routes VALUES ('architecture-hub', 'en', '/', 'pages', '019f0a63-6686-71f2-a8c9-b4e7f0c6ff6e', 2, NULL);
INSERT INTO public.ro_routes VALUES (NULL, 'en', '/understanding-the-cap-theorem', 'articles', '019f0a63-7da5-7277-98ce-4c75280acfbf', 3, 2);
INSERT INTO public.ro_routes VALUES (NULL, 'en', '/eventual-consistency-in-practice', 'articles', '019f0a63-7ec1-797f-9a50-9fd0ee001098', 4, 2);
INSERT INTO public.ro_routes VALUES (NULL, 'en', '/domain-driven-design-strategic-patterns', 'articles', '019f0a63-7eec-7e3e-922e-19b253d0ba27', 5, 2);
INSERT INTO public.ro_routes VALUES (NULL, 'en', '/domain-driven-design-aggregates', 'articles', '019f0a63-7f13-76a6-9820-09063579be68', 6, 2);
INSERT INTO public.ro_routes VALUES (NULL, 'en', '/value-objects-in-ddd', 'articles', '019f0a63-7f3b-7053-816a-4e409ce7fff1', 7, 2);
INSERT INTO public.ro_routes VALUES (NULL, 'en', '/cqrs-command-query-responsibility-segregation', 'articles', '019f0a63-7f62-72e1-8f42-8c89ac4ed8c8', 8, 2);
INSERT INTO public.ro_routes VALUES (NULL, 'en', '/event-sourcing-storing-state-as-events', 'articles', '019f0a63-7f89-7c70-83fa-c4d99f423e05', 9, 2);
INSERT INTO public.ro_routes VALUES (NULL, 'en', '/microservices-architecture-promises-and-pitfalls', 'articles', '019f0a63-7fba-7c70-b040-3e7e9ce94909', 10, 2);
INSERT INTO public.ro_routes VALUES (NULL, 'en', '/hexagonal-architecture-ports-and-adapters', 'articles', '019f0a63-7fe7-7f84-9b23-0603fcc7155e', 11, 2);
INSERT INTO public.ro_routes VALUES (NULL, 'en', '/clean-architecture-the-dependency-rule', 'articles', '019f0a63-8011-7c5b-9a45-6195911b5536', 12, 2);
INSERT INTO public.ro_routes VALUES (NULL, 'en', '/monolith-vs-microservices-when-to-split', 'articles', '019f0a63-803d-758c-a68a-55f5ee38d8b5', 13, 2);
INSERT INTO public.ro_routes VALUES (NULL, 'en', '/api-gateway-pattern', 'articles', '019f0a63-806b-75d3-9bb4-31d0fdf95812', 14, 2);
INSERT INTO public.ro_routes VALUES (NULL, 'en', '/saga-pattern-distributed-transactions', 'articles', '019f0a63-80a8-73fa-ad9e-30557ace8490', 15, 2);
INSERT INTO public.ro_routes VALUES (NULL, 'en', '/circuit-breaker-pattern', 'articles', '019f0a63-80e4-7806-83b8-8991df317fa6', 16, 2);
INSERT INTO public.ro_routes VALUES (NULL, 'en', '/the-outbox-pattern-for-reliable-messaging', 'articles', '019f0a63-811e-7863-bee3-31d130b66430', 17, 2);
INSERT INTO public.ro_routes VALUES (NULL, 'en', '/the-repository-pattern', 'articles', '019f0a63-8150-7804-9c6f-f6c154f95cd1', 18, 2);
INSERT INTO public.ro_routes VALUES (NULL, 'en', '/factory-pattern-object-creation', 'articles', '019f0a63-8184-76a6-979c-4683b7807a4f', 19, 2);
INSERT INTO public.ro_routes VALUES (NULL, 'en', '/strategy-pattern-encapsulating-algorithms', 'articles', '019f0a63-81b0-7060-8257-0ddd2bb95a71', 20, 2);
INSERT INTO public.ro_routes VALUES (NULL, 'en', '/observer-pattern-and-event-driven-design', 'articles', '019f0a63-81dc-7e9b-9d96-64555bce8199', 21, 2);
INSERT INTO public.ro_routes VALUES (NULL, 'en', '/dependency-injection-and-ioc-containers', 'articles', '019f0a63-820c-7902-9100-98c04b1f89bd', 22, 2);
INSERT INTO public.ro_routes VALUES ('architecture-hub', 'en', '/authors/adam-ministrator', 'pages', '019f0a63-823f-7d92-94b7-223065cae0d8', 23, NULL);
INSERT INTO public.ro_routes VALUES ('architecture-hub', 'en', '/authors/jane-kowalski', 'pages', '019f0a63-826d-77e6-adcf-e37b657311ed', 24, NULL);
INSERT INTO public.ro_routes VALUES ('architecture-hub', 'en', '/authors', 'pages', '019f0a71-f47f-7c8e-9018-5bfe524ddb81', 25, NULL);
INSERT INTO public.ro_routes VALUES ('architecture-hub', 'en', '/learning-paths/distributed-systems-fundamentals', 'pages', '019f0a94-9d57-7cad-b9d7-fb66234cc944', 26, NULL);
INSERT INTO public.ro_routes VALUES ('architecture-hub', 'en', '/learning-paths/domain-driven-design', 'pages', '019f0a94-9d85-74e2-9529-c565160fb66d', 27, NULL);
INSERT INTO public.ro_routes VALUES ('architecture-hub', 'en', '/learning-paths/architecture-patterns', 'pages', '019f0a94-9daf-7dc1-b7cd-8354981cfe04', 28, NULL);
INSERT INTO public.ro_routes VALUES ('architecture-hub', 'en', '/learning-paths', 'pages', '019f0a94-9dd7-7c35-935d-5f56d43baf7e', 29, NULL);


--
-- Data for Name: ar_article_dimension_contents; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 1, 'draft', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, '019f0a63-7da5-7277-98ce-4c75280acfbf', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 3, 'draft', NULL, 'en', '["en"]', 1782585720, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, '019f0a63-7da5-7277-98ce-4c75280acfbf', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('Understanding the CAP Theorem', false, 4, 'draft', 'en', NULL, NULL, 1782585720, NULL, NULL, 'article', '{"body": [{"_id": "a101", "text": "<p>The CAP theorem states that a distributed data store can guarantee at most two of three properties simultaneously: <strong>Consistency</strong> (every read returns the most recent write), <strong>Availability</strong> (every request gets a non-error response), and <strong>Partition Tolerance</strong> (the system continues operating despite network partitions). Because partitions are unavoidable in real networks, the practical choice is always between consistency and availability.</p>", "type": "text"}, {"_id": "a102", "type": "callout", "style": "info", "content": "<p>CP systems (ZooKeeper, HBase) reject requests during a partition to preserve consistency. AP systems (Cassandra, CouchDB) accept requests and resolve conflicts later.</p>"}], "tags": [27, 28, 29, 30], "title": "Understanding the CAP Theorem", "author": 4, "summary": "A practical look at consistency, availability, and partition tolerance — and why you can only pick two during a network partition.", "categories": [6]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-01-10 09:00:00', NULL, 'unpublished', NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, '019f0a63-7da5-7277-98ce-4c75280acfbf', 4, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 5, 'live', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, '019f0a63-7da5-7277-98ce-4c75280acfbf', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('Understanding the CAP Theorem', false, 6, 'live', 'en', NULL, NULL, 0, NULL, NULL, 'article', '{"body": [{"_id": "a101", "text": "<p>The CAP theorem states that a distributed data store can guarantee at most two of three properties simultaneously: <strong>Consistency</strong> (every read returns the most recent write), <strong>Availability</strong> (every request gets a non-error response), and <strong>Partition Tolerance</strong> (the system continues operating despite network partitions). Because partitions are unavoidable in real networks, the practical choice is always between consistency and availability.</p>", "type": "text"}, {"_id": "a102", "type": "callout", "style": "info", "content": "<p>CP systems (ZooKeeper, HBase) reject requests during a partition to preserve consistency. AP systems (Cassandra, CouchDB) accept requests and resolve conflicts later.</p>"}], "tags": [27, 28, 29, 30], "title": "Understanding the CAP Theorem", "author": 4, "summary": "A practical look at consistency, availability, and partition tolerance — and why you can only pick two during a network partition.", "categories": [6]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-01-10 09:00:00', NULL, NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', '2026-06-27 18:42:00', 3, '019f0a63-7da5-7277-98ce-4c75280acfbf', 4, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('Understanding the CAP Theorem', false, 2, 'draft', 'en', NULL, NULL, 0, NULL, NULL, 'article', '{"body": [{"_id": "a101", "text": "<p>The CAP theorem states that a distributed data store can guarantee at most two of three properties simultaneously: <strong>Consistency</strong> (every read returns the most recent write), <strong>Availability</strong> (every request gets a non-error response), and <strong>Partition Tolerance</strong> (the system continues operating despite network partitions). Because partitions are unavoidable in real networks, the practical choice is always between consistency and availability.</p>", "type": "text"}, {"_id": "a102", "type": "callout", "style": "info", "content": "<p>CP systems (ZooKeeper, HBase) reject requests during a partition to preserve consistency. AP systems (Cassandra, CouchDB) accept requests and resolve conflicts later.</p>"}], "tags": [27, 28, 29, 30], "title": "Understanding the CAP Theorem", "author": 4, "summary": "A practical look at consistency, availability, and partition tolerance — and why you can only pick two during a network partition.", "categories": [6]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-01-10 09:00:00', NULL, 'published', '2026-06-27 18:42:00', '2026-06-27 18:42:00', '2026-06-27 18:42:00', 3, '019f0a63-7da5-7277-98ce-4c75280acfbf', 4, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 7, 'draft', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, '019f0a63-7ec1-797f-9a50-9fd0ee001098', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 9, 'draft', NULL, 'en', '["en"]', 1782585720, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, '019f0a63-7ec1-797f-9a50-9fd0ee001098', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('Eventual Consistency in Practice', false, 10, 'draft', 'en', NULL, NULL, 1782585720, NULL, NULL, 'article', '{"body": [{"_id": "b101", "text": "<p>Eventual consistency guarantees that, if no new updates are made, all replicas will eventually return the same value. It sacrifices immediate global agreement in favour of availability and low latency. The system converges through background processes like <em>read-repair</em>, <em>hinted handoff</em>, and <em>anti-entropy</em> reconciliation.</p>", "type": "text"}, {"_id": "b102", "type": "callout", "style": "tip", "content": "<p>Conflict-free Replicated Data Types (CRDTs) make convergence mathematically guaranteed without coordination — a good fit for counters, sets, and last-write-wins registers.</p>"}], "tags": [28, 38, 31], "title": "Eventual Consistency in Practice", "author": 3, "summary": "How distributed systems converge to a consistent state over time, and the patterns that make it workable.", "categories": [6]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-01-12 09:00:00', NULL, 'unpublished', NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, '019f0a63-7ec1-797f-9a50-9fd0ee001098', 3, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 11, 'live', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, '019f0a63-7ec1-797f-9a50-9fd0ee001098', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('Eventual Consistency in Practice', false, 12, 'live', 'en', NULL, NULL, 0, NULL, NULL, 'article', '{"body": [{"_id": "b101", "text": "<p>Eventual consistency guarantees that, if no new updates are made, all replicas will eventually return the same value. It sacrifices immediate global agreement in favour of availability and low latency. The system converges through background processes like <em>read-repair</em>, <em>hinted handoff</em>, and <em>anti-entropy</em> reconciliation.</p>", "type": "text"}, {"_id": "b102", "type": "callout", "style": "tip", "content": "<p>Conflict-free Replicated Data Types (CRDTs) make convergence mathematically guaranteed without coordination — a good fit for counters, sets, and last-write-wins registers.</p>"}], "tags": [28, 38, 31], "title": "Eventual Consistency in Practice", "author": 3, "summary": "How distributed systems converge to a consistent state over time, and the patterns that make it workable.", "categories": [6]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-01-12 09:00:00', NULL, NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', '2026-06-27 18:42:00', 4, '019f0a63-7ec1-797f-9a50-9fd0ee001098', 3, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('Eventual Consistency in Practice', false, 8, 'draft', 'en', NULL, NULL, 0, NULL, NULL, 'article', '{"body": [{"_id": "b101", "text": "<p>Eventual consistency guarantees that, if no new updates are made, all replicas will eventually return the same value. It sacrifices immediate global agreement in favour of availability and low latency. The system converges through background processes like <em>read-repair</em>, <em>hinted handoff</em>, and <em>anti-entropy</em> reconciliation.</p>", "type": "text"}, {"_id": "b102", "type": "callout", "style": "tip", "content": "<p>Conflict-free Replicated Data Types (CRDTs) make convergence mathematically guaranteed without coordination — a good fit for counters, sets, and last-write-wins registers.</p>"}], "tags": [28, 38, 31], "title": "Eventual Consistency in Practice", "author": 3, "summary": "How distributed systems converge to a consistent state over time, and the patterns that make it workable.", "categories": [6]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-01-12 09:00:00', NULL, 'published', '2026-06-27 18:42:00', '2026-06-27 18:42:00', '2026-06-27 18:42:00', 4, '019f0a63-7ec1-797f-9a50-9fd0ee001098', 3, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 13, 'draft', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, '019f0a63-7eec-7e3e-922e-19b253d0ba27', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 15, 'draft', NULL, 'en', '["en"]', 1782585720, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, '019f0a63-7eec-7e3e-922e-19b253d0ba27', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('Domain-Driven Design: Strategic Patterns', false, 16, 'draft', 'en', NULL, NULL, 1782585720, NULL, NULL, 'article', '{"body": [{"_id": "c101", "text": "<p>Strategic DDD is about dividing a large domain into <strong>Bounded Contexts</strong> — explicit boundaries within which a model applies consistently. Each context has its own <em>Ubiquitous Language</em> shared between developers and domain experts. A <em>Context Map</em> documents how contexts relate: Shared Kernel, Customer-Supplier, Conformist, Anti-Corruption Layer, or Open Host Service.</p>", "type": "text"}, {"_id": "c102", "code": "OrderContext:\n  upstream: InventoryContext  # Inventory is upstream supplier\n  downstream: ShippingContext # Shipping conforms to Order\n  relationship: Customer-Supplier\n\nPaymentContext:\n  relationship: Shared-Kernel  # shared Money value object", "type": "code", "caption": "Context Map example", "language": "yaml"}], "tags": [39, 41], "title": "Domain-Driven Design: Strategic Patterns", "author": 4, "summary": "Bounded contexts, ubiquitous language, and context maps — the high-level tools for taming large domains.", "categories": [8]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-01-15 09:00:00', NULL, 'unpublished', NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, '019f0a63-7eec-7e3e-922e-19b253d0ba27', 4, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 17, 'live', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, '019f0a63-7eec-7e3e-922e-19b253d0ba27', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('Domain-Driven Design: Strategic Patterns', false, 18, 'live', 'en', NULL, NULL, 0, NULL, NULL, 'article', '{"body": [{"_id": "c101", "text": "<p>Strategic DDD is about dividing a large domain into <strong>Bounded Contexts</strong> — explicit boundaries within which a model applies consistently. Each context has its own <em>Ubiquitous Language</em> shared between developers and domain experts. A <em>Context Map</em> documents how contexts relate: Shared Kernel, Customer-Supplier, Conformist, Anti-Corruption Layer, or Open Host Service.</p>", "type": "text"}, {"_id": "c102", "code": "OrderContext:\n  upstream: InventoryContext  # Inventory is upstream supplier\n  downstream: ShippingContext # Shipping conforms to Order\n  relationship: Customer-Supplier\n\nPaymentContext:\n  relationship: Shared-Kernel  # shared Money value object", "type": "code", "caption": "Context Map example", "language": "yaml"}], "tags": [39, 41], "title": "Domain-Driven Design: Strategic Patterns", "author": 4, "summary": "Bounded contexts, ubiquitous language, and context maps — the high-level tools for taming large domains.", "categories": [8]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-01-15 09:00:00', NULL, NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', '2026-06-27 18:42:00', 5, '019f0a63-7eec-7e3e-922e-19b253d0ba27', 4, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('Domain-Driven Design: Strategic Patterns', false, 14, 'draft', 'en', NULL, NULL, 0, NULL, NULL, 'article', '{"body": [{"_id": "c101", "text": "<p>Strategic DDD is about dividing a large domain into <strong>Bounded Contexts</strong> — explicit boundaries within which a model applies consistently. Each context has its own <em>Ubiquitous Language</em> shared between developers and domain experts. A <em>Context Map</em> documents how contexts relate: Shared Kernel, Customer-Supplier, Conformist, Anti-Corruption Layer, or Open Host Service.</p>", "type": "text"}, {"_id": "c102", "code": "OrderContext:\n  upstream: InventoryContext  # Inventory is upstream supplier\n  downstream: ShippingContext # Shipping conforms to Order\n  relationship: Customer-Supplier\n\nPaymentContext:\n  relationship: Shared-Kernel  # shared Money value object", "type": "code", "caption": "Context Map example", "language": "yaml"}], "tags": [39, 41], "title": "Domain-Driven Design: Strategic Patterns", "author": 4, "summary": "Bounded contexts, ubiquitous language, and context maps — the high-level tools for taming large domains.", "categories": [8]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-01-15 09:00:00', NULL, 'published', '2026-06-27 18:42:00', '2026-06-27 18:42:00', '2026-06-27 18:42:00', 5, '019f0a63-7eec-7e3e-922e-19b253d0ba27', 4, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 19, 'draft', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, '019f0a63-7f13-76a6-9820-09063579be68', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 21, 'draft', NULL, 'en', '["en"]', 1782585720, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, '019f0a63-7f13-76a6-9820-09063579be68', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('Domain-Driven Design: Aggregates & Invariants', false, 22, 'draft', 'en', NULL, NULL, 1782585720, NULL, NULL, 'article', '{"body": [{"_id": "d101", "text": "<p>An <strong>Aggregate</strong> is a cluster of domain objects treated as a single unit for data changes. Every aggregate has a <em>root entity</em> — the only object external code may hold a reference to. All modifications go through the root, which enforces invariants across the cluster. This is the primary mechanism for maintaining consistency without distributed transactions.</p>", "type": "text"}, {"_id": "d102", "type": "callout", "style": "warning", "content": "<p>Keep aggregates small. A large aggregate becomes a contention hotspot — every write locks the entire cluster. If two concepts rarely change together, they probably belong in separate aggregates.</p>"}], "tags": [39, 40], "title": "Domain-Driven Design: Aggregates & Invariants", "author": 3, "summary": "What aggregates are, how to draw their boundaries, and why external code should only talk to the root.", "categories": [8]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-01-17 09:00:00', NULL, 'unpublished', NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, '019f0a63-7f13-76a6-9820-09063579be68', 3, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 23, 'live', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, '019f0a63-7f13-76a6-9820-09063579be68', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('Domain-Driven Design: Aggregates & Invariants', false, 24, 'live', 'en', NULL, NULL, 0, NULL, NULL, 'article', '{"body": [{"_id": "d101", "text": "<p>An <strong>Aggregate</strong> is a cluster of domain objects treated as a single unit for data changes. Every aggregate has a <em>root entity</em> — the only object external code may hold a reference to. All modifications go through the root, which enforces invariants across the cluster. This is the primary mechanism for maintaining consistency without distributed transactions.</p>", "type": "text"}, {"_id": "d102", "type": "callout", "style": "warning", "content": "<p>Keep aggregates small. A large aggregate becomes a contention hotspot — every write locks the entire cluster. If two concepts rarely change together, they probably belong in separate aggregates.</p>"}], "tags": [39, 40], "title": "Domain-Driven Design: Aggregates & Invariants", "author": 3, "summary": "What aggregates are, how to draw their boundaries, and why external code should only talk to the root.", "categories": [8]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-01-17 09:00:00', NULL, NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', '2026-06-27 18:42:00', 6, '019f0a63-7f13-76a6-9820-09063579be68', 3, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('Domain-Driven Design: Aggregates & Invariants', false, 20, 'draft', 'en', NULL, NULL, 0, NULL, NULL, 'article', '{"body": [{"_id": "d101", "text": "<p>An <strong>Aggregate</strong> is a cluster of domain objects treated as a single unit for data changes. Every aggregate has a <em>root entity</em> — the only object external code may hold a reference to. All modifications go through the root, which enforces invariants across the cluster. This is the primary mechanism for maintaining consistency without distributed transactions.</p>", "type": "text"}, {"_id": "d102", "type": "callout", "style": "warning", "content": "<p>Keep aggregates small. A large aggregate becomes a contention hotspot — every write locks the entire cluster. If two concepts rarely change together, they probably belong in separate aggregates.</p>"}], "tags": [39, 40], "title": "Domain-Driven Design: Aggregates & Invariants", "author": 3, "summary": "What aggregates are, how to draw their boundaries, and why external code should only talk to the root.", "categories": [8]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-01-17 09:00:00', NULL, 'published', '2026-06-27 18:42:00', '2026-06-27 18:42:00', '2026-06-27 18:42:00', 6, '019f0a63-7f13-76a6-9820-09063579be68', 3, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 25, 'draft', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, '019f0a63-7f3b-7053-816a-4e409ce7fff1', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 27, 'draft', NULL, 'en', '["en"]', 1782585720, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, '019f0a63-7f3b-7053-816a-4e409ce7fff1', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('Value Objects in Domain-Driven Design', false, 28, 'draft', 'en', NULL, NULL, 1782585720, NULL, NULL, 'article', '{"body": [{"_id": "e101", "text": "<p>A <strong>Value Object</strong> has no conceptual identity; it is defined entirely by its attributes. Two Money objects representing €10 are interchangeable regardless of which instance they are. Value objects should be <em>immutable</em>: operations return new instances rather than mutating state. This makes them safe to share across the model without defensive copying.</p>", "type": "text"}, {"_id": "e102", "code": "final class Money\n{\n    public function __construct(\n        private readonly int $amount,    // in cents\n        private readonly string $currency,\n    ) {}\n\n    public function add(Money $other): self\n    {\n        if ($this->currency !== $other->currency) {\n            throw new \\DomainException(''Currency mismatch'');\n        }\n        return new self($this->amount + $other->amount, $this->currency);\n    }\n}", "type": "code", "caption": "Immutable Money value object", "language": "php"}], "tags": [39, 42, 43], "title": "Value Objects in Domain-Driven Design", "author": 4, "summary": "Objects defined by their attributes rather than identity — and why immutability makes them safe to share.", "categories": [8]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-01-20 09:00:00', NULL, 'unpublished', NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, '019f0a63-7f3b-7053-816a-4e409ce7fff1', 4, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 29, 'live', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, '019f0a63-7f3b-7053-816a-4e409ce7fff1', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('Value Objects in Domain-Driven Design', false, 30, 'live', 'en', NULL, NULL, 0, NULL, NULL, 'article', '{"body": [{"_id": "e101", "text": "<p>A <strong>Value Object</strong> has no conceptual identity; it is defined entirely by its attributes. Two Money objects representing €10 are interchangeable regardless of which instance they are. Value objects should be <em>immutable</em>: operations return new instances rather than mutating state. This makes them safe to share across the model without defensive copying.</p>", "type": "text"}, {"_id": "e102", "code": "final class Money\n{\n    public function __construct(\n        private readonly int $amount,    // in cents\n        private readonly string $currency,\n    ) {}\n\n    public function add(Money $other): self\n    {\n        if ($this->currency !== $other->currency) {\n            throw new \\DomainException(''Currency mismatch'');\n        }\n        return new self($this->amount + $other->amount, $this->currency);\n    }\n}", "type": "code", "caption": "Immutable Money value object", "language": "php"}], "tags": [39, 42, 43], "title": "Value Objects in Domain-Driven Design", "author": 4, "summary": "Objects defined by their attributes rather than identity — and why immutability makes them safe to share.", "categories": [8]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-01-20 09:00:00', NULL, NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', '2026-06-27 18:42:00', 7, '019f0a63-7f3b-7053-816a-4e409ce7fff1', 4, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('Value Objects in Domain-Driven Design', false, 26, 'draft', 'en', NULL, NULL, 0, NULL, NULL, 'article', '{"body": [{"_id": "e101", "text": "<p>A <strong>Value Object</strong> has no conceptual identity; it is defined entirely by its attributes. Two Money objects representing €10 are interchangeable regardless of which instance they are. Value objects should be <em>immutable</em>: operations return new instances rather than mutating state. This makes them safe to share across the model without defensive copying.</p>", "type": "text"}, {"_id": "e102", "code": "final class Money\n{\n    public function __construct(\n        private readonly int $amount,    // in cents\n        private readonly string $currency,\n    ) {}\n\n    public function add(Money $other): self\n    {\n        if ($this->currency !== $other->currency) {\n            throw new \\DomainException(''Currency mismatch'');\n        }\n        return new self($this->amount + $other->amount, $this->currency);\n    }\n}", "type": "code", "caption": "Immutable Money value object", "language": "php"}], "tags": [39, 42, 43], "title": "Value Objects in Domain-Driven Design", "author": 4, "summary": "Objects defined by their attributes rather than identity — and why immutability makes them safe to share.", "categories": [8]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-01-20 09:00:00', NULL, 'published', '2026-06-27 18:42:00', '2026-06-27 18:42:00', '2026-06-27 18:42:00', 7, '019f0a63-7f3b-7053-816a-4e409ce7fff1', 4, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 31, 'draft', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, '019f0a63-7f62-72e1-8f42-8c89ac4ed8c8', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 33, 'draft', NULL, 'en', '["en"]', 1782585720, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, '019f0a63-7f62-72e1-8f42-8c89ac4ed8c8', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('CQRS: Command Query Responsibility Segregation', false, 34, 'draft', 'en', NULL, NULL, 1782585720, NULL, NULL, 'article', '{"body": [{"_id": "f101", "text": "<p>CQRS splits an application''s operations into <strong>Commands</strong> (intent to change state, no return value) and <strong>Queries</strong> (read state, no side effects). The write side enforces domain rules and emits events; the read side builds denormalised projections optimised for specific query patterns. The two sides can use completely different data models, databases, and scaling strategies.</p>", "type": "text"}, {"_id": "f102", "type": "callout", "style": "tip", "content": "<p>Don''t apply CQRS everywhere. Start with a simple unified model and introduce CQRS only in bounded contexts where read and write load profiles genuinely diverge.</p>"}], "tags": [36, 43, 32], "title": "CQRS: Command Query Responsibility Segregation", "author": 3, "summary": "Separating the write model from the read model to let each evolve independently and scale differently.", "categories": [9]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-01-22 09:00:00', NULL, 'unpublished', NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, '019f0a63-7f62-72e1-8f42-8c89ac4ed8c8', 3, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 35, 'live', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, '019f0a63-7f62-72e1-8f42-8c89ac4ed8c8', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('CQRS: Command Query Responsibility Segregation', false, 36, 'live', 'en', NULL, NULL, 0, NULL, NULL, 'article', '{"body": [{"_id": "f101", "text": "<p>CQRS splits an application''s operations into <strong>Commands</strong> (intent to change state, no return value) and <strong>Queries</strong> (read state, no side effects). The write side enforces domain rules and emits events; the read side builds denormalised projections optimised for specific query patterns. The two sides can use completely different data models, databases, and scaling strategies.</p>", "type": "text"}, {"_id": "f102", "type": "callout", "style": "tip", "content": "<p>Don''t apply CQRS everywhere. Start with a simple unified model and introduce CQRS only in bounded contexts where read and write load profiles genuinely diverge.</p>"}], "tags": [36, 43, 32], "title": "CQRS: Command Query Responsibility Segregation", "author": 3, "summary": "Separating the write model from the read model to let each evolve independently and scale differently.", "categories": [9]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-01-22 09:00:00', NULL, NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', '2026-06-27 18:42:00', 8, '019f0a63-7f62-72e1-8f42-8c89ac4ed8c8', 3, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('CQRS: Command Query Responsibility Segregation', false, 32, 'draft', 'en', NULL, NULL, 0, NULL, NULL, 'article', '{"body": [{"_id": "f101", "text": "<p>CQRS splits an application''s operations into <strong>Commands</strong> (intent to change state, no return value) and <strong>Queries</strong> (read state, no side effects). The write side enforces domain rules and emits events; the read side builds denormalised projections optimised for specific query patterns. The two sides can use completely different data models, databases, and scaling strategies.</p>", "type": "text"}, {"_id": "f102", "type": "callout", "style": "tip", "content": "<p>Don''t apply CQRS everywhere. Start with a simple unified model and introduce CQRS only in bounded contexts where read and write load profiles genuinely diverge.</p>"}], "tags": [36, 43, 32], "title": "CQRS: Command Query Responsibility Segregation", "author": 3, "summary": "Separating the write model from the read model to let each evolve independently and scale differently.", "categories": [9]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-01-22 09:00:00', NULL, 'published', '2026-06-27 18:42:00', '2026-06-27 18:42:00', '2026-06-27 18:42:00', 8, '019f0a63-7f62-72e1-8f42-8c89ac4ed8c8', 3, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 37, 'draft', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, '019f0a63-7f89-7c70-83fa-c4d99f423e05', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 39, 'draft', NULL, 'en', '["en"]', 1782585720, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, '019f0a63-7f89-7c70-83fa-c4d99f423e05', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('Event Sourcing: Storing State as a Sequence of Events', false, 40, 'draft', 'en', NULL, NULL, 1782585720, NULL, NULL, 'article', '{"body": [{"_id": "g101", "text": "<p>In event sourcing, the database is an <strong>append-only event log</strong>. Current state is a left-fold over all events for an aggregate. This gives you a complete audit trail, the ability to replay history for debugging, and a natural integration bus — other services subscribe to the same event stream. The trade-off is query complexity: you must build and maintain read-model projections.</p>", "type": "text"}, {"_id": "g102", "code": "{ \"type\": \"OrderPlaced\",   \"orderId\": \"ord-1\", \"total\": 49.99 }\n{ \"type\": \"ItemAdded\",     \"orderId\": \"ord-1\", \"sku\": \"ABC\", \"qty\": 2 }\n{ \"type\": \"OrderShipped\",  \"orderId\": \"ord-1\", \"trackingId\": \"TRK-99\" }", "type": "code", "caption": "Event store entries for an Order", "language": "json"}], "tags": [32, 31, 36], "title": "Event Sourcing: Storing State as a Sequence of Events", "author": 4, "summary": "Instead of persisting current state, store every change as an immutable event and derive state by replaying the log.", "categories": [10]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-01-25 09:00:00', NULL, 'unpublished', NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, '019f0a63-7f89-7c70-83fa-c4d99f423e05', 4, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 41, 'live', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, '019f0a63-7f89-7c70-83fa-c4d99f423e05', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('Event Sourcing: Storing State as a Sequence of Events', false, 42, 'live', 'en', NULL, NULL, 0, NULL, NULL, 'article', '{"body": [{"_id": "g101", "text": "<p>In event sourcing, the database is an <strong>append-only event log</strong>. Current state is a left-fold over all events for an aggregate. This gives you a complete audit trail, the ability to replay history for debugging, and a natural integration bus — other services subscribe to the same event stream. The trade-off is query complexity: you must build and maintain read-model projections.</p>", "type": "text"}, {"_id": "g102", "code": "{ \"type\": \"OrderPlaced\",   \"orderId\": \"ord-1\", \"total\": 49.99 }\n{ \"type\": \"ItemAdded\",     \"orderId\": \"ord-1\", \"sku\": \"ABC\", \"qty\": 2 }\n{ \"type\": \"OrderShipped\",  \"orderId\": \"ord-1\", \"trackingId\": \"TRK-99\" }", "type": "code", "caption": "Event store entries for an Order", "language": "json"}], "tags": [32, 31, 36], "title": "Event Sourcing: Storing State as a Sequence of Events", "author": 4, "summary": "Instead of persisting current state, store every change as an immutable event and derive state by replaying the log.", "categories": [10]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-01-25 09:00:00', NULL, NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', '2026-06-27 18:42:00', 9, '019f0a63-7f89-7c70-83fa-c4d99f423e05', 4, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('Event Sourcing: Storing State as a Sequence of Events', false, 38, 'draft', 'en', NULL, NULL, 0, NULL, NULL, 'article', '{"body": [{"_id": "g101", "text": "<p>In event sourcing, the database is an <strong>append-only event log</strong>. Current state is a left-fold over all events for an aggregate. This gives you a complete audit trail, the ability to replay history for debugging, and a natural integration bus — other services subscribe to the same event stream. The trade-off is query complexity: you must build and maintain read-model projections.</p>", "type": "text"}, {"_id": "g102", "code": "{ \"type\": \"OrderPlaced\",   \"orderId\": \"ord-1\", \"total\": 49.99 }\n{ \"type\": \"ItemAdded\",     \"orderId\": \"ord-1\", \"sku\": \"ABC\", \"qty\": 2 }\n{ \"type\": \"OrderShipped\",  \"orderId\": \"ord-1\", \"trackingId\": \"TRK-99\" }", "type": "code", "caption": "Event store entries for an Order", "language": "json"}], "tags": [32, 31, 36], "title": "Event Sourcing: Storing State as a Sequence of Events", "author": 4, "summary": "Instead of persisting current state, store every change as an immutable event and derive state by replaying the log.", "categories": [10]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-01-25 09:00:00', NULL, 'published', '2026-06-27 18:42:00', '2026-06-27 18:42:00', '2026-06-27 18:42:00', 9, '019f0a63-7f89-7c70-83fa-c4d99f423e05', 4, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 43, 'draft', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, '019f0a63-7fba-7c70-b040-3e7e9ce94909', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 45, 'draft', NULL, 'en', '["en"]', 1782585720, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, '019f0a63-7fba-7c70-b040-3e7e9ce94909', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('Microservices Architecture: Promises & Pitfalls', false, 46, 'draft', 'en', NULL, NULL, 1782585720, NULL, NULL, 'article', '{"body": [{"_id": "h101", "text": "<p>Microservices decompose an application into small, independently deployable services aligned to business capabilities. Each service owns its data store, can be deployed on its own release cadence, and can be scaled individually. The promises are real: teams move faster and blast radius is smaller. The pitfalls are equally real: network calls replace in-process calls, distributed tracing becomes essential, and data consistency requires choreography or sagas.</p>", "type": "text"}, {"_id": "h102", "type": "callout", "style": "warning", "content": "<p>Don''t start with microservices. Build a well-structured modular monolith first. Extract services only when you have clear operational reasons: independent scaling, independent deployment cadence, or isolated failure domains.</p>"}], "tags": [33, 38], "title": "Microservices Architecture: Promises & Pitfalls", "author": 3, "summary": "Independent deployability and polyglot freedom come with distributed systems complexity — here is what to expect.", "categories": [9]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-01-28 09:00:00', NULL, 'unpublished', NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, '019f0a63-7fba-7c70-b040-3e7e9ce94909', 3, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 47, 'live', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, '019f0a63-7fba-7c70-b040-3e7e9ce94909', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('Microservices Architecture: Promises & Pitfalls', false, 48, 'live', 'en', NULL, NULL, 0, NULL, NULL, 'article', '{"body": [{"_id": "h101", "text": "<p>Microservices decompose an application into small, independently deployable services aligned to business capabilities. Each service owns its data store, can be deployed on its own release cadence, and can be scaled individually. The promises are real: teams move faster and blast radius is smaller. The pitfalls are equally real: network calls replace in-process calls, distributed tracing becomes essential, and data consistency requires choreography or sagas.</p>", "type": "text"}, {"_id": "h102", "type": "callout", "style": "warning", "content": "<p>Don''t start with microservices. Build a well-structured modular monolith first. Extract services only when you have clear operational reasons: independent scaling, independent deployment cadence, or isolated failure domains.</p>"}], "tags": [33, 38], "title": "Microservices Architecture: Promises & Pitfalls", "author": 3, "summary": "Independent deployability and polyglot freedom come with distributed systems complexity — here is what to expect.", "categories": [9]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-01-28 09:00:00', NULL, NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', '2026-06-27 18:42:00', 10, '019f0a63-7fba-7c70-b040-3e7e9ce94909', 3, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('Microservices Architecture: Promises & Pitfalls', false, 44, 'draft', 'en', NULL, NULL, 0, NULL, NULL, 'article', '{"body": [{"_id": "h101", "text": "<p>Microservices decompose an application into small, independently deployable services aligned to business capabilities. Each service owns its data store, can be deployed on its own release cadence, and can be scaled individually. The promises are real: teams move faster and blast radius is smaller. The pitfalls are equally real: network calls replace in-process calls, distributed tracing becomes essential, and data consistency requires choreography or sagas.</p>", "type": "text"}, {"_id": "h102", "type": "callout", "style": "warning", "content": "<p>Don''t start with microservices. Build a well-structured modular monolith first. Extract services only when you have clear operational reasons: independent scaling, independent deployment cadence, or isolated failure domains.</p>"}], "tags": [33, 38], "title": "Microservices Architecture: Promises & Pitfalls", "author": 3, "summary": "Independent deployability and polyglot freedom come with distributed systems complexity — here is what to expect.", "categories": [9]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-01-28 09:00:00', NULL, 'published', '2026-06-27 18:42:00', '2026-06-27 18:42:00', '2026-06-27 18:42:00', 10, '019f0a63-7fba-7c70-b040-3e7e9ce94909', 3, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 49, 'draft', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, '019f0a63-7fe7-7f84-9b23-0603fcc7155e', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 51, 'draft', NULL, 'en', '["en"]', 1782585720, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, '019f0a63-7fe7-7f84-9b23-0603fcc7155e', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('Hexagonal Architecture: Ports and Adapters', false, 52, 'draft', 'en', NULL, NULL, 1782585720, NULL, NULL, 'article', '{"body": [{"_id": "i101", "text": "<p>Hexagonal architecture (Alistair Cockburn, 2005) places the application core at the centre with <strong>Ports</strong> (interfaces) on the boundary and <strong>Adapters</strong> as the implementations that connect to the outside world. The domain never imports infrastructure code — it imports only its own interfaces. Infrastructure imports the domain. This makes it trivial to swap databases, test without HTTP, or add a new delivery mechanism.</p>", "type": "text"}, {"_id": "i102", "type": "callout", "style": "tip", "content": "<p>A port is just an interface. An adapter is a class that implements the port using real infrastructure (Doctrine, Redis, Symfony Mailer). In tests, use a fake adapter — no mocking frameworks needed.</p>"}], "tags": [44, 45, 43], "title": "Hexagonal Architecture: Ports and Adapters", "author": 4, "summary": "Isolate your domain from infrastructure by inverting dependencies — the application core knows nothing about HTTP, databases, or queues.", "categories": [9]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-02-01 09:00:00', NULL, 'unpublished', NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, '019f0a63-7fe7-7f84-9b23-0603fcc7155e', 4, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 53, 'live', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, '019f0a63-7fe7-7f84-9b23-0603fcc7155e', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('Hexagonal Architecture: Ports and Adapters', false, 54, 'live', 'en', NULL, NULL, 0, NULL, NULL, 'article', '{"body": [{"_id": "i101", "text": "<p>Hexagonal architecture (Alistair Cockburn, 2005) places the application core at the centre with <strong>Ports</strong> (interfaces) on the boundary and <strong>Adapters</strong> as the implementations that connect to the outside world. The domain never imports infrastructure code — it imports only its own interfaces. Infrastructure imports the domain. This makes it trivial to swap databases, test without HTTP, or add a new delivery mechanism.</p>", "type": "text"}, {"_id": "i102", "type": "callout", "style": "tip", "content": "<p>A port is just an interface. An adapter is a class that implements the port using real infrastructure (Doctrine, Redis, Symfony Mailer). In tests, use a fake adapter — no mocking frameworks needed.</p>"}], "tags": [44, 45, 43], "title": "Hexagonal Architecture: Ports and Adapters", "author": 4, "summary": "Isolate your domain from infrastructure by inverting dependencies — the application core knows nothing about HTTP, databases, or queues.", "categories": [9]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-02-01 09:00:00', NULL, NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', '2026-06-27 18:42:00', 11, '019f0a63-7fe7-7f84-9b23-0603fcc7155e', 4, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('Hexagonal Architecture: Ports and Adapters', false, 50, 'draft', 'en', NULL, NULL, 0, NULL, NULL, 'article', '{"body": [{"_id": "i101", "text": "<p>Hexagonal architecture (Alistair Cockburn, 2005) places the application core at the centre with <strong>Ports</strong> (interfaces) on the boundary and <strong>Adapters</strong> as the implementations that connect to the outside world. The domain never imports infrastructure code — it imports only its own interfaces. Infrastructure imports the domain. This makes it trivial to swap databases, test without HTTP, or add a new delivery mechanism.</p>", "type": "text"}, {"_id": "i102", "type": "callout", "style": "tip", "content": "<p>A port is just an interface. An adapter is a class that implements the port using real infrastructure (Doctrine, Redis, Symfony Mailer). In tests, use a fake adapter — no mocking frameworks needed.</p>"}], "tags": [44, 45, 43], "title": "Hexagonal Architecture: Ports and Adapters", "author": 4, "summary": "Isolate your domain from infrastructure by inverting dependencies — the application core knows nothing about HTTP, databases, or queues.", "categories": [9]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-02-01 09:00:00', NULL, 'published', '2026-06-27 18:42:00', '2026-06-27 18:42:00', '2026-06-27 18:42:00', 11, '019f0a63-7fe7-7f84-9b23-0603fcc7155e', 4, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 55, 'draft', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, '019f0a63-8011-7c5b-9a45-6195911b5536', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 57, 'draft', NULL, 'en', '["en"]', 1782585720, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, '019f0a63-8011-7c5b-9a45-6195911b5536', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('Clean Architecture: The Dependency Rule', false, 58, 'draft', 'en', NULL, NULL, 1782585720, NULL, NULL, 'article', '{"body": [{"_id": "j101", "text": "<p>Robert Martin''s Clean Architecture organises code into concentric layers: <em>Entities</em> (enterprise-wide rules), <em>Use Cases</em> (application-specific rules), <em>Interface Adapters</em> (controllers, presenters, gateways), and <em>Frameworks & Drivers</em> (web, database, UI). The <strong>Dependency Rule</strong> is absolute: source code dependencies must point inward only. Nothing in an inner layer may name or depend on anything in an outer layer.</p>", "type": "text"}, {"_id": "j102", "type": "callout", "style": "info", "content": "<p>The dependency inversion principle is the mechanism that enforces the rule — inner layers define interfaces; outer layers implement them. The framework calls your code; your code never calls the framework directly.</p>"}], "tags": [45, 43, 39], "title": "Clean Architecture: The Dependency Rule", "author": 3, "summary": "Source code dependencies must always point inward — toward higher-level policy and away from details like frameworks and databases.", "categories": [9]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-02-04 09:00:00', NULL, 'unpublished', NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, '019f0a63-8011-7c5b-9a45-6195911b5536', 3, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 59, 'live', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, '019f0a63-8011-7c5b-9a45-6195911b5536', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('Clean Architecture: The Dependency Rule', false, 60, 'live', 'en', NULL, NULL, 0, NULL, NULL, 'article', '{"body": [{"_id": "j101", "text": "<p>Robert Martin''s Clean Architecture organises code into concentric layers: <em>Entities</em> (enterprise-wide rules), <em>Use Cases</em> (application-specific rules), <em>Interface Adapters</em> (controllers, presenters, gateways), and <em>Frameworks & Drivers</em> (web, database, UI). The <strong>Dependency Rule</strong> is absolute: source code dependencies must point inward only. Nothing in an inner layer may name or depend on anything in an outer layer.</p>", "type": "text"}, {"_id": "j102", "type": "callout", "style": "info", "content": "<p>The dependency inversion principle is the mechanism that enforces the rule — inner layers define interfaces; outer layers implement them. The framework calls your code; your code never calls the framework directly.</p>"}], "tags": [45, 43, 39], "title": "Clean Architecture: The Dependency Rule", "author": 3, "summary": "Source code dependencies must always point inward — toward higher-level policy and away from details like frameworks and databases.", "categories": [9]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-02-04 09:00:00', NULL, NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', '2026-06-27 18:42:00', 12, '019f0a63-8011-7c5b-9a45-6195911b5536', 3, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('Clean Architecture: The Dependency Rule', false, 56, 'draft', 'en', NULL, NULL, 0, NULL, NULL, 'article', '{"body": [{"_id": "j101", "text": "<p>Robert Martin''s Clean Architecture organises code into concentric layers: <em>Entities</em> (enterprise-wide rules), <em>Use Cases</em> (application-specific rules), <em>Interface Adapters</em> (controllers, presenters, gateways), and <em>Frameworks & Drivers</em> (web, database, UI). The <strong>Dependency Rule</strong> is absolute: source code dependencies must point inward only. Nothing in an inner layer may name or depend on anything in an outer layer.</p>", "type": "text"}, {"_id": "j102", "type": "callout", "style": "info", "content": "<p>The dependency inversion principle is the mechanism that enforces the rule — inner layers define interfaces; outer layers implement them. The framework calls your code; your code never calls the framework directly.</p>"}], "tags": [45, 43, 39], "title": "Clean Architecture: The Dependency Rule", "author": 3, "summary": "Source code dependencies must always point inward — toward higher-level policy and away from details like frameworks and databases.", "categories": [9]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-02-04 09:00:00', NULL, 'published', '2026-06-27 18:42:00', '2026-06-27 18:42:00', '2026-06-27 18:42:00', 12, '019f0a63-8011-7c5b-9a45-6195911b5536', 3, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 61, 'draft', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, '019f0a63-803d-758c-a68a-55f5ee38d8b5', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 63, 'draft', NULL, 'en', '["en"]', 1782585720, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, '019f0a63-803d-758c-a68a-55f5ee38d8b5', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('Monolith vs Microservices: When to Split', false, 64, 'draft', 'en', NULL, NULL, 1782585720, NULL, NULL, 'article', '{"body": [{"_id": "k101", "text": "<p>A well-structured modular monolith is the right default for most products. It is simpler to deploy, debug, and refactor. The signals that make splitting worthwhile are specific and operational: <em>independent team deployment cadence</em> (one team blocks another''s releases), <em>independent scaling requirements</em> (one component needs 100× the resources of the rest), or <em>isolated failure domains</em> (one subsystem must keep running when another is down).</p>", "type": "text"}, {"_id": "k102", "type": "callout", "style": "info", "content": "<p>Organise your monolith into modules with strict dependency rules first. Extract only the modules that meet the operational criteria above — and only after you have proven the boundary is stable enough to survive a network hop.</p>"}], "tags": [37, 33, 38], "title": "Monolith vs Microservices: When to Split", "author": 4, "summary": "A decision framework for choosing between a modular monolith and microservices — and the signals that tell you it is time to split.", "categories": [9]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-02-07 09:00:00', NULL, 'unpublished', NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, '019f0a63-803d-758c-a68a-55f5ee38d8b5', 4, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 65, 'live', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, '019f0a63-803d-758c-a68a-55f5ee38d8b5', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('Monolith vs Microservices: When to Split', false, 66, 'live', 'en', NULL, NULL, 0, NULL, NULL, 'article', '{"body": [{"_id": "k101", "text": "<p>A well-structured modular monolith is the right default for most products. It is simpler to deploy, debug, and refactor. The signals that make splitting worthwhile are specific and operational: <em>independent team deployment cadence</em> (one team blocks another''s releases), <em>independent scaling requirements</em> (one component needs 100× the resources of the rest), or <em>isolated failure domains</em> (one subsystem must keep running when another is down).</p>", "type": "text"}, {"_id": "k102", "type": "callout", "style": "info", "content": "<p>Organise your monolith into modules with strict dependency rules first. Extract only the modules that meet the operational criteria above — and only after you have proven the boundary is stable enough to survive a network hop.</p>"}], "tags": [37, 33, 38], "title": "Monolith vs Microservices: When to Split", "author": 4, "summary": "A decision framework for choosing between a modular monolith and microservices — and the signals that tell you it is time to split.", "categories": [9]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-02-07 09:00:00', NULL, NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', '2026-06-27 18:42:00', 13, '019f0a63-803d-758c-a68a-55f5ee38d8b5', 4, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('Monolith vs Microservices: When to Split', false, 62, 'draft', 'en', NULL, NULL, 0, NULL, NULL, 'article', '{"body": [{"_id": "k101", "text": "<p>A well-structured modular monolith is the right default for most products. It is simpler to deploy, debug, and refactor. The signals that make splitting worthwhile are specific and operational: <em>independent team deployment cadence</em> (one team blocks another''s releases), <em>independent scaling requirements</em> (one component needs 100× the resources of the rest), or <em>isolated failure domains</em> (one subsystem must keep running when another is down).</p>", "type": "text"}, {"_id": "k102", "type": "callout", "style": "info", "content": "<p>Organise your monolith into modules with strict dependency rules first. Extract only the modules that meet the operational criteria above — and only after you have proven the boundary is stable enough to survive a network hop.</p>"}], "tags": [37, 33, 38], "title": "Monolith vs Microservices: When to Split", "author": 4, "summary": "A decision framework for choosing between a modular monolith and microservices — and the signals that tell you it is time to split.", "categories": [9]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-02-07 09:00:00', NULL, 'published', '2026-06-27 18:42:00', '2026-06-27 18:42:00', '2026-06-27 18:42:00', 13, '019f0a63-803d-758c-a68a-55f5ee38d8b5', 4, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 67, 'draft', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, '019f0a63-806b-75d3-9bb4-31d0fdf95812', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 69, 'draft', NULL, 'en', '["en"]', 1782585720, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, '019f0a63-806b-75d3-9bb4-31d0fdf95812', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('The API Gateway Pattern', false, 70, 'draft', 'en', NULL, NULL, 1782585720, NULL, NULL, 'article', '{"body": [{"_id": "l101", "text": "<p>An API Gateway sits between clients and backend services, acting as the system''s front door. It handles cross-cutting concerns — authentication, authorisation, rate limiting, SSL termination, request logging, and protocol translation — so individual services do not have to. It can also aggregate responses from multiple services into a single client-friendly payload (Backend for Frontend pattern).</p>", "type": "text"}, {"_id": "l102", "type": "callout", "style": "tip", "content": "<p>Do not put business logic in the gateway. Route, translate, and enforce policy — nothing more. Business decisions belong in the services behind it. A gateway that accumulates logic becomes a deployment bottleneck and single point of failure.</p>"}], "tags": [52, 33], "title": "The API Gateway Pattern", "author": 3, "summary": "A single entry point for clients that handles routing, auth, rate limiting, and protocol translation across backend services.", "categories": [9]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-02-10 09:00:00', NULL, 'unpublished', NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, '019f0a63-806b-75d3-9bb4-31d0fdf95812', 3, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 71, 'live', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', NULL, '019f0a63-806b-75d3-9bb4-31d0fdf95812', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('The API Gateway Pattern', false, 72, 'live', 'en', NULL, NULL, 0, NULL, NULL, 'article', '{"body": [{"_id": "l101", "text": "<p>An API Gateway sits between clients and backend services, acting as the system''s front door. It handles cross-cutting concerns — authentication, authorisation, rate limiting, SSL termination, request logging, and protocol translation — so individual services do not have to. It can also aggregate responses from multiple services into a single client-friendly payload (Backend for Frontend pattern).</p>", "type": "text"}, {"_id": "l102", "type": "callout", "style": "tip", "content": "<p>Do not put business logic in the gateway. Route, translate, and enforce policy — nothing more. Business decisions belong in the services behind it. A gateway that accumulates logic becomes a deployment bottleneck and single point of failure.</p>"}], "tags": [52, 33], "title": "The API Gateway Pattern", "author": 3, "summary": "A single entry point for clients that handles routing, auth, rate limiting, and protocol translation across backend services.", "categories": [9]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-02-10 09:00:00', NULL, NULL, '2026-06-27 18:42:00', '2026-06-27 18:42:00', '2026-06-27 18:42:00', 14, '019f0a63-806b-75d3-9bb4-31d0fdf95812', 3, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('The API Gateway Pattern', false, 68, 'draft', 'en', NULL, NULL, 0, NULL, NULL, 'article', '{"body": [{"_id": "l101", "text": "<p>An API Gateway sits between clients and backend services, acting as the system''s front door. It handles cross-cutting concerns — authentication, authorisation, rate limiting, SSL termination, request logging, and protocol translation — so individual services do not have to. It can also aggregate responses from multiple services into a single client-friendly payload (Backend for Frontend pattern).</p>", "type": "text"}, {"_id": "l102", "type": "callout", "style": "tip", "content": "<p>Do not put business logic in the gateway. Route, translate, and enforce policy — nothing more. Business decisions belong in the services behind it. A gateway that accumulates logic becomes a deployment bottleneck and single point of failure.</p>"}], "tags": [52, 33], "title": "The API Gateway Pattern", "author": 3, "summary": "A single entry point for clients that handles routing, auth, rate limiting, and protocol translation across backend services.", "categories": [9]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-02-10 09:00:00', NULL, 'published', '2026-06-27 18:42:00', '2026-06-27 18:42:00', '2026-06-27 18:42:00', 14, '019f0a63-806b-75d3-9bb4-31d0fdf95812', 3, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 73, 'draft', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:01', '2026-06-27 18:42:01', NULL, '019f0a63-80a8-73fa-ad9e-30557ace8490', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 75, 'draft', NULL, 'en', '["en"]', 1782585721, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:01', '2026-06-27 18:42:01', NULL, '019f0a63-80a8-73fa-ad9e-30557ace8490', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('The Saga Pattern: Distributed Transactions Without 2PC', false, 76, 'draft', 'en', NULL, NULL, 1782585721, NULL, NULL, 'article', '{"body": [{"_id": "m101", "text": "<p>A <strong>Saga</strong> is a sequence of local transactions where each step publishes an event or sends a message to trigger the next. If a step fails, the saga executes <em>compensating transactions</em> to undo the work already done. There are two coordination styles: <em>choreography</em> (each service reacts to events with no central orchestrator) and <em>orchestration</em> (a central saga orchestrator directs each participant).</p>", "type": "text"}, {"_id": "m102", "type": "callout", "style": "warning", "content": "<p>Sagas are hard to debug. Compensating transactions must be idempotent and cannot truly \"rollback\" — they create new corrective state. Invest heavily in distributed tracing and saga state visualisation before going to production.</p>"}], "tags": [34, 33, 38], "title": "The Saga Pattern: Distributed Transactions Without 2PC", "author": 4, "summary": "Coordinate long-running business transactions across services using a sequence of local transactions and compensating actions.", "categories": [10]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-02-13 09:00:00', NULL, 'unpublished', NULL, '2026-06-27 18:42:01', '2026-06-27 18:42:01', NULL, '019f0a63-80a8-73fa-ad9e-30557ace8490', 4, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 77, 'live', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:01', '2026-06-27 18:42:01', NULL, '019f0a63-80a8-73fa-ad9e-30557ace8490', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('The Saga Pattern: Distributed Transactions Without 2PC', false, 78, 'live', 'en', NULL, NULL, 0, NULL, NULL, 'article', '{"body": [{"_id": "m101", "text": "<p>A <strong>Saga</strong> is a sequence of local transactions where each step publishes an event or sends a message to trigger the next. If a step fails, the saga executes <em>compensating transactions</em> to undo the work already done. There are two coordination styles: <em>choreography</em> (each service reacts to events with no central orchestrator) and <em>orchestration</em> (a central saga orchestrator directs each participant).</p>", "type": "text"}, {"_id": "m102", "type": "callout", "style": "warning", "content": "<p>Sagas are hard to debug. Compensating transactions must be idempotent and cannot truly \"rollback\" — they create new corrective state. Invest heavily in distributed tracing and saga state visualisation before going to production.</p>"}], "tags": [34, 33, 38], "title": "The Saga Pattern: Distributed Transactions Without 2PC", "author": 4, "summary": "Coordinate long-running business transactions across services using a sequence of local transactions and compensating actions.", "categories": [10]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-02-13 09:00:00', NULL, NULL, '2026-06-27 18:42:01', '2026-06-27 18:42:01', '2026-06-27 18:42:01', 15, '019f0a63-80a8-73fa-ad9e-30557ace8490', 4, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('The Saga Pattern: Distributed Transactions Without 2PC', false, 74, 'draft', 'en', NULL, NULL, 0, NULL, NULL, 'article', '{"body": [{"_id": "m101", "text": "<p>A <strong>Saga</strong> is a sequence of local transactions where each step publishes an event or sends a message to trigger the next. If a step fails, the saga executes <em>compensating transactions</em> to undo the work already done. There are two coordination styles: <em>choreography</em> (each service reacts to events with no central orchestrator) and <em>orchestration</em> (a central saga orchestrator directs each participant).</p>", "type": "text"}, {"_id": "m102", "type": "callout", "style": "warning", "content": "<p>Sagas are hard to debug. Compensating transactions must be idempotent and cannot truly \"rollback\" — they create new corrective state. Invest heavily in distributed tracing and saga state visualisation before going to production.</p>"}], "tags": [34, 33, 38], "title": "The Saga Pattern: Distributed Transactions Without 2PC", "author": 4, "summary": "Coordinate long-running business transactions across services using a sequence of local transactions and compensating actions.", "categories": [10]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-02-13 09:00:00', NULL, 'published', '2026-06-27 18:42:01', '2026-06-27 18:42:01', '2026-06-27 18:42:01', 15, '019f0a63-80a8-73fa-ad9e-30557ace8490', 4, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 79, 'draft', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:01', '2026-06-27 18:42:01', NULL, '019f0a63-80e4-7806-83b8-8991df317fa6', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 81, 'draft', NULL, 'en', '["en"]', 1782585721, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:01', '2026-06-27 18:42:01', NULL, '019f0a63-80e4-7806-83b8-8991df317fa6', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('The Circuit Breaker Pattern', false, 82, 'draft', 'en', NULL, NULL, 1782585721, NULL, NULL, 'article', '{"body": [{"_id": "n101", "text": "<p>A circuit breaker wraps a remote call and tracks failure rates. In the <strong>Closed</strong> state, calls pass through normally. After a failure threshold is crossed, the breaker trips to <strong>Open</strong> and immediately rejects calls (fail fast). After a timeout, it enters <strong>Half-Open</strong> and allows a probe request: success resets to Closed, failure returns to Open.</p>", "type": "text"}, {"_id": "n102", "type": "callout", "style": "info", "content": "<p>Without a circuit breaker, a slow or failing downstream service holds threads open until the thread pool is exhausted, taking the caller offline too — a cascade failure. The breaker prevents the cascade by failing fast and giving the downstream service time to recover.</p>"}], "tags": [46, 33, 38], "title": "The Circuit Breaker Pattern", "author": 3, "summary": "Stop cascading failures by detecting when a downstream service is unhealthy and short-circuiting calls until it recovers.", "categories": [10]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-02-16 09:00:00', NULL, 'unpublished', NULL, '2026-06-27 18:42:01', '2026-06-27 18:42:01', NULL, '019f0a63-80e4-7806-83b8-8991df317fa6', 3, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 83, 'live', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:01', '2026-06-27 18:42:01', NULL, '019f0a63-80e4-7806-83b8-8991df317fa6', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('The Circuit Breaker Pattern', false, 84, 'live', 'en', NULL, NULL, 0, NULL, NULL, 'article', '{"body": [{"_id": "n101", "text": "<p>A circuit breaker wraps a remote call and tracks failure rates. In the <strong>Closed</strong> state, calls pass through normally. After a failure threshold is crossed, the breaker trips to <strong>Open</strong> and immediately rejects calls (fail fast). After a timeout, it enters <strong>Half-Open</strong> and allows a probe request: success resets to Closed, failure returns to Open.</p>", "type": "text"}, {"_id": "n102", "type": "callout", "style": "info", "content": "<p>Without a circuit breaker, a slow or failing downstream service holds threads open until the thread pool is exhausted, taking the caller offline too — a cascade failure. The breaker prevents the cascade by failing fast and giving the downstream service time to recover.</p>"}], "tags": [46, 33, 38], "title": "The Circuit Breaker Pattern", "author": 3, "summary": "Stop cascading failures by detecting when a downstream service is unhealthy and short-circuiting calls until it recovers.", "categories": [10]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-02-16 09:00:00', NULL, NULL, '2026-06-27 18:42:01', '2026-06-27 18:42:01', '2026-06-27 18:42:01', 16, '019f0a63-80e4-7806-83b8-8991df317fa6', 3, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('The Circuit Breaker Pattern', false, 80, 'draft', 'en', NULL, NULL, 0, NULL, NULL, 'article', '{"body": [{"_id": "n101", "text": "<p>A circuit breaker wraps a remote call and tracks failure rates. In the <strong>Closed</strong> state, calls pass through normally. After a failure threshold is crossed, the breaker trips to <strong>Open</strong> and immediately rejects calls (fail fast). After a timeout, it enters <strong>Half-Open</strong> and allows a probe request: success resets to Closed, failure returns to Open.</p>", "type": "text"}, {"_id": "n102", "type": "callout", "style": "info", "content": "<p>Without a circuit breaker, a slow or failing downstream service holds threads open until the thread pool is exhausted, taking the caller offline too — a cascade failure. The breaker prevents the cascade by failing fast and giving the downstream service time to recover.</p>"}], "tags": [46, 33, 38], "title": "The Circuit Breaker Pattern", "author": 3, "summary": "Stop cascading failures by detecting when a downstream service is unhealthy and short-circuiting calls until it recovers.", "categories": [10]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-02-16 09:00:00', NULL, 'published', '2026-06-27 18:42:01', '2026-06-27 18:42:01', '2026-06-27 18:42:01', 16, '019f0a63-80e4-7806-83b8-8991df317fa6', 3, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 85, 'draft', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:01', '2026-06-27 18:42:01', NULL, '019f0a63-811e-7863-bee3-31d130b66430', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 87, 'draft', NULL, 'en', '["en"]', 1782585721, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:01', '2026-06-27 18:42:01', NULL, '019f0a63-811e-7863-bee3-31d130b66430', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('The Outbox Pattern for Reliable Messaging', false, 88, 'draft', 'en', NULL, NULL, 1782585721, NULL, NULL, 'article', '{"body": [{"_id": "o101", "text": "<p>The <strong>dual-write problem</strong>: if you write to your database and then publish to a message broker, a crash between the two leaves them inconsistent. The outbox pattern solves this by writing messages to an <em>outbox table</em> in the same local transaction as the business data. A relay process reads the outbox and publishes to the broker, marking messages as sent. Atomicity is guaranteed by the database; the broker gets at-least-once delivery.</p>", "type": "text"}, {"_id": "o102", "code": "CREATE TABLE outbox (\n    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),\n    aggregate   TEXT        NOT NULL,\n    event_type  TEXT        NOT NULL,\n    payload     JSONB       NOT NULL,\n    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),\n    sent_at     TIMESTAMPTZ\n);", "type": "code", "caption": "Outbox table structure", "language": "sql"}], "tags": [35, 31, 38], "title": "The Outbox Pattern for Reliable Messaging", "author": 4, "summary": "Guarantee at-least-once event delivery without two-phase commit by writing events to the database in the same transaction as your business data.", "categories": [10]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-02-19 09:00:00', NULL, 'unpublished', NULL, '2026-06-27 18:42:01', '2026-06-27 18:42:01', NULL, '019f0a63-811e-7863-bee3-31d130b66430', 4, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 89, 'live', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:01', '2026-06-27 18:42:01', NULL, '019f0a63-811e-7863-bee3-31d130b66430', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('The Outbox Pattern for Reliable Messaging', false, 90, 'live', 'en', NULL, NULL, 0, NULL, NULL, 'article', '{"body": [{"_id": "o101", "text": "<p>The <strong>dual-write problem</strong>: if you write to your database and then publish to a message broker, a crash between the two leaves them inconsistent. The outbox pattern solves this by writing messages to an <em>outbox table</em> in the same local transaction as the business data. A relay process reads the outbox and publishes to the broker, marking messages as sent. Atomicity is guaranteed by the database; the broker gets at-least-once delivery.</p>", "type": "text"}, {"_id": "o102", "code": "CREATE TABLE outbox (\n    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),\n    aggregate   TEXT        NOT NULL,\n    event_type  TEXT        NOT NULL,\n    payload     JSONB       NOT NULL,\n    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),\n    sent_at     TIMESTAMPTZ\n);", "type": "code", "caption": "Outbox table structure", "language": "sql"}], "tags": [35, 31, 38], "title": "The Outbox Pattern for Reliable Messaging", "author": 4, "summary": "Guarantee at-least-once event delivery without two-phase commit by writing events to the database in the same transaction as your business data.", "categories": [10]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-02-19 09:00:00', NULL, NULL, '2026-06-27 18:42:01', '2026-06-27 18:42:01', '2026-06-27 18:42:01', 17, '019f0a63-811e-7863-bee3-31d130b66430', 4, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('The Outbox Pattern for Reliable Messaging', false, 86, 'draft', 'en', NULL, NULL, 0, NULL, NULL, 'article', '{"body": [{"_id": "o101", "text": "<p>The <strong>dual-write problem</strong>: if you write to your database and then publish to a message broker, a crash between the two leaves them inconsistent. The outbox pattern solves this by writing messages to an <em>outbox table</em> in the same local transaction as the business data. A relay process reads the outbox and publishes to the broker, marking messages as sent. Atomicity is guaranteed by the database; the broker gets at-least-once delivery.</p>", "type": "text"}, {"_id": "o102", "code": "CREATE TABLE outbox (\n    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),\n    aggregate   TEXT        NOT NULL,\n    event_type  TEXT        NOT NULL,\n    payload     JSONB       NOT NULL,\n    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),\n    sent_at     TIMESTAMPTZ\n);", "type": "code", "caption": "Outbox table structure", "language": "sql"}], "tags": [35, 31, 38], "title": "The Outbox Pattern for Reliable Messaging", "author": 4, "summary": "Guarantee at-least-once event delivery without two-phase commit by writing events to the database in the same transaction as your business data.", "categories": [10]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-02-19 09:00:00', NULL, 'published', '2026-06-27 18:42:01', '2026-06-27 18:42:01', '2026-06-27 18:42:01', 17, '019f0a63-811e-7863-bee3-31d130b66430', 4, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 91, 'draft', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:01', '2026-06-27 18:42:01', NULL, '019f0a63-8150-7804-9c6f-f6c154f95cd1', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 93, 'draft', NULL, 'en', '["en"]', 1782585721, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:01', '2026-06-27 18:42:01', NULL, '019f0a63-8150-7804-9c6f-f6c154f95cd1', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('The Repository Pattern', false, 94, 'draft', 'en', NULL, NULL, 1782585721, NULL, NULL, 'article', '{"body": [{"_id": "p101", "text": "<p>A <strong>Repository</strong> encapsulates the logic for querying and persisting aggregates, presenting a collection-like interface to the domain layer. The domain asks the repository for objects by identity or specification; it never writes SQL or calls an ORM directly. This decouples the domain from persistence infrastructure and makes it straightforward to test the domain with in-memory fakes.</p>", "type": "text"}, {"_id": "p102", "code": "interface OrderRepository\n{\n    public function findById(OrderId $id): ?Order;\n    public function findPendingOlderThan(\\DateTimeImmutable $cutoff): array;\n    public function save(Order $order): void;\n    public function remove(Order $order): void;\n}", "type": "code", "caption": "Repository interface in the domain layer", "language": "php"}], "tags": [47, 43, 39], "title": "The Repository Pattern", "author": 3, "summary": "Mediate between the domain model and the data mapping layer using a collection-like interface for accessing domain objects.", "categories": [7]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-02-22 09:00:00', NULL, 'unpublished', NULL, '2026-06-27 18:42:01', '2026-06-27 18:42:01', NULL, '019f0a63-8150-7804-9c6f-f6c154f95cd1', 3, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 95, 'live', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:01', '2026-06-27 18:42:01', NULL, '019f0a63-8150-7804-9c6f-f6c154f95cd1', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('The Repository Pattern', false, 96, 'live', 'en', NULL, NULL, 0, NULL, NULL, 'article', '{"body": [{"_id": "p101", "text": "<p>A <strong>Repository</strong> encapsulates the logic for querying and persisting aggregates, presenting a collection-like interface to the domain layer. The domain asks the repository for objects by identity or specification; it never writes SQL or calls an ORM directly. This decouples the domain from persistence infrastructure and makes it straightforward to test the domain with in-memory fakes.</p>", "type": "text"}, {"_id": "p102", "code": "interface OrderRepository\n{\n    public function findById(OrderId $id): ?Order;\n    public function findPendingOlderThan(\\DateTimeImmutable $cutoff): array;\n    public function save(Order $order): void;\n    public function remove(Order $order): void;\n}", "type": "code", "caption": "Repository interface in the domain layer", "language": "php"}], "tags": [47, 43, 39], "title": "The Repository Pattern", "author": 3, "summary": "Mediate between the domain model and the data mapping layer using a collection-like interface for accessing domain objects.", "categories": [7]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-02-22 09:00:00', NULL, NULL, '2026-06-27 18:42:01', '2026-06-27 18:42:01', '2026-06-27 18:42:01', 18, '019f0a63-8150-7804-9c6f-f6c154f95cd1', 3, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('The Repository Pattern', false, 92, 'draft', 'en', NULL, NULL, 0, NULL, NULL, 'article', '{"body": [{"_id": "p101", "text": "<p>A <strong>Repository</strong> encapsulates the logic for querying and persisting aggregates, presenting a collection-like interface to the domain layer. The domain asks the repository for objects by identity or specification; it never writes SQL or calls an ORM directly. This decouples the domain from persistence infrastructure and makes it straightforward to test the domain with in-memory fakes.</p>", "type": "text"}, {"_id": "p102", "code": "interface OrderRepository\n{\n    public function findById(OrderId $id): ?Order;\n    public function findPendingOlderThan(\\DateTimeImmutable $cutoff): array;\n    public function save(Order $order): void;\n    public function remove(Order $order): void;\n}", "type": "code", "caption": "Repository interface in the domain layer", "language": "php"}], "tags": [47, 43, 39], "title": "The Repository Pattern", "author": 3, "summary": "Mediate between the domain model and the data mapping layer using a collection-like interface for accessing domain objects.", "categories": [7]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-02-22 09:00:00', NULL, 'published', '2026-06-27 18:42:01', '2026-06-27 18:42:01', '2026-06-27 18:42:01', 18, '019f0a63-8150-7804-9c6f-f6c154f95cd1', 3, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 97, 'draft', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:01', '2026-06-27 18:42:01', NULL, '019f0a63-8184-76a6-979c-4683b7807a4f', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 99, 'draft', NULL, 'en', '["en"]', 1782585721, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:01', '2026-06-27 18:42:01', NULL, '019f0a63-8184-76a6-979c-4683b7807a4f', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('The Factory Pattern: Centralising Object Creation', false, 100, 'draft', 'en', NULL, NULL, 1782585721, NULL, NULL, 'article', '{"body": [{"_id": "q101", "text": "<p>When constructing an object requires complex logic — choosing a concrete subclass, validating invariants, or coordinating multiple collaborators — that logic should not live in the caller or in the object itself. A <strong>Factory</strong> centralises creation, enforces invariants at construction time, and returns a fully initialised object. In DDD, factories are especially useful for creating aggregates whose initial state is non-trivial.</p>", "type": "text"}, {"_id": "q102", "code": "final class Order\n{\n    private function __construct(\n        private readonly OrderId $id,\n        private readonly CustomerId $customerId,\n        private array $items = [],\n    ) {}\n\n    public static function place(CustomerId $customerId, array $items): self\n    {\n        if (empty($items)) {\n            throw new \\DomainException(''An order must have at least one item.'');\n        }\n        return new self(OrderId::generate(), $customerId, $items);\n    }\n}", "type": "code", "caption": "Static factory method on an aggregate", "language": "php"}], "tags": [48, 43], "title": "The Factory Pattern: Centralising Object Creation", "author": 4, "summary": "Delegate the responsibility of creating complex objects to a dedicated factory, keeping construction logic out of the domain and callers.", "categories": [7]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-02-25 09:00:00', NULL, 'unpublished', NULL, '2026-06-27 18:42:01', '2026-06-27 18:42:01', NULL, '019f0a63-8184-76a6-979c-4683b7807a4f', 4, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 101, 'live', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:01', '2026-06-27 18:42:01', NULL, '019f0a63-8184-76a6-979c-4683b7807a4f', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('The Factory Pattern: Centralising Object Creation', false, 102, 'live', 'en', NULL, NULL, 0, NULL, NULL, 'article', '{"body": [{"_id": "q101", "text": "<p>When constructing an object requires complex logic — choosing a concrete subclass, validating invariants, or coordinating multiple collaborators — that logic should not live in the caller or in the object itself. A <strong>Factory</strong> centralises creation, enforces invariants at construction time, and returns a fully initialised object. In DDD, factories are especially useful for creating aggregates whose initial state is non-trivial.</p>", "type": "text"}, {"_id": "q102", "code": "final class Order\n{\n    private function __construct(\n        private readonly OrderId $id,\n        private readonly CustomerId $customerId,\n        private array $items = [],\n    ) {}\n\n    public static function place(CustomerId $customerId, array $items): self\n    {\n        if (empty($items)) {\n            throw new \\DomainException(''An order must have at least one item.'');\n        }\n        return new self(OrderId::generate(), $customerId, $items);\n    }\n}", "type": "code", "caption": "Static factory method on an aggregate", "language": "php"}], "tags": [48, 43], "title": "The Factory Pattern: Centralising Object Creation", "author": 4, "summary": "Delegate the responsibility of creating complex objects to a dedicated factory, keeping construction logic out of the domain and callers.", "categories": [7]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-02-25 09:00:00', NULL, NULL, '2026-06-27 18:42:01', '2026-06-27 18:42:01', '2026-06-27 18:42:01', 19, '019f0a63-8184-76a6-979c-4683b7807a4f', 4, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('The Factory Pattern: Centralising Object Creation', false, 98, 'draft', 'en', NULL, NULL, 0, NULL, NULL, 'article', '{"body": [{"_id": "q101", "text": "<p>When constructing an object requires complex logic — choosing a concrete subclass, validating invariants, or coordinating multiple collaborators — that logic should not live in the caller or in the object itself. A <strong>Factory</strong> centralises creation, enforces invariants at construction time, and returns a fully initialised object. In DDD, factories are especially useful for creating aggregates whose initial state is non-trivial.</p>", "type": "text"}, {"_id": "q102", "code": "final class Order\n{\n    private function __construct(\n        private readonly OrderId $id,\n        private readonly CustomerId $customerId,\n        private array $items = [],\n    ) {}\n\n    public static function place(CustomerId $customerId, array $items): self\n    {\n        if (empty($items)) {\n            throw new \\DomainException(''An order must have at least one item.'');\n        }\n        return new self(OrderId::generate(), $customerId, $items);\n    }\n}", "type": "code", "caption": "Static factory method on an aggregate", "language": "php"}], "tags": [48, 43], "title": "The Factory Pattern: Centralising Object Creation", "author": 4, "summary": "Delegate the responsibility of creating complex objects to a dedicated factory, keeping construction logic out of the domain and callers.", "categories": [7]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-02-25 09:00:00', NULL, 'published', '2026-06-27 18:42:01', '2026-06-27 18:42:01', '2026-06-27 18:42:01', 19, '019f0a63-8184-76a6-979c-4683b7807a4f', 4, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 103, 'draft', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:01', '2026-06-27 18:42:01', NULL, '019f0a63-81b0-7060-8257-0ddd2bb95a71', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 105, 'draft', NULL, 'en', '["en"]', 1782585721, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:01', '2026-06-27 18:42:01', NULL, '019f0a63-81b0-7060-8257-0ddd2bb95a71', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('The Strategy Pattern: Encapsulating Algorithms', false, 106, 'draft', 'en', NULL, NULL, 1782585721, NULL, NULL, 'article', '{"body": [{"_id": "r101", "text": "<p>The <strong>Strategy</strong> pattern defines a set of interchangeable algorithms behind a common interface. The context class delegates the algorithm to a strategy object rather than hard-coding it. This eliminates conditional branching inside the context and makes it easy to add new algorithms without modifying existing code — satisfying the Open/Closed Principle.</p>", "type": "text"}, {"_id": "r102", "code": "interface ShippingStrategy\n{\n    public function calculate(Order $order): Money;\n}\n\nclass StandardShipping implements ShippingStrategy { /* ... */ }\nclass ExpressShipping implements ShippingStrategy { /* ... */ }\n\nclass OrderPricer\n{\n    public function __construct(private readonly ShippingStrategy $shipping) {}\n\n    public function total(Order $order): Money\n    {\n        return $order->subtotal()->add($this->shipping->calculate($order));\n    }\n}", "type": "code", "caption": "Shipping cost strategy", "language": "php"}], "tags": [49, 43], "title": "The Strategy Pattern: Encapsulating Algorithms", "author": 3, "summary": "Define a family of algorithms, encapsulate each one, and make them interchangeable — open for extension, closed for modification.", "categories": [7]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-02-28 09:00:00', NULL, 'unpublished', NULL, '2026-06-27 18:42:01', '2026-06-27 18:42:01', NULL, '019f0a63-81b0-7060-8257-0ddd2bb95a71', 3, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 107, 'live', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:01', '2026-06-27 18:42:01', NULL, '019f0a63-81b0-7060-8257-0ddd2bb95a71', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('The Strategy Pattern: Encapsulating Algorithms', false, 108, 'live', 'en', NULL, NULL, 0, NULL, NULL, 'article', '{"body": [{"_id": "r101", "text": "<p>The <strong>Strategy</strong> pattern defines a set of interchangeable algorithms behind a common interface. The context class delegates the algorithm to a strategy object rather than hard-coding it. This eliminates conditional branching inside the context and makes it easy to add new algorithms without modifying existing code — satisfying the Open/Closed Principle.</p>", "type": "text"}, {"_id": "r102", "code": "interface ShippingStrategy\n{\n    public function calculate(Order $order): Money;\n}\n\nclass StandardShipping implements ShippingStrategy { /* ... */ }\nclass ExpressShipping implements ShippingStrategy { /* ... */ }\n\nclass OrderPricer\n{\n    public function __construct(private readonly ShippingStrategy $shipping) {}\n\n    public function total(Order $order): Money\n    {\n        return $order->subtotal()->add($this->shipping->calculate($order));\n    }\n}", "type": "code", "caption": "Shipping cost strategy", "language": "php"}], "tags": [49, 43], "title": "The Strategy Pattern: Encapsulating Algorithms", "author": 3, "summary": "Define a family of algorithms, encapsulate each one, and make them interchangeable — open for extension, closed for modification.", "categories": [7]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-02-28 09:00:00', NULL, NULL, '2026-06-27 18:42:01', '2026-06-27 18:42:01', '2026-06-27 18:42:01', 20, '019f0a63-81b0-7060-8257-0ddd2bb95a71', 3, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('The Strategy Pattern: Encapsulating Algorithms', false, 104, 'draft', 'en', NULL, NULL, 0, NULL, NULL, 'article', '{"body": [{"_id": "r101", "text": "<p>The <strong>Strategy</strong> pattern defines a set of interchangeable algorithms behind a common interface. The context class delegates the algorithm to a strategy object rather than hard-coding it. This eliminates conditional branching inside the context and makes it easy to add new algorithms without modifying existing code — satisfying the Open/Closed Principle.</p>", "type": "text"}, {"_id": "r102", "code": "interface ShippingStrategy\n{\n    public function calculate(Order $order): Money;\n}\n\nclass StandardShipping implements ShippingStrategy { /* ... */ }\nclass ExpressShipping implements ShippingStrategy { /* ... */ }\n\nclass OrderPricer\n{\n    public function __construct(private readonly ShippingStrategy $shipping) {}\n\n    public function total(Order $order): Money\n    {\n        return $order->subtotal()->add($this->shipping->calculate($order));\n    }\n}", "type": "code", "caption": "Shipping cost strategy", "language": "php"}], "tags": [49, 43], "title": "The Strategy Pattern: Encapsulating Algorithms", "author": 3, "summary": "Define a family of algorithms, encapsulate each one, and make them interchangeable — open for extension, closed for modification.", "categories": [7]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-02-28 09:00:00', NULL, 'published', '2026-06-27 18:42:01', '2026-06-27 18:42:01', '2026-06-27 18:42:01', 20, '019f0a63-81b0-7060-8257-0ddd2bb95a71', 3, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 109, 'draft', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:01', '2026-06-27 18:42:01', NULL, '019f0a63-81dc-7e9b-9d96-64555bce8199', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 111, 'draft', NULL, 'en', '["en"]', 1782585721, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:01', '2026-06-27 18:42:01', NULL, '019f0a63-81dc-7e9b-9d96-64555bce8199', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('The Observer Pattern and Event-Driven Design', false, 112, 'draft', 'en', NULL, NULL, 1782585721, NULL, NULL, 'article', '{"body": [{"_id": "s101", "text": "<p>The <strong>Observer</strong> pattern defines a one-to-many dependency: when a subject''s state changes, all registered observers are notified automatically. This decouples the subject from its dependents — the subject does not know how many observers exist or what they do. Modern event buses, domain event dispatchers, and reactive streams all implement this idea at different scales.</p>", "type": "text"}, {"_id": "s102", "type": "callout", "style": "tip", "content": "<p>In domain-driven systems, raise domain events inside aggregates and dispatch them after the transaction commits. This keeps the aggregate focused on invariants while allowing side effects (sending emails, updating projections) to be handled by separate listeners.</p>"}], "tags": [50, 31, 43], "title": "The Observer Pattern and Event-Driven Design", "author": 4, "summary": "Decouple publishers from subscribers by letting objects register interest in events without the producer knowing who is listening.", "categories": [7]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-03-03 09:00:00', NULL, 'unpublished', NULL, '2026-06-27 18:42:01', '2026-06-27 18:42:01', NULL, '019f0a63-81dc-7e9b-9d96-64555bce8199', 4, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 113, 'live', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:01', '2026-06-27 18:42:01', NULL, '019f0a63-81dc-7e9b-9d96-64555bce8199', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('The Observer Pattern and Event-Driven Design', false, 114, 'live', 'en', NULL, NULL, 0, NULL, NULL, 'article', '{"body": [{"_id": "s101", "text": "<p>The <strong>Observer</strong> pattern defines a one-to-many dependency: when a subject''s state changes, all registered observers are notified automatically. This decouples the subject from its dependents — the subject does not know how many observers exist or what they do. Modern event buses, domain event dispatchers, and reactive streams all implement this idea at different scales.</p>", "type": "text"}, {"_id": "s102", "type": "callout", "style": "tip", "content": "<p>In domain-driven systems, raise domain events inside aggregates and dispatch them after the transaction commits. This keeps the aggregate focused on invariants while allowing side effects (sending emails, updating projections) to be handled by separate listeners.</p>"}], "tags": [50, 31, 43], "title": "The Observer Pattern and Event-Driven Design", "author": 4, "summary": "Decouple publishers from subscribers by letting objects register interest in events without the producer knowing who is listening.", "categories": [7]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-03-03 09:00:00', NULL, NULL, '2026-06-27 18:42:01', '2026-06-27 18:42:01', '2026-06-27 18:42:01', 21, '019f0a63-81dc-7e9b-9d96-64555bce8199', 4, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('The Observer Pattern and Event-Driven Design', false, 110, 'draft', 'en', NULL, NULL, 0, NULL, NULL, 'article', '{"body": [{"_id": "s101", "text": "<p>The <strong>Observer</strong> pattern defines a one-to-many dependency: when a subject''s state changes, all registered observers are notified automatically. This decouples the subject from its dependents — the subject does not know how many observers exist or what they do. Modern event buses, domain event dispatchers, and reactive streams all implement this idea at different scales.</p>", "type": "text"}, {"_id": "s102", "type": "callout", "style": "tip", "content": "<p>In domain-driven systems, raise domain events inside aggregates and dispatch them after the transaction commits. This keeps the aggregate focused on invariants while allowing side effects (sending emails, updating projections) to be handled by separate listeners.</p>"}], "tags": [50, 31, 43], "title": "The Observer Pattern and Event-Driven Design", "author": 4, "summary": "Decouple publishers from subscribers by letting objects register interest in events without the producer knowing who is listening.", "categories": [7]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-03-03 09:00:00', NULL, 'published', '2026-06-27 18:42:01', '2026-06-27 18:42:01', '2026-06-27 18:42:01', 21, '019f0a63-81dc-7e9b-9d96-64555bce8199', 4, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 115, 'draft', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:01', '2026-06-27 18:42:01', NULL, '019f0a63-820c-7902-9100-98c04b1f89bd', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 117, 'draft', NULL, 'en', '["en"]', 1782585721, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:01', '2026-06-27 18:42:01', NULL, '019f0a63-820c-7902-9100-98c04b1f89bd', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('Dependency Injection and IoC Containers', false, 118, 'draft', 'en', NULL, NULL, 1782585721, NULL, NULL, 'article', '{"body": [{"_id": "t101", "text": "<p><strong>Dependency Injection</strong> means that a class receives its collaborators from the outside rather than creating them itself. Constructor injection is the clearest form: the dependencies are declared as constructor parameters and provided at instantiation. This inverts control — the class no longer owns its dependencies'' lifecycle — and makes substitution (for testing or configuration) straightforward without any mocking framework.</p>", "type": "text"}, {"_id": "t102", "code": "class OrderService\n{\n    public function __construct(\n        private readonly OrderRepository $orders,\n        private readonly EventBus $events,\n        private readonly Clock $clock,\n    ) {}\n}\n\n// In a test — plain PHP, no container:\n$service = new OrderService(\n    new InMemoryOrderRepository(),\n    new RecordingEventBus(),\n    new FixedClock(''2026-03-06''),\n);", "type": "code", "caption": "Constructor injection — no container magic needed in tests", "language": "php"}], "tags": [51, 43, 45], "title": "Dependency Injection and IoC Containers", "author": 3, "summary": "Invert control of dependency creation to keep classes decoupled from their collaborators and trivially testable.", "categories": [7]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-03-06 09:00:00', NULL, 'unpublished', NULL, '2026-06-27 18:42:01', '2026-06-27 18:42:01', NULL, '019f0a63-820c-7902-9100-98c04b1f89bd', 3, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES (NULL, false, 119, 'live', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:01', '2026-06-27 18:42:01', NULL, '019f0a63-820c-7902-9100-98c04b1f89bd', NULL, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('Dependency Injection and IoC Containers', false, 120, 'live', 'en', NULL, NULL, 0, NULL, NULL, 'article', '{"body": [{"_id": "t101", "text": "<p><strong>Dependency Injection</strong> means that a class receives its collaborators from the outside rather than creating them itself. Constructor injection is the clearest form: the dependencies are declared as constructor parameters and provided at instantiation. This inverts control — the class no longer owns its dependencies'' lifecycle — and makes substitution (for testing or configuration) straightforward without any mocking framework.</p>", "type": "text"}, {"_id": "t102", "code": "class OrderService\n{\n    public function __construct(\n        private readonly OrderRepository $orders,\n        private readonly EventBus $events,\n        private readonly Clock $clock,\n    ) {}\n}\n\n// In a test — plain PHP, no container:\n$service = new OrderService(\n    new InMemoryOrderRepository(),\n    new RecordingEventBus(),\n    new FixedClock(''2026-03-06''),\n);", "type": "code", "caption": "Constructor injection — no container magic needed in tests", "language": "php"}], "tags": [51, 43, 45], "title": "Dependency Injection and IoC Containers", "author": 3, "summary": "Invert control of dependency creation to keep classes decoupled from their collaborators and trivially testable.", "categories": [7]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-03-06 09:00:00', NULL, NULL, '2026-06-27 18:42:01', '2026-06-27 18:42:01', '2026-06-27 18:42:01', 22, '019f0a63-820c-7902-9100-98c04b1f89bd', 3, NULL, NULL);
INSERT INTO public.ar_article_dimension_contents VALUES ('Dependency Injection and IoC Containers', false, 116, 'draft', 'en', NULL, NULL, 0, NULL, NULL, 'article', '{"body": [{"_id": "t101", "text": "<p><strong>Dependency Injection</strong> means that a class receives its collaborators from the outside rather than creating them itself. Constructor injection is the clearest form: the dependencies are declared as constructor parameters and provided at instantiation. This inverts control — the class no longer owns its dependencies'' lifecycle — and makes substitution (for testing or configuration) straightforward without any mocking framework.</p>", "type": "text"}, {"_id": "t102", "code": "class OrderService\n{\n    public function __construct(\n        private readonly OrderRepository $orders,\n        private readonly EventBus $events,\n        private readonly Clock $clock,\n    ) {}\n}\n\n// In a test — plain PHP, no container:\n$service = new OrderService(\n    new InMemoryOrderRepository(),\n    new RecordingEventBus(),\n    new FixedClock(''2026-03-06''),\n);", "type": "code", "caption": "Constructor injection — no container magic needed in tests", "language": "php"}], "tags": [51, 43, 45], "title": "Dependency Injection and IoC Containers", "author": 3, "summary": "Invert control of dependency creation to keep classes decoupled from their collaborators and trivially testable.", "categories": [7]}', '[]', false, false, false, '[]', NULL, 'architecture-hub', '2026-03-06 09:00:00', NULL, 'published', '2026-06-27 18:42:01', '2026-06-27 18:42:01', '2026-06-27 18:42:01', 22, '019f0a63-820c-7902-9100-98c04b1f89bd', 3, NULL, NULL);


--
-- Data for Name: ar_article_dimension_content_additional_webspaces; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: ca_categories; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.ca_categories VALUES ('distributed-systems', 'en', 1, 2, 0, 6, '2026-06-27 18:39:12', '2026-06-27 18:39:12', NULL, NULL, NULL);
INSERT INTO public.ca_categories VALUES ('design-patterns', 'en', 3, 4, 0, 7, '2026-06-27 18:39:12', '2026-06-27 18:39:12', NULL, NULL, NULL);
INSERT INTO public.ca_categories VALUES ('ddd', 'en', 5, 6, 0, 8, '2026-06-27 18:39:12', '2026-06-27 18:39:12', NULL, NULL, NULL);
INSERT INTO public.ca_categories VALUES ('architecture-styles', 'en', 7, 8, 0, 9, '2026-06-27 18:39:12', '2026-06-27 18:39:12', NULL, NULL, NULL);
INSERT INTO public.ca_categories VALUES ('messaging-patterns', 'en', 9, 10, 0, 10, '2026-06-27 18:39:12', '2026-06-27 18:39:12', NULL, NULL, NULL);


--
-- Data for Name: ar_article_dimension_content_excerpt_categories; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: ta_tags; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.ta_tags VALUES ('cap-theorem', 27, '2026-06-27 18:39:12', '2026-06-27 18:39:12', NULL, NULL);
INSERT INTO public.ta_tags VALUES ('consistency', 28, '2026-06-27 18:39:12', '2026-06-27 18:39:12', NULL, NULL);
INSERT INTO public.ta_tags VALUES ('availability', 29, '2026-06-27 18:39:12', '2026-06-27 18:39:12', NULL, NULL);
INSERT INTO public.ta_tags VALUES ('partition-tolerance', 30, '2026-06-27 18:39:12', '2026-06-27 18:39:12', NULL, NULL);
INSERT INTO public.ta_tags VALUES ('event-driven', 31, '2026-06-27 18:39:12', '2026-06-27 18:39:12', NULL, NULL);
INSERT INTO public.ta_tags VALUES ('event-sourcing', 32, '2026-06-27 18:39:12', '2026-06-27 18:39:12', NULL, NULL);
INSERT INTO public.ta_tags VALUES ('microservices', 33, '2026-06-27 18:39:12', '2026-06-27 18:39:12', NULL, NULL);
INSERT INTO public.ta_tags VALUES ('saga', 34, '2026-06-27 18:39:12', '2026-06-27 18:39:12', NULL, NULL);
INSERT INTO public.ta_tags VALUES ('outbox', 35, '2026-06-27 18:39:12', '2026-06-27 18:39:12', NULL, NULL);
INSERT INTO public.ta_tags VALUES ('cqrs', 36, '2026-06-27 18:39:12', '2026-06-27 18:39:12', NULL, NULL);
INSERT INTO public.ta_tags VALUES ('monolith', 37, '2026-06-27 18:39:12', '2026-06-27 18:39:12', NULL, NULL);
INSERT INTO public.ta_tags VALUES ('distributed-systems', 38, '2026-06-27 18:39:12', '2026-06-27 18:39:12', NULL, NULL);
INSERT INTO public.ta_tags VALUES ('ddd', 39, '2026-06-27 18:39:12', '2026-06-27 18:39:12', NULL, NULL);
INSERT INTO public.ta_tags VALUES ('aggregates', 40, '2026-06-27 18:39:12', '2026-06-27 18:39:12', NULL, NULL);
INSERT INTO public.ta_tags VALUES ('bounded-context', 41, '2026-06-27 18:39:12', '2026-06-27 18:39:12', NULL, NULL);
INSERT INTO public.ta_tags VALUES ('value-objects', 42, '2026-06-27 18:39:12', '2026-06-27 18:39:12', NULL, NULL);
INSERT INTO public.ta_tags VALUES ('design-patterns', 43, '2026-06-27 18:39:12', '2026-06-27 18:39:12', NULL, NULL);
INSERT INTO public.ta_tags VALUES ('hexagonal', 44, '2026-06-27 18:39:12', '2026-06-27 18:39:12', NULL, NULL);
INSERT INTO public.ta_tags VALUES ('clean-architecture', 45, '2026-06-27 18:39:12', '2026-06-27 18:39:12', NULL, NULL);
INSERT INTO public.ta_tags VALUES ('circuit-breaker', 46, '2026-06-27 18:39:12', '2026-06-27 18:39:12', NULL, NULL);
INSERT INTO public.ta_tags VALUES ('repository-pattern', 47, '2026-06-27 18:39:12', '2026-06-27 18:39:12', NULL, NULL);
INSERT INTO public.ta_tags VALUES ('factory-pattern', 48, '2026-06-27 18:39:12', '2026-06-27 18:39:12', NULL, NULL);
INSERT INTO public.ta_tags VALUES ('strategy-pattern', 49, '2026-06-27 18:39:12', '2026-06-27 18:39:12', NULL, NULL);
INSERT INTO public.ta_tags VALUES ('observer-pattern', 50, '2026-06-27 18:39:12', '2026-06-27 18:39:12', NULL, NULL);
INSERT INTO public.ta_tags VALUES ('dependency-injection', 51, '2026-06-27 18:39:12', '2026-06-27 18:39:12', NULL, NULL);
INSERT INTO public.ta_tags VALUES ('api-gateway', 52, '2026-06-27 18:39:12', '2026-06-27 18:39:12', NULL, NULL);


--
-- Data for Name: ar_article_dimension_content_excerpt_tags; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: ca_category_translations; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.ca_category_translations VALUES ('Distributed Systems', 'en', NULL, 6, '2026-06-27 18:39:12', '2026-06-27 18:39:12', 6, NULL, NULL);
INSERT INTO public.ca_category_translations VALUES ('Design Patterns', 'en', NULL, 7, '2026-06-27 18:39:12', '2026-06-27 18:39:12', 7, NULL, NULL);
INSERT INTO public.ca_category_translations VALUES ('Domain-Driven Design', 'en', NULL, 8, '2026-06-27 18:39:12', '2026-06-27 18:39:12', 8, NULL, NULL);
INSERT INTO public.ca_category_translations VALUES ('Architecture Styles', 'en', NULL, 9, '2026-06-27 18:39:12', '2026-06-27 18:39:12', 9, NULL, NULL);
INSERT INTO public.ca_category_translations VALUES ('Messaging Patterns', 'en', NULL, 10, '2026-06-27 18:39:12', '2026-06-27 18:39:12', 10, NULL, NULL);


--
-- Data for Name: ca_keywords; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: ca_category_translation_keywords; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: ca_category_translation_medias; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: co_accounts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: co_address_types; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.co_address_types VALUES ('sulu_contact.work', 1);
INSERT INTO public.co_address_types VALUES ('sulu_contact.private', 2);


--
-- Data for Name: co_addresses; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: co_account_addresses; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: co_bank_account; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: co_account_bank_accounts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: co_account_categories; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: co_positions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: co_account_contacts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: co_email_types; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.co_email_types VALUES ('sulu_contact.work', 1);
INSERT INTO public.co_email_types VALUES ('sulu_contact.private', 2);


--
-- Data for Name: co_emails; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: co_account_emails; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: co_fax_types; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.co_fax_types VALUES ('sulu_contact.work', 1);
INSERT INTO public.co_fax_types VALUES ('sulu_contact.private', 2);


--
-- Data for Name: co_faxes; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: co_account_faxes; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: co_account_medias; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: co_notes; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: co_account_notes; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: co_phone_types; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.co_phone_types VALUES ('sulu_contact.work', 1);
INSERT INTO public.co_phone_types VALUES ('sulu_contact.private', 2);
INSERT INTO public.co_phone_types VALUES ('sulu_contact.mobile', 3);


--
-- Data for Name: co_phones; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: co_account_phones; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: co_social_media_profile_types; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.co_social_media_profile_types VALUES ('Facebook', 1);
INSERT INTO public.co_social_media_profile_types VALUES ('Twitter', 2);
INSERT INTO public.co_social_media_profile_types VALUES ('Instagram', 3);


--
-- Data for Name: co_social_media_profiles; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: co_account_social_media_profiles; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: co_account_tags; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: co_url_types; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.co_url_types VALUES ('sulu_contact.work', 1);
INSERT INTO public.co_url_types VALUES ('sulu_contact.private', 2);


--
-- Data for Name: co_urls; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: co_account_urls; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: co_contact_addresses; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: co_contact_bank_accounts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: co_contact_categories; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: co_contact_emails; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: co_contact_faxes; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: co_contact_locales; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: co_contact_medias; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: co_contact_notes; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: co_contact_phones; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: co_contact_social_media_profiles; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: co_contact_tags; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: co_contact_urls; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: cu_custom_url; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: cu_custom_url_route; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: me_collection_meta; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.me_collection_meta VALUES ('System', NULL, 'en', 12, 7);
INSERT INTO public.me_collection_meta VALUES ('Sulu media', NULL, 'en', 13, 8);
INSERT INTO public.me_collection_meta VALUES ('Sulu Medien', NULL, 'de', 14, 8);
INSERT INTO public.me_collection_meta VALUES ('Preview images', NULL, 'en', 15, 9);
INSERT INTO public.me_collection_meta VALUES ('Vorschaubilder', NULL, 'de', 16, 9);
INSERT INTO public.me_collection_meta VALUES ('Sulu contacts', NULL, 'en', 17, 10);
INSERT INTO public.me_collection_meta VALUES ('Sulu Kontakte', NULL, 'de', 18, 10);
INSERT INTO public.me_collection_meta VALUES ('People', NULL, 'en', 19, 11);
INSERT INTO public.me_collection_meta VALUES ('Personen', NULL, 'de', 20, 11);
INSERT INTO public.me_collection_meta VALUES ('Organizations', NULL, 'en', 21, 12);
INSERT INTO public.me_collection_meta VALUES ('Organisationen', NULL, 'de', 22, 12);


--
-- Data for Name: me_file_version_meta; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: me_files; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: me_file_versions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: me_file_version_categories; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: me_file_version_tags; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: me_format_options; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: pa_pages; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.pa_pages VALUES ('architecture-hub', 2, 3, 1, '019f0a63-823f-7d92-94b7-223065cae0d8', '2026-06-27 18:42:01', '2026-06-27 18:42:01', '019f0a63-6686-71f2-a8c9-b4e7f0c6ff6e', NULL, NULL);
INSERT INTO public.pa_pages VALUES ('architecture-hub', 4, 5, 1, '019f0a63-826d-77e6-adcf-e37b657311ed', '2026-06-27 18:42:01', '2026-06-27 18:42:01', '019f0a63-6686-71f2-a8c9-b4e7f0c6ff6e', NULL, NULL);
INSERT INTO public.pa_pages VALUES ('architecture-hub', 6, 7, 1, '019f0a71-f47f-7c8e-9018-5bfe524ddb81', '2026-06-27 18:57:48', '2026-06-27 18:57:48', '019f0a63-6686-71f2-a8c9-b4e7f0c6ff6e', NULL, NULL);
INSERT INTO public.pa_pages VALUES ('architecture-hub', 8, 9, 1, '019f0a94-9d57-7cad-b9d7-fb66234cc944', '2026-06-27 19:35:39', '2026-06-27 19:35:39', '019f0a63-6686-71f2-a8c9-b4e7f0c6ff6e', NULL, NULL);
INSERT INTO public.pa_pages VALUES ('architecture-hub', 10, 11, 1, '019f0a94-9d85-74e2-9529-c565160fb66d', '2026-06-27 19:35:39', '2026-06-27 19:35:39', '019f0a63-6686-71f2-a8c9-b4e7f0c6ff6e', NULL, NULL);
INSERT INTO public.pa_pages VALUES ('architecture-hub', 12, 13, 1, '019f0a94-9daf-7dc1-b7cd-8354981cfe04', '2026-06-27 19:35:39', '2026-06-27 19:35:39', '019f0a63-6686-71f2-a8c9-b4e7f0c6ff6e', NULL, NULL);
INSERT INTO public.pa_pages VALUES ('architecture-hub', 1, 16, 0, '019f0a63-6686-71f2-a8c9-b4e7f0c6ff6e', '2026-06-27 18:41:54', '2026-06-27 18:41:54', NULL, NULL, NULL);
INSERT INTO public.pa_pages VALUES ('architecture-hub', 14, 15, 1, '019f0a94-9dd7-7c35-935d-5f56d43baf7e', '2026-06-27 19:35:39', '2026-06-27 19:35:39', '019f0a63-6686-71f2-a8c9-b4e7f0c6ff6e', NULL, NULL);


--
-- Data for Name: pa_page_dimension_contents; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.pa_page_dimension_contents VALUES (NULL, 7, 'draft', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:41:54', '2026-06-27 18:41:54', NULL, '019f0a63-6686-71f2-a8c9-b4e7f0c6ff6e', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES (NULL, 9, 'draft', NULL, 'en', '["en"]', 1782585714, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:41:54', '2026-06-27 18:41:54', NULL, '019f0a63-6686-71f2-a8c9-b4e7f0c6ff6e', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES ('Architecture Hub', 10, 'draft', 'en', NULL, NULL, 1782585714, NULL, NULL, 'homepage', '{"title": "Architecture Hub", "articles": null}', '[]', false, false, false, '[]', NULL, '2026-06-27 18:41:54', NULL, 'unpublished', NULL, NULL, NULL, '2026-06-27 18:41:54', '2026-06-27 18:41:54', NULL, '019f0a63-6686-71f2-a8c9-b4e7f0c6ff6e', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES (NULL, 11, 'live', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:41:54', '2026-06-27 18:41:54', NULL, '019f0a63-6686-71f2-a8c9-b4e7f0c6ff6e', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES ('Architecture Hub', 12, 'live', 'en', NULL, NULL, 0, NULL, NULL, 'homepage', '{"title": "Architecture Hub", "articles": null}', '[]', false, false, false, '[]', NULL, '2026-06-27 18:41:54', NULL, NULL, '2026-06-27 18:41:54', NULL, NULL, '2026-06-27 18:41:54', '2026-06-27 18:41:54', 2, '019f0a63-6686-71f2-a8c9-b4e7f0c6ff6e', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES ('Architecture Hub', 8, 'draft', 'en', NULL, NULL, 0, NULL, NULL, 'homepage', '{"title": "Architecture Hub", "articles": null}', '[]', false, false, false, '[]', NULL, '2026-06-27 18:41:54', NULL, 'published', '2026-06-27 18:41:54', NULL, NULL, '2026-06-27 18:41:54', '2026-06-27 18:41:54', 2, '019f0a63-6686-71f2-a8c9-b4e7f0c6ff6e', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES (NULL, 13, 'draft', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:01', '2026-06-27 18:42:01', NULL, '019f0a63-823f-7d92-94b7-223065cae0d8', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES (NULL, 15, 'draft', NULL, 'en', '["en"]', 1782585721, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:01', '2026-06-27 18:42:01', NULL, '019f0a63-823f-7d92-94b7-223065cae0d8', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES ('Adam Ministrator', 16, 'draft', 'en', NULL, NULL, 1782585721, NULL, NULL, 'author', '{"bio": "Adam builds distributed systems and obsesses over operational correctness. He writes about consistency models, distributed consensus, and the tradeoffs that matter at scale.", "photo": null, "title": "Adam Ministrator", "articles": [], "position": "Platform Architect"}', '[]', false, false, false, '[]', NULL, '2026-06-27 18:42:01', NULL, 'unpublished', NULL, NULL, NULL, '2026-06-27 18:42:01', '2026-06-27 18:42:01', NULL, '019f0a63-823f-7d92-94b7-223065cae0d8', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES (NULL, 17, 'live', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:01', '2026-06-27 18:42:01', NULL, '019f0a63-823f-7d92-94b7-223065cae0d8', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES (NULL, 19, 'draft', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:01', '2026-06-27 18:42:01', NULL, '019f0a63-826d-77e6-adcf-e37b657311ed', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES (NULL, 21, 'draft', NULL, 'en', '["en"]', 1782585721, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:01', '2026-06-27 18:42:01', NULL, '019f0a63-826d-77e6-adcf-e37b657311ed', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES ('Jane Kowalski', 22, 'draft', 'en', NULL, NULL, 1782585721, NULL, NULL, 'author', '{"bio": "Jane specialises in event-driven architecture and high-throughput data pipelines. She contributes to open-source tooling and writes about domain modelling and clean service boundaries.", "photo": null, "title": "Jane Kowalski", "articles": [], "position": "Backend Engineer"}', '[]', false, false, false, '[]', NULL, '2026-06-27 18:42:01', NULL, 'unpublished', NULL, NULL, NULL, '2026-06-27 18:42:01', '2026-06-27 18:42:01', NULL, '019f0a63-826d-77e6-adcf-e37b657311ed', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES (NULL, 23, 'live', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:42:01', '2026-06-27 18:42:01', NULL, '019f0a63-826d-77e6-adcf-e37b657311ed', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES (NULL, 25, 'draft', NULL, 'en', '["en"]', 1782585907, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:45:07', '2026-06-27 18:45:07', NULL, '019f0a63-823f-7d92-94b7-223065cae0d8', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES ('Adam Ministrator', 26, 'draft', 'en', NULL, NULL, 1782585907, NULL, NULL, 'author', '{"bio": "Adam builds distributed systems and obsesses over operational correctness. He writes about consistency models, distributed consensus, and the tradeoffs that matter at scale.", "photo": null, "title": "Adam Ministrator", "articles": ["019f0a63-7da5-7277-98ce-4c75280acfbf", "019f0a63-7eec-7e3e-922e-19b253d0ba27", "019f0a63-7f3b-7053-816a-4e409ce7fff1", "019f0a63-7f89-7c70-83fa-c4d99f423e05", "019f0a63-7fe7-7f84-9b23-0603fcc7155e", "019f0a63-803d-758c-a68a-55f5ee38d8b5", "019f0a63-80a8-73fa-ad9e-30557ace8490", "019f0a63-811e-7863-bee3-31d130b66430", "019f0a63-8184-76a6-979c-4683b7807a4f", "019f0a63-81dc-7e9b-9d96-64555bce8199"], "position": "Platform Architect"}', '[]', false, false, false, '[]', NULL, '2026-06-27 18:42:01', NULL, 'unpublished', NULL, NULL, NULL, '2026-06-27 18:45:07', '2026-06-27 18:45:07', NULL, '019f0a63-823f-7d92-94b7-223065cae0d8', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES ('Adam Ministrator', 14, 'draft', 'en', NULL, NULL, 0, NULL, NULL, 'author', '{"bio": "Adam builds distributed systems and obsesses over operational correctness. He writes about consistency models, distributed consensus, and the tradeoffs that matter at scale.", "photo": null, "title": "Adam Ministrator", "articles": ["019f0a63-7da5-7277-98ce-4c75280acfbf", "019f0a63-7eec-7e3e-922e-19b253d0ba27", "019f0a63-7f3b-7053-816a-4e409ce7fff1", "019f0a63-7f89-7c70-83fa-c4d99f423e05", "019f0a63-7fe7-7f84-9b23-0603fcc7155e", "019f0a63-803d-758c-a68a-55f5ee38d8b5", "019f0a63-80a8-73fa-ad9e-30557ace8490", "019f0a63-811e-7863-bee3-31d130b66430", "019f0a63-8184-76a6-979c-4683b7807a4f", "019f0a63-81dc-7e9b-9d96-64555bce8199"], "position": "Platform Architect"}', '[]', false, false, false, '[]', NULL, '2026-06-27 18:42:01', NULL, 'published', '2026-06-27 18:42:01', NULL, NULL, '2026-06-27 18:42:01', '2026-06-27 18:45:07', 23, '019f0a63-823f-7d92-94b7-223065cae0d8', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES ('Adam Ministrator', 18, 'live', 'en', NULL, NULL, 0, NULL, NULL, 'author', '{"bio": "Adam builds distributed systems and obsesses over operational correctness. He writes about consistency models, distributed consensus, and the tradeoffs that matter at scale.", "photo": null, "title": "Adam Ministrator", "articles": ["019f0a63-7da5-7277-98ce-4c75280acfbf", "019f0a63-7eec-7e3e-922e-19b253d0ba27", "019f0a63-7f3b-7053-816a-4e409ce7fff1", "019f0a63-7f89-7c70-83fa-c4d99f423e05", "019f0a63-7fe7-7f84-9b23-0603fcc7155e", "019f0a63-803d-758c-a68a-55f5ee38d8b5", "019f0a63-80a8-73fa-ad9e-30557ace8490", "019f0a63-811e-7863-bee3-31d130b66430", "019f0a63-8184-76a6-979c-4683b7807a4f", "019f0a63-81dc-7e9b-9d96-64555bce8199"], "position": "Platform Architect"}', '[]', false, false, false, '[]', NULL, '2026-06-27 18:42:01', NULL, NULL, '2026-06-27 18:42:01', NULL, NULL, '2026-06-27 18:42:01', '2026-06-27 18:45:07', 23, '019f0a63-823f-7d92-94b7-223065cae0d8', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES (NULL, 27, 'draft', NULL, 'en', '["en"]', 1782585907, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:45:07', '2026-06-27 18:45:07', NULL, '019f0a63-826d-77e6-adcf-e37b657311ed', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES ('Jane Kowalski', 28, 'draft', 'en', NULL, NULL, 1782585907, NULL, NULL, 'author', '{"bio": "Jane specialises in event-driven architecture and high-throughput data pipelines. She contributes to open-source tooling and writes about domain modelling and clean service boundaries.", "photo": null, "title": "Jane Kowalski", "articles": ["019f0a63-7ec1-797f-9a50-9fd0ee001098", "019f0a63-7f13-76a6-9820-09063579be68", "019f0a63-7f62-72e1-8f42-8c89ac4ed8c8", "019f0a63-7fba-7c70-b040-3e7e9ce94909", "019f0a63-8011-7c5b-9a45-6195911b5536", "019f0a63-806b-75d3-9bb4-31d0fdf95812", "019f0a63-80e4-7806-83b8-8991df317fa6", "019f0a63-8150-7804-9c6f-f6c154f95cd1", "019f0a63-81b0-7060-8257-0ddd2bb95a71", "019f0a63-820c-7902-9100-98c04b1f89bd"], "position": "Backend Engineer"}', '[]', false, false, false, '[]', NULL, '2026-06-27 18:42:01', NULL, 'unpublished', NULL, NULL, NULL, '2026-06-27 18:45:07', '2026-06-27 18:45:07', NULL, '019f0a63-826d-77e6-adcf-e37b657311ed', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES (NULL, 29, 'draft', NULL, 'en', '["en"]', 1782586668, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:57:48', '2026-06-27 18:57:48', NULL, '019f0a63-826d-77e6-adcf-e37b657311ed', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES ('Jane Kowalski', 30, 'draft', 'en', NULL, NULL, 1782586668, NULL, NULL, 'author', '{"bio": "Jane specialises in event-driven architecture and high-throughput data pipelines. She contributes to open-source tooling and writes about domain modelling and clean service boundaries.", "photo": null, "title": "Jane Kowalski", "articles": ["019f0a63-7ec1-797f-9a50-9fd0ee001098", "019f0a63-7f13-76a6-9820-09063579be68", "019f0a63-7f62-72e1-8f42-8c89ac4ed8c8", "019f0a63-7fba-7c70-b040-3e7e9ce94909", "019f0a63-8011-7c5b-9a45-6195911b5536", "019f0a63-806b-75d3-9bb4-31d0fdf95812", "019f0a63-80e4-7806-83b8-8991df317fa6", "019f0a63-8150-7804-9c6f-f6c154f95cd1", "019f0a63-81b0-7060-8257-0ddd2bb95a71", "019f0a63-820c-7902-9100-98c04b1f89bd"], "position": "Backend Engineer"}', '[]', false, false, false, '[]', NULL, '2026-06-27 18:42:01', NULL, 'unpublished', NULL, NULL, NULL, '2026-06-27 18:57:48', '2026-06-27 18:57:48', NULL, '019f0a63-826d-77e6-adcf-e37b657311ed', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES ('Distributed Systems Fundamentals', 46, 'live', 'en', NULL, NULL, 0, NULL, NULL, 'learning-path', '{"title": "Distributed Systems Fundamentals", "articles": ["019f0a63-7da5-7277-98ce-4c75280acfbf", "019f0a63-7ec1-797f-9a50-9fd0ee001098", "019f0a63-80e4-7806-83b8-8991df317fa6", "019f0a63-80a8-73fa-ad9e-30557ace8490", "019f0a63-811e-7863-bee3-31d130b66430"], "description": "Master the core concepts behind reliable distributed systems — from consistency guarantees and failure handling to messaging patterns that keep services in sync."}', '[]', false, false, false, '[]', NULL, '2026-06-27 19:35:39', NULL, NULL, '2026-06-27 19:35:39', NULL, NULL, '2026-06-27 19:35:39', '2026-06-27 19:35:39', 26, '019f0a94-9d57-7cad-b9d7-fb66234cc944', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES ('Distributed Systems Fundamentals', 42, 'draft', 'en', NULL, NULL, 0, NULL, NULL, 'learning-path', '{"title": "Distributed Systems Fundamentals", "articles": ["019f0a63-7da5-7277-98ce-4c75280acfbf", "019f0a63-7ec1-797f-9a50-9fd0ee001098", "019f0a63-80e4-7806-83b8-8991df317fa6", "019f0a63-80a8-73fa-ad9e-30557ace8490", "019f0a63-811e-7863-bee3-31d130b66430"], "description": "Master the core concepts behind reliable distributed systems — from consistency guarantees and failure handling to messaging patterns that keep services in sync."}', '[]', false, false, false, '[]', NULL, '2026-06-27 19:35:39', NULL, 'published', '2026-06-27 19:35:39', NULL, NULL, '2026-06-27 19:35:39', '2026-06-27 19:35:39', 26, '019f0a94-9d57-7cad-b9d7-fb66234cc944', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES (NULL, 47, 'draft', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 19:35:39', '2026-06-27 19:35:39', NULL, '019f0a94-9d85-74e2-9529-c565160fb66d', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES (NULL, 49, 'draft', NULL, 'en', '["en"]', 1782588939, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 19:35:39', '2026-06-27 19:35:39', NULL, '019f0a94-9d85-74e2-9529-c565160fb66d', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES ('Domain-Driven Design', 50, 'draft', 'en', NULL, NULL, 1782588939, NULL, NULL, 'learning-path', '{"title": "Domain-Driven Design", "articles": ["019f0a63-7eec-7e3e-922e-19b253d0ba27", "019f0a63-7f13-76a6-9820-09063579be68", "019f0a63-7f3b-7053-816a-4e409ce7fff1", "019f0a63-7f62-72e1-8f42-8c89ac4ed8c8", "019f0a63-7f89-7c70-83fa-c4d99f423e05", "019f0a63-8150-7804-9c6f-f6c154f95cd1"], "description": "Learn to model complex domains with precision. Covers strategic design, aggregates, value objects, CQRS, event sourcing, and the repository pattern."}', '[]', false, false, false, '[]', NULL, '2026-06-27 19:35:39', NULL, 'unpublished', NULL, NULL, NULL, '2026-06-27 19:35:39', '2026-06-27 19:35:39', NULL, '019f0a94-9d85-74e2-9529-c565160fb66d', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES (NULL, 51, 'live', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 19:35:39', '2026-06-27 19:35:39', NULL, '019f0a94-9d85-74e2-9529-c565160fb66d', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES (NULL, 31, 'draft', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:57:48', '2026-06-27 18:57:48', NULL, '019f0a71-f47f-7c8e-9018-5bfe524ddb81', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES (NULL, 33, 'draft', NULL, 'en', '["en"]', 1782586668, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:57:48', '2026-06-27 18:57:48', NULL, '019f0a71-f47f-7c8e-9018-5bfe524ddb81', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES ('Authors', 34, 'draft', 'en', NULL, NULL, 1782586668, NULL, NULL, 'authors', '{"title": "Authors", "authors": ["019f0a63-823f-7d92-94b7-223065cae0d8", "019f0a63-826d-77e6-adcf-e37b657311ed"]}', '[]', false, false, false, '[]', NULL, '2026-06-27 18:57:48', NULL, 'unpublished', NULL, NULL, NULL, '2026-06-27 18:57:48', '2026-06-27 18:57:48', NULL, '019f0a71-f47f-7c8e-9018-5bfe524ddb81', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES (NULL, 35, 'live', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 18:57:48', '2026-06-27 18:57:48', NULL, '019f0a71-f47f-7c8e-9018-5bfe524ddb81', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES (NULL, 37, 'draft', NULL, 'en', '["en"]', 1782588939, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 19:35:39', '2026-06-27 19:35:39', NULL, '019f0a63-826d-77e6-adcf-e37b657311ed', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES ('Jane Kowalski', 38, 'draft', 'en', NULL, NULL, 1782588939, NULL, NULL, 'author', '{"bio": "Jane specialises in event-driven architecture and high-throughput data pipelines. She contributes to open-source tooling and writes about domain modelling and clean service boundaries.", "photo": null, "title": "Jane Kowalski", "articles": ["019f0a63-7ec1-797f-9a50-9fd0ee001098", "019f0a63-7f13-76a6-9820-09063579be68", "019f0a63-7f62-72e1-8f42-8c89ac4ed8c8", "019f0a63-7fba-7c70-b040-3e7e9ce94909", "019f0a63-8011-7c5b-9a45-6195911b5536", "019f0a63-806b-75d3-9bb4-31d0fdf95812", "019f0a63-80e4-7806-83b8-8991df317fa6", "019f0a63-8150-7804-9c6f-f6c154f95cd1", "019f0a63-81b0-7060-8257-0ddd2bb95a71", "019f0a63-820c-7902-9100-98c04b1f89bd"], "position": "Backend Engineer"}', '[]', false, false, false, '[]', NULL, '2026-06-27 18:42:01', NULL, 'unpublished', NULL, NULL, NULL, '2026-06-27 19:35:39', '2026-06-27 19:35:39', NULL, '019f0a63-826d-77e6-adcf-e37b657311ed', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES ('Jane Kowalski', 20, 'draft', 'en', NULL, NULL, 0, NULL, NULL, 'author', '{"bio": "Jane specialises in event-driven architecture and high-throughput data pipelines. She contributes to open-source tooling and writes about domain modelling and clean service boundaries.", "photo": null, "title": "Jane Kowalski", "articles": ["019f0a63-7ec1-797f-9a50-9fd0ee001098", "019f0a63-7f13-76a6-9820-09063579be68", "019f0a63-7f62-72e1-8f42-8c89ac4ed8c8", "019f0a63-7fba-7c70-b040-3e7e9ce94909", "019f0a63-8011-7c5b-9a45-6195911b5536", "019f0a63-806b-75d3-9bb4-31d0fdf95812", "019f0a63-80e4-7806-83b8-8991df317fa6", "019f0a63-8150-7804-9c6f-f6c154f95cd1", "019f0a63-81b0-7060-8257-0ddd2bb95a71", "019f0a63-820c-7902-9100-98c04b1f89bd"], "position": "Backend Engineer"}', '[]', false, false, false, '[]', NULL, '2026-06-27 18:42:01', NULL, 'published', '2026-06-27 18:42:01', NULL, NULL, '2026-06-27 18:42:01', '2026-06-27 19:35:39', 24, '019f0a63-826d-77e6-adcf-e37b657311ed', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES ('Jane Kowalski', 24, 'live', 'en', NULL, NULL, 0, NULL, NULL, 'author', '{"bio": "Jane specialises in event-driven architecture and high-throughput data pipelines. She contributes to open-source tooling and writes about domain modelling and clean service boundaries.", "photo": null, "title": "Jane Kowalski", "articles": ["019f0a63-7ec1-797f-9a50-9fd0ee001098", "019f0a63-7f13-76a6-9820-09063579be68", "019f0a63-7f62-72e1-8f42-8c89ac4ed8c8", "019f0a63-7fba-7c70-b040-3e7e9ce94909", "019f0a63-8011-7c5b-9a45-6195911b5536", "019f0a63-806b-75d3-9bb4-31d0fdf95812", "019f0a63-80e4-7806-83b8-8991df317fa6", "019f0a63-8150-7804-9c6f-f6c154f95cd1", "019f0a63-81b0-7060-8257-0ddd2bb95a71", "019f0a63-820c-7902-9100-98c04b1f89bd"], "position": "Backend Engineer"}', '[]', false, false, false, '[]', NULL, '2026-06-27 18:42:01', NULL, NULL, '2026-06-27 18:42:01', NULL, NULL, '2026-06-27 18:42:01', '2026-06-27 19:35:39', 24, '019f0a63-826d-77e6-adcf-e37b657311ed', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES (NULL, 39, 'draft', NULL, 'en', '["en"]', 1782588939, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 19:35:39', '2026-06-27 19:35:39', NULL, '019f0a71-f47f-7c8e-9018-5bfe524ddb81', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES ('Authors', 40, 'draft', 'en', NULL, NULL, 1782588939, NULL, NULL, 'authors', '{"title": "Authors", "authors": ["019f0a63-823f-7d92-94b7-223065cae0d8", "019f0a63-826d-77e6-adcf-e37b657311ed"]}', '[]', false, false, false, '[]', NULL, '2026-06-27 18:57:48', NULL, 'unpublished', NULL, NULL, NULL, '2026-06-27 19:35:39', '2026-06-27 19:35:39', NULL, '019f0a71-f47f-7c8e-9018-5bfe524ddb81', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES ('Authors', 36, 'live', 'en', NULL, NULL, 0, NULL, NULL, 'authors', '{"title": "Authors", "authors": ["019f0a63-823f-7d92-94b7-223065cae0d8", "019f0a63-826d-77e6-adcf-e37b657311ed"]}', '[]', false, false, false, '[]', NULL, '2026-06-27 18:57:48', NULL, NULL, '2026-06-27 18:57:48', NULL, NULL, '2026-06-27 18:57:48', '2026-06-27 19:35:39', 25, '019f0a71-f47f-7c8e-9018-5bfe524ddb81', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES ('Authors', 32, 'draft', 'en', NULL, NULL, 0, NULL, NULL, 'authors', '{"title": "Authors", "authors": ["019f0a63-823f-7d92-94b7-223065cae0d8", "019f0a63-826d-77e6-adcf-e37b657311ed"]}', '[]', false, false, false, '[]', NULL, '2026-06-27 18:57:48', NULL, 'published', '2026-06-27 18:57:48', NULL, NULL, '2026-06-27 18:57:48', '2026-06-27 19:35:39', 25, '019f0a71-f47f-7c8e-9018-5bfe524ddb81', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES (NULL, 41, 'draft', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 19:35:39', '2026-06-27 19:35:39', NULL, '019f0a94-9d57-7cad-b9d7-fb66234cc944', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES (NULL, 43, 'draft', NULL, 'en', '["en"]', 1782588939, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 19:35:39', '2026-06-27 19:35:39', NULL, '019f0a94-9d57-7cad-b9d7-fb66234cc944', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES ('Distributed Systems Fundamentals', 44, 'draft', 'en', NULL, NULL, 1782588939, NULL, NULL, 'learning-path', '{"title": "Distributed Systems Fundamentals", "articles": ["019f0a63-7da5-7277-98ce-4c75280acfbf", "019f0a63-7ec1-797f-9a50-9fd0ee001098", "019f0a63-80e4-7806-83b8-8991df317fa6", "019f0a63-80a8-73fa-ad9e-30557ace8490", "019f0a63-811e-7863-bee3-31d130b66430"], "description": "Master the core concepts behind reliable distributed systems — from consistency guarantees and failure handling to messaging patterns that keep services in sync."}', '[]', false, false, false, '[]', NULL, '2026-06-27 19:35:39', NULL, 'unpublished', NULL, NULL, NULL, '2026-06-27 19:35:39', '2026-06-27 19:35:39', NULL, '019f0a94-9d57-7cad-b9d7-fb66234cc944', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES (NULL, 45, 'live', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 19:35:39', '2026-06-27 19:35:39', NULL, '019f0a94-9d57-7cad-b9d7-fb66234cc944', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES ('Domain-Driven Design', 52, 'live', 'en', NULL, NULL, 0, NULL, NULL, 'learning-path', '{"title": "Domain-Driven Design", "articles": ["019f0a63-7eec-7e3e-922e-19b253d0ba27", "019f0a63-7f13-76a6-9820-09063579be68", "019f0a63-7f3b-7053-816a-4e409ce7fff1", "019f0a63-7f62-72e1-8f42-8c89ac4ed8c8", "019f0a63-7f89-7c70-83fa-c4d99f423e05", "019f0a63-8150-7804-9c6f-f6c154f95cd1"], "description": "Learn to model complex domains with precision. Covers strategic design, aggregates, value objects, CQRS, event sourcing, and the repository pattern."}', '[]', false, false, false, '[]', NULL, '2026-06-27 19:35:39', NULL, NULL, '2026-06-27 19:35:39', NULL, NULL, '2026-06-27 19:35:39', '2026-06-27 19:35:39', 27, '019f0a94-9d85-74e2-9529-c565160fb66d', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES ('Domain-Driven Design', 48, 'draft', 'en', NULL, NULL, 0, NULL, NULL, 'learning-path', '{"title": "Domain-Driven Design", "articles": ["019f0a63-7eec-7e3e-922e-19b253d0ba27", "019f0a63-7f13-76a6-9820-09063579be68", "019f0a63-7f3b-7053-816a-4e409ce7fff1", "019f0a63-7f62-72e1-8f42-8c89ac4ed8c8", "019f0a63-7f89-7c70-83fa-c4d99f423e05", "019f0a63-8150-7804-9c6f-f6c154f95cd1"], "description": "Learn to model complex domains with precision. Covers strategic design, aggregates, value objects, CQRS, event sourcing, and the repository pattern."}', '[]', false, false, false, '[]', NULL, '2026-06-27 19:35:39', NULL, 'published', '2026-06-27 19:35:39', NULL, NULL, '2026-06-27 19:35:39', '2026-06-27 19:35:39', 27, '019f0a94-9d85-74e2-9529-c565160fb66d', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES (NULL, 53, 'draft', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 19:35:39', '2026-06-27 19:35:39', NULL, '019f0a94-9daf-7dc1-b7cd-8354981cfe04', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES (NULL, 55, 'draft', NULL, 'en', '["en"]', 1782588939, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 19:35:39', '2026-06-27 19:35:39', NULL, '019f0a94-9daf-7dc1-b7cd-8354981cfe04', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES ('Architecture Patterns', 56, 'draft', 'en', NULL, NULL, 1782588939, NULL, NULL, 'learning-path', '{"title": "Architecture Patterns", "articles": ["019f0a63-7fe7-7f84-9b23-0603fcc7155e", "019f0a63-8011-7c5b-9a45-6195911b5536", "019f0a63-7fba-7c70-b040-3e7e9ce94909", "019f0a63-803d-758c-a68a-55f5ee38d8b5", "019f0a63-806b-75d3-9bb4-31d0fdf95812"], "description": "A tour of the structural patterns that keep large systems maintainable — from hexagonal architecture and clean code to microservices decomposition."}', '[]', false, false, false, '[]', NULL, '2026-06-27 19:35:39', NULL, 'unpublished', NULL, NULL, NULL, '2026-06-27 19:35:39', '2026-06-27 19:35:39', NULL, '019f0a94-9daf-7dc1-b7cd-8354981cfe04', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES (NULL, 57, 'live', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 19:35:39', '2026-06-27 19:35:39', NULL, '019f0a94-9daf-7dc1-b7cd-8354981cfe04', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES ('Architecture Patterns', 58, 'live', 'en', NULL, NULL, 0, NULL, NULL, 'learning-path', '{"title": "Architecture Patterns", "articles": ["019f0a63-7fe7-7f84-9b23-0603fcc7155e", "019f0a63-8011-7c5b-9a45-6195911b5536", "019f0a63-7fba-7c70-b040-3e7e9ce94909", "019f0a63-803d-758c-a68a-55f5ee38d8b5", "019f0a63-806b-75d3-9bb4-31d0fdf95812"], "description": "A tour of the structural patterns that keep large systems maintainable — from hexagonal architecture and clean code to microservices decomposition."}', '[]', false, false, false, '[]', NULL, '2026-06-27 19:35:39', NULL, NULL, '2026-06-27 19:35:39', NULL, NULL, '2026-06-27 19:35:39', '2026-06-27 19:35:39', 28, '019f0a94-9daf-7dc1-b7cd-8354981cfe04', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES ('Architecture Patterns', 54, 'draft', 'en', NULL, NULL, 0, NULL, NULL, 'learning-path', '{"title": "Architecture Patterns", "articles": ["019f0a63-7fe7-7f84-9b23-0603fcc7155e", "019f0a63-8011-7c5b-9a45-6195911b5536", "019f0a63-7fba-7c70-b040-3e7e9ce94909", "019f0a63-803d-758c-a68a-55f5ee38d8b5", "019f0a63-806b-75d3-9bb4-31d0fdf95812"], "description": "A tour of the structural patterns that keep large systems maintainable — from hexagonal architecture and clean code to microservices decomposition."}', '[]', false, false, false, '[]', NULL, '2026-06-27 19:35:39', NULL, 'published', '2026-06-27 19:35:39', NULL, NULL, '2026-06-27 19:35:39', '2026-06-27 19:35:39', 28, '019f0a94-9daf-7dc1-b7cd-8354981cfe04', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES (NULL, 59, 'draft', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 19:35:39', '2026-06-27 19:35:39', NULL, '019f0a94-9dd7-7c35-935d-5f56d43baf7e', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES (NULL, 61, 'draft', NULL, 'en', '["en"]', 1782588939, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 19:35:39', '2026-06-27 19:35:39', NULL, '019f0a94-9dd7-7c35-935d-5f56d43baf7e', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES ('Learning Paths', 62, 'draft', 'en', NULL, NULL, 1782588939, NULL, NULL, 'learning-paths', '{"paths": ["019f0a94-9d57-7cad-b9d7-fb66234cc944", "019f0a94-9d85-74e2-9529-c565160fb66d", "019f0a94-9daf-7dc1-b7cd-8354981cfe04"], "title": "Learning Paths"}', '[]', false, false, false, '[]', NULL, '2026-06-27 19:35:39', NULL, 'unpublished', NULL, NULL, NULL, '2026-06-27 19:35:39', '2026-06-27 19:35:39', NULL, '019f0a94-9dd7-7c35-935d-5f56d43baf7e', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES (NULL, 63, 'live', NULL, 'en', '["en"]', 0, NULL, NULL, NULL, '[]', '[]', false, false, false, '[]', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 19:35:39', '2026-06-27 19:35:39', NULL, '019f0a94-9dd7-7c35-935d-5f56d43baf7e', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES ('Learning Paths', 64, 'live', 'en', NULL, NULL, 0, NULL, NULL, 'learning-paths', '{"paths": ["019f0a94-9d57-7cad-b9d7-fb66234cc944", "019f0a94-9d85-74e2-9529-c565160fb66d", "019f0a94-9daf-7dc1-b7cd-8354981cfe04"], "title": "Learning Paths"}', '[]', false, false, false, '[]', NULL, '2026-06-27 19:35:39', NULL, NULL, '2026-06-27 19:35:39', NULL, NULL, '2026-06-27 19:35:39', '2026-06-27 19:35:39', 29, '019f0a94-9dd7-7c35-935d-5f56d43baf7e', NULL, NULL, NULL);
INSERT INTO public.pa_page_dimension_contents VALUES ('Learning Paths', 60, 'draft', 'en', NULL, NULL, 0, NULL, NULL, 'learning-paths', '{"paths": ["019f0a94-9d57-7cad-b9d7-fb66234cc944", "019f0a94-9d85-74e2-9529-c565160fb66d", "019f0a94-9daf-7dc1-b7cd-8354981cfe04"], "title": "Learning Paths"}', '[]', false, false, false, '[]', NULL, '2026-06-27 19:35:39', NULL, 'published', '2026-06-27 19:35:39', NULL, NULL, '2026-06-27 19:35:39', '2026-06-27 19:35:39', 29, '019f0a94-9dd7-7c35-935d-5f56d43baf7e', NULL, NULL, NULL);


--
-- Data for Name: pa_page_dimension_content_excerpt_categories; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: pa_page_dimension_content_excerpt_tags; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: pa_page_dimension_content_navigation_contexts; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.pa_page_dimension_content_navigation_contexts VALUES ('main', 1, 12);
INSERT INTO public.pa_page_dimension_content_navigation_contexts VALUES ('main', 2, 36);
INSERT INTO public.pa_page_dimension_content_navigation_contexts VALUES ('main', 3, 64);


--
-- Data for Name: pr_preview_links; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: re_references; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.re_references VALUES ('contacts', '4', 'articles', '019f0a63-7da5-7277-98ce-4c75280acfbf', 'en', '{"locale": "en"}', 'Understanding the CAP Theorem', 'author', 'live', 8, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('categories', '6', 'articles', '019f0a63-7da5-7277-98ce-4c75280acfbf', 'en', '{"locale": "en"}', 'Understanding the CAP Theorem', 'categories', 'live', 9, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '27', 'articles', '019f0a63-7da5-7277-98ce-4c75280acfbf', 'en', '{"locale": "en"}', 'Understanding the CAP Theorem', 'tags', 'live', 10, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '28', 'articles', '019f0a63-7da5-7277-98ce-4c75280acfbf', 'en', '{"locale": "en"}', 'Understanding the CAP Theorem', 'tags', 'live', 11, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '29', 'articles', '019f0a63-7da5-7277-98ce-4c75280acfbf', 'en', '{"locale": "en"}', 'Understanding the CAP Theorem', 'tags', 'live', 12, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '30', 'articles', '019f0a63-7da5-7277-98ce-4c75280acfbf', 'en', '{"locale": "en"}', 'Understanding the CAP Theorem', 'tags', 'live', 13, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('users', '4', 'articles', '019f0a63-7da5-7277-98ce-4c75280acfbf', 'en', '{"locale": "en"}', 'Understanding the CAP Theorem', 'settings.author', 'live', 14, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('contacts', '4', 'articles', '019f0a63-7da5-7277-98ce-4c75280acfbf', 'en', '{"locale": "en"}', 'Understanding the CAP Theorem', 'author', 'draft', 15, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('categories', '6', 'articles', '019f0a63-7da5-7277-98ce-4c75280acfbf', 'en', '{"locale": "en"}', 'Understanding the CAP Theorem', 'categories', 'draft', 16, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '27', 'articles', '019f0a63-7da5-7277-98ce-4c75280acfbf', 'en', '{"locale": "en"}', 'Understanding the CAP Theorem', 'tags', 'draft', 17, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '28', 'articles', '019f0a63-7da5-7277-98ce-4c75280acfbf', 'en', '{"locale": "en"}', 'Understanding the CAP Theorem', 'tags', 'draft', 18, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '29', 'articles', '019f0a63-7da5-7277-98ce-4c75280acfbf', 'en', '{"locale": "en"}', 'Understanding the CAP Theorem', 'tags', 'draft', 19, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '30', 'articles', '019f0a63-7da5-7277-98ce-4c75280acfbf', 'en', '{"locale": "en"}', 'Understanding the CAP Theorem', 'tags', 'draft', 20, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('users', '4', 'articles', '019f0a63-7da5-7277-98ce-4c75280acfbf', 'en', '{"locale": "en"}', 'Understanding the CAP Theorem', 'settings.author', 'draft', 21, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-7da5-7277-98ce-4c75280acfbf', 'pages', '019f0a63-823f-7d92-94b7-223065cae0d8', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Adam Ministrator', 'articles', 'draft', 356, '2026-06-27 18:45:07', '2026-06-27 18:45:07');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-7eec-7e3e-922e-19b253d0ba27', 'pages', '019f0a63-823f-7d92-94b7-223065cae0d8', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Adam Ministrator', 'articles', 'draft', 357, '2026-06-27 18:45:07', '2026-06-27 18:45:07');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-7f3b-7053-816a-4e409ce7fff1', 'pages', '019f0a63-823f-7d92-94b7-223065cae0d8', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Adam Ministrator', 'articles', 'draft', 358, '2026-06-27 18:45:07', '2026-06-27 18:45:07');
INSERT INTO public.re_references VALUES ('contacts', '3', 'articles', '019f0a63-7ec1-797f-9a50-9fd0ee001098', 'en', '{"locale": "en"}', 'Eventual Consistency in Practice', 'author', 'live', 28, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('categories', '6', 'articles', '019f0a63-7ec1-797f-9a50-9fd0ee001098', 'en', '{"locale": "en"}', 'Eventual Consistency in Practice', 'categories', 'live', 29, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '28', 'articles', '019f0a63-7ec1-797f-9a50-9fd0ee001098', 'en', '{"locale": "en"}', 'Eventual Consistency in Practice', 'tags', 'live', 30, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '38', 'articles', '019f0a63-7ec1-797f-9a50-9fd0ee001098', 'en', '{"locale": "en"}', 'Eventual Consistency in Practice', 'tags', 'live', 31, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '31', 'articles', '019f0a63-7ec1-797f-9a50-9fd0ee001098', 'en', '{"locale": "en"}', 'Eventual Consistency in Practice', 'tags', 'live', 32, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('users', '3', 'articles', '019f0a63-7ec1-797f-9a50-9fd0ee001098', 'en', '{"locale": "en"}', 'Eventual Consistency in Practice', 'settings.author', 'live', 33, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('contacts', '3', 'articles', '019f0a63-7ec1-797f-9a50-9fd0ee001098', 'en', '{"locale": "en"}', 'Eventual Consistency in Practice', 'author', 'draft', 34, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('categories', '6', 'articles', '019f0a63-7ec1-797f-9a50-9fd0ee001098', 'en', '{"locale": "en"}', 'Eventual Consistency in Practice', 'categories', 'draft', 35, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '28', 'articles', '019f0a63-7ec1-797f-9a50-9fd0ee001098', 'en', '{"locale": "en"}', 'Eventual Consistency in Practice', 'tags', 'draft', 36, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '38', 'articles', '019f0a63-7ec1-797f-9a50-9fd0ee001098', 'en', '{"locale": "en"}', 'Eventual Consistency in Practice', 'tags', 'draft', 37, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '31', 'articles', '019f0a63-7ec1-797f-9a50-9fd0ee001098', 'en', '{"locale": "en"}', 'Eventual Consistency in Practice', 'tags', 'draft', 38, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('users', '3', 'articles', '019f0a63-7ec1-797f-9a50-9fd0ee001098', 'en', '{"locale": "en"}', 'Eventual Consistency in Practice', 'settings.author', 'draft', 39, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-7f89-7c70-83fa-c4d99f423e05', 'pages', '019f0a63-823f-7d92-94b7-223065cae0d8', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Adam Ministrator', 'articles', 'draft', 359, '2026-06-27 18:45:07', '2026-06-27 18:45:07');
INSERT INTO public.re_references VALUES ('contacts', '4', 'articles', '019f0a63-7eec-7e3e-922e-19b253d0ba27', 'en', '{"locale": "en"}', 'Domain-Driven Design: Strategic Patterns', 'author', 'live', 45, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('categories', '8', 'articles', '019f0a63-7eec-7e3e-922e-19b253d0ba27', 'en', '{"locale": "en"}', 'Domain-Driven Design: Strategic Patterns', 'categories', 'live', 46, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '39', 'articles', '019f0a63-7eec-7e3e-922e-19b253d0ba27', 'en', '{"locale": "en"}', 'Domain-Driven Design: Strategic Patterns', 'tags', 'live', 47, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '41', 'articles', '019f0a63-7eec-7e3e-922e-19b253d0ba27', 'en', '{"locale": "en"}', 'Domain-Driven Design: Strategic Patterns', 'tags', 'live', 48, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('users', '4', 'articles', '019f0a63-7eec-7e3e-922e-19b253d0ba27', 'en', '{"locale": "en"}', 'Domain-Driven Design: Strategic Patterns', 'settings.author', 'live', 49, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('contacts', '4', 'articles', '019f0a63-7eec-7e3e-922e-19b253d0ba27', 'en', '{"locale": "en"}', 'Domain-Driven Design: Strategic Patterns', 'author', 'draft', 50, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('categories', '8', 'articles', '019f0a63-7eec-7e3e-922e-19b253d0ba27', 'en', '{"locale": "en"}', 'Domain-Driven Design: Strategic Patterns', 'categories', 'draft', 51, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '39', 'articles', '019f0a63-7eec-7e3e-922e-19b253d0ba27', 'en', '{"locale": "en"}', 'Domain-Driven Design: Strategic Patterns', 'tags', 'draft', 52, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '41', 'articles', '019f0a63-7eec-7e3e-922e-19b253d0ba27', 'en', '{"locale": "en"}', 'Domain-Driven Design: Strategic Patterns', 'tags', 'draft', 53, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('users', '4', 'articles', '019f0a63-7eec-7e3e-922e-19b253d0ba27', 'en', '{"locale": "en"}', 'Domain-Driven Design: Strategic Patterns', 'settings.author', 'draft', 54, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-7fe7-7f84-9b23-0603fcc7155e', 'pages', '019f0a63-823f-7d92-94b7-223065cae0d8', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Adam Ministrator', 'articles', 'draft', 360, '2026-06-27 18:45:07', '2026-06-27 18:45:07');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-803d-758c-a68a-55f5ee38d8b5', 'pages', '019f0a63-823f-7d92-94b7-223065cae0d8', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Adam Ministrator', 'articles', 'draft', 361, '2026-06-27 18:45:07', '2026-06-27 18:45:07');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-80a8-73fa-ad9e-30557ace8490', 'pages', '019f0a63-823f-7d92-94b7-223065cae0d8', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Adam Ministrator', 'articles', 'draft', 362, '2026-06-27 18:45:07', '2026-06-27 18:45:07');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-811e-7863-bee3-31d130b66430', 'pages', '019f0a63-823f-7d92-94b7-223065cae0d8', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Adam Ministrator', 'articles', 'draft', 363, '2026-06-27 18:45:07', '2026-06-27 18:45:07');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-8184-76a6-979c-4683b7807a4f', 'pages', '019f0a63-823f-7d92-94b7-223065cae0d8', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Adam Ministrator', 'articles', 'draft', 364, '2026-06-27 18:45:07', '2026-06-27 18:45:07');
INSERT INTO public.re_references VALUES ('contacts', '3', 'articles', '019f0a63-7f13-76a6-9820-09063579be68', 'en', '{"locale": "en"}', 'Domain-Driven Design: Aggregates & Invariants', 'author', 'live', 60, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('categories', '8', 'articles', '019f0a63-7f13-76a6-9820-09063579be68', 'en', '{"locale": "en"}', 'Domain-Driven Design: Aggregates & Invariants', 'categories', 'live', 61, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '39', 'articles', '019f0a63-7f13-76a6-9820-09063579be68', 'en', '{"locale": "en"}', 'Domain-Driven Design: Aggregates & Invariants', 'tags', 'live', 62, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '40', 'articles', '019f0a63-7f13-76a6-9820-09063579be68', 'en', '{"locale": "en"}', 'Domain-Driven Design: Aggregates & Invariants', 'tags', 'live', 63, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('users', '3', 'articles', '019f0a63-7f13-76a6-9820-09063579be68', 'en', '{"locale": "en"}', 'Domain-Driven Design: Aggregates & Invariants', 'settings.author', 'live', 64, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('contacts', '3', 'articles', '019f0a63-7f13-76a6-9820-09063579be68', 'en', '{"locale": "en"}', 'Domain-Driven Design: Aggregates & Invariants', 'author', 'draft', 65, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('categories', '8', 'articles', '019f0a63-7f13-76a6-9820-09063579be68', 'en', '{"locale": "en"}', 'Domain-Driven Design: Aggregates & Invariants', 'categories', 'draft', 66, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '39', 'articles', '019f0a63-7f13-76a6-9820-09063579be68', 'en', '{"locale": "en"}', 'Domain-Driven Design: Aggregates & Invariants', 'tags', 'draft', 67, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '40', 'articles', '019f0a63-7f13-76a6-9820-09063579be68', 'en', '{"locale": "en"}', 'Domain-Driven Design: Aggregates & Invariants', 'tags', 'draft', 68, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('users', '3', 'articles', '019f0a63-7f13-76a6-9820-09063579be68', 'en', '{"locale": "en"}', 'Domain-Driven Design: Aggregates & Invariants', 'settings.author', 'draft', 69, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-81dc-7e9b-9d96-64555bce8199', 'pages', '019f0a63-823f-7d92-94b7-223065cae0d8', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Adam Ministrator', 'articles', 'draft', 365, '2026-06-27 18:45:07', '2026-06-27 18:45:07');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-7da5-7277-98ce-4c75280acfbf', 'pages', '019f0a63-823f-7d92-94b7-223065cae0d8', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Adam Ministrator', 'articles', 'live', 366, '2026-06-27 18:45:07', '2026-06-27 18:45:07');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-7eec-7e3e-922e-19b253d0ba27', 'pages', '019f0a63-823f-7d92-94b7-223065cae0d8', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Adam Ministrator', 'articles', 'live', 367, '2026-06-27 18:45:07', '2026-06-27 18:45:07');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-7f3b-7053-816a-4e409ce7fff1', 'pages', '019f0a63-823f-7d92-94b7-223065cae0d8', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Adam Ministrator', 'articles', 'live', 368, '2026-06-27 18:45:07', '2026-06-27 18:45:07');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-7f89-7c70-83fa-c4d99f423e05', 'pages', '019f0a63-823f-7d92-94b7-223065cae0d8', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Adam Ministrator', 'articles', 'live', 369, '2026-06-27 18:45:07', '2026-06-27 18:45:07');
INSERT INTO public.re_references VALUES ('contacts', '4', 'articles', '019f0a63-7f3b-7053-816a-4e409ce7fff1', 'en', '{"locale": "en"}', 'Value Objects in Domain-Driven Design', 'author', 'live', 76, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('categories', '8', 'articles', '019f0a63-7f3b-7053-816a-4e409ce7fff1', 'en', '{"locale": "en"}', 'Value Objects in Domain-Driven Design', 'categories', 'live', 77, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '39', 'articles', '019f0a63-7f3b-7053-816a-4e409ce7fff1', 'en', '{"locale": "en"}', 'Value Objects in Domain-Driven Design', 'tags', 'live', 78, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '42', 'articles', '019f0a63-7f3b-7053-816a-4e409ce7fff1', 'en', '{"locale": "en"}', 'Value Objects in Domain-Driven Design', 'tags', 'live', 79, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '43', 'articles', '019f0a63-7f3b-7053-816a-4e409ce7fff1', 'en', '{"locale": "en"}', 'Value Objects in Domain-Driven Design', 'tags', 'live', 80, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('users', '4', 'articles', '019f0a63-7f3b-7053-816a-4e409ce7fff1', 'en', '{"locale": "en"}', 'Value Objects in Domain-Driven Design', 'settings.author', 'live', 81, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('contacts', '4', 'articles', '019f0a63-7f3b-7053-816a-4e409ce7fff1', 'en', '{"locale": "en"}', 'Value Objects in Domain-Driven Design', 'author', 'draft', 82, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('categories', '8', 'articles', '019f0a63-7f3b-7053-816a-4e409ce7fff1', 'en', '{"locale": "en"}', 'Value Objects in Domain-Driven Design', 'categories', 'draft', 83, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '39', 'articles', '019f0a63-7f3b-7053-816a-4e409ce7fff1', 'en', '{"locale": "en"}', 'Value Objects in Domain-Driven Design', 'tags', 'draft', 84, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '42', 'articles', '019f0a63-7f3b-7053-816a-4e409ce7fff1', 'en', '{"locale": "en"}', 'Value Objects in Domain-Driven Design', 'tags', 'draft', 85, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '43', 'articles', '019f0a63-7f3b-7053-816a-4e409ce7fff1', 'en', '{"locale": "en"}', 'Value Objects in Domain-Driven Design', 'tags', 'draft', 86, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('users', '4', 'articles', '019f0a63-7f3b-7053-816a-4e409ce7fff1', 'en', '{"locale": "en"}', 'Value Objects in Domain-Driven Design', 'settings.author', 'draft', 87, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-7fe7-7f84-9b23-0603fcc7155e', 'pages', '019f0a63-823f-7d92-94b7-223065cae0d8', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Adam Ministrator', 'articles', 'live', 370, '2026-06-27 18:45:07', '2026-06-27 18:45:07');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-803d-758c-a68a-55f5ee38d8b5', 'pages', '019f0a63-823f-7d92-94b7-223065cae0d8', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Adam Ministrator', 'articles', 'live', 371, '2026-06-27 18:45:07', '2026-06-27 18:45:07');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-80a8-73fa-ad9e-30557ace8490', 'pages', '019f0a63-823f-7d92-94b7-223065cae0d8', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Adam Ministrator', 'articles', 'live', 372, '2026-06-27 18:45:07', '2026-06-27 18:45:07');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-811e-7863-bee3-31d130b66430', 'pages', '019f0a63-823f-7d92-94b7-223065cae0d8', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Adam Ministrator', 'articles', 'live', 373, '2026-06-27 18:45:07', '2026-06-27 18:45:07');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-8184-76a6-979c-4683b7807a4f', 'pages', '019f0a63-823f-7d92-94b7-223065cae0d8', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Adam Ministrator', 'articles', 'live', 374, '2026-06-27 18:45:07', '2026-06-27 18:45:07');
INSERT INTO public.re_references VALUES ('contacts', '3', 'articles', '019f0a63-7f62-72e1-8f42-8c89ac4ed8c8', 'en', '{"locale": "en"}', 'CQRS: Command Query Responsibility Segregation', 'author', 'live', 94, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('categories', '9', 'articles', '019f0a63-7f62-72e1-8f42-8c89ac4ed8c8', 'en', '{"locale": "en"}', 'CQRS: Command Query Responsibility Segregation', 'categories', 'live', 95, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '36', 'articles', '019f0a63-7f62-72e1-8f42-8c89ac4ed8c8', 'en', '{"locale": "en"}', 'CQRS: Command Query Responsibility Segregation', 'tags', 'live', 96, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '43', 'articles', '019f0a63-7f62-72e1-8f42-8c89ac4ed8c8', 'en', '{"locale": "en"}', 'CQRS: Command Query Responsibility Segregation', 'tags', 'live', 97, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '32', 'articles', '019f0a63-7f62-72e1-8f42-8c89ac4ed8c8', 'en', '{"locale": "en"}', 'CQRS: Command Query Responsibility Segregation', 'tags', 'live', 98, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('users', '3', 'articles', '019f0a63-7f62-72e1-8f42-8c89ac4ed8c8', 'en', '{"locale": "en"}', 'CQRS: Command Query Responsibility Segregation', 'settings.author', 'live', 99, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('contacts', '3', 'articles', '019f0a63-7f62-72e1-8f42-8c89ac4ed8c8', 'en', '{"locale": "en"}', 'CQRS: Command Query Responsibility Segregation', 'author', 'draft', 100, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('categories', '9', 'articles', '019f0a63-7f62-72e1-8f42-8c89ac4ed8c8', 'en', '{"locale": "en"}', 'CQRS: Command Query Responsibility Segregation', 'categories', 'draft', 101, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '36', 'articles', '019f0a63-7f62-72e1-8f42-8c89ac4ed8c8', 'en', '{"locale": "en"}', 'CQRS: Command Query Responsibility Segregation', 'tags', 'draft', 102, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '43', 'articles', '019f0a63-7f62-72e1-8f42-8c89ac4ed8c8', 'en', '{"locale": "en"}', 'CQRS: Command Query Responsibility Segregation', 'tags', 'draft', 103, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '32', 'articles', '019f0a63-7f62-72e1-8f42-8c89ac4ed8c8', 'en', '{"locale": "en"}', 'CQRS: Command Query Responsibility Segregation', 'tags', 'draft', 104, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('users', '3', 'articles', '019f0a63-7f62-72e1-8f42-8c89ac4ed8c8', 'en', '{"locale": "en"}', 'CQRS: Command Query Responsibility Segregation', 'settings.author', 'draft', 105, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-81dc-7e9b-9d96-64555bce8199', 'pages', '019f0a63-823f-7d92-94b7-223065cae0d8', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Adam Ministrator', 'articles', 'live', 375, '2026-06-27 18:45:07', '2026-06-27 18:45:07');
INSERT INTO public.re_references VALUES ('contacts', '4', 'articles', '019f0a63-7f89-7c70-83fa-c4d99f423e05', 'en', '{"locale": "en"}', 'Event Sourcing: Storing State as a Sequence of Events', 'author', 'live', 112, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('categories', '10', 'articles', '019f0a63-7f89-7c70-83fa-c4d99f423e05', 'en', '{"locale": "en"}', 'Event Sourcing: Storing State as a Sequence of Events', 'categories', 'live', 113, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '32', 'articles', '019f0a63-7f89-7c70-83fa-c4d99f423e05', 'en', '{"locale": "en"}', 'Event Sourcing: Storing State as a Sequence of Events', 'tags', 'live', 114, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '31', 'articles', '019f0a63-7f89-7c70-83fa-c4d99f423e05', 'en', '{"locale": "en"}', 'Event Sourcing: Storing State as a Sequence of Events', 'tags', 'live', 115, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '36', 'articles', '019f0a63-7f89-7c70-83fa-c4d99f423e05', 'en', '{"locale": "en"}', 'Event Sourcing: Storing State as a Sequence of Events', 'tags', 'live', 116, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('users', '4', 'articles', '019f0a63-7f89-7c70-83fa-c4d99f423e05', 'en', '{"locale": "en"}', 'Event Sourcing: Storing State as a Sequence of Events', 'settings.author', 'live', 117, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('contacts', '4', 'articles', '019f0a63-7f89-7c70-83fa-c4d99f423e05', 'en', '{"locale": "en"}', 'Event Sourcing: Storing State as a Sequence of Events', 'author', 'draft', 118, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('categories', '10', 'articles', '019f0a63-7f89-7c70-83fa-c4d99f423e05', 'en', '{"locale": "en"}', 'Event Sourcing: Storing State as a Sequence of Events', 'categories', 'draft', 119, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '32', 'articles', '019f0a63-7f89-7c70-83fa-c4d99f423e05', 'en', '{"locale": "en"}', 'Event Sourcing: Storing State as a Sequence of Events', 'tags', 'draft', 120, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '31', 'articles', '019f0a63-7f89-7c70-83fa-c4d99f423e05', 'en', '{"locale": "en"}', 'Event Sourcing: Storing State as a Sequence of Events', 'tags', 'draft', 121, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '36', 'articles', '019f0a63-7f89-7c70-83fa-c4d99f423e05', 'en', '{"locale": "en"}', 'Event Sourcing: Storing State as a Sequence of Events', 'tags', 'draft', 122, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('users', '4', 'articles', '019f0a63-7f89-7c70-83fa-c4d99f423e05', 'en', '{"locale": "en"}', 'Event Sourcing: Storing State as a Sequence of Events', 'settings.author', 'draft', 123, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('contacts', '3', 'articles', '019f0a63-7fba-7c70-b040-3e7e9ce94909', 'en', '{"locale": "en"}', 'Microservices Architecture: Promises & Pitfalls', 'author', 'live', 129, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('categories', '9', 'articles', '019f0a63-7fba-7c70-b040-3e7e9ce94909', 'en', '{"locale": "en"}', 'Microservices Architecture: Promises & Pitfalls', 'categories', 'live', 130, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '33', 'articles', '019f0a63-7fba-7c70-b040-3e7e9ce94909', 'en', '{"locale": "en"}', 'Microservices Architecture: Promises & Pitfalls', 'tags', 'live', 131, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '38', 'articles', '019f0a63-7fba-7c70-b040-3e7e9ce94909', 'en', '{"locale": "en"}', 'Microservices Architecture: Promises & Pitfalls', 'tags', 'live', 132, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('users', '3', 'articles', '019f0a63-7fba-7c70-b040-3e7e9ce94909', 'en', '{"locale": "en"}', 'Microservices Architecture: Promises & Pitfalls', 'settings.author', 'live', 133, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('contacts', '3', 'articles', '019f0a63-7fba-7c70-b040-3e7e9ce94909', 'en', '{"locale": "en"}', 'Microservices Architecture: Promises & Pitfalls', 'author', 'draft', 134, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('categories', '9', 'articles', '019f0a63-7fba-7c70-b040-3e7e9ce94909', 'en', '{"locale": "en"}', 'Microservices Architecture: Promises & Pitfalls', 'categories', 'draft', 135, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '33', 'articles', '019f0a63-7fba-7c70-b040-3e7e9ce94909', 'en', '{"locale": "en"}', 'Microservices Architecture: Promises & Pitfalls', 'tags', 'draft', 136, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '38', 'articles', '019f0a63-7fba-7c70-b040-3e7e9ce94909', 'en', '{"locale": "en"}', 'Microservices Architecture: Promises & Pitfalls', 'tags', 'draft', 137, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('users', '3', 'articles', '019f0a63-7fba-7c70-b040-3e7e9ce94909', 'en', '{"locale": "en"}', 'Microservices Architecture: Promises & Pitfalls', 'settings.author', 'draft', 138, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('contacts', '4', 'articles', '019f0a63-7fe7-7f84-9b23-0603fcc7155e', 'en', '{"locale": "en"}', 'Hexagonal Architecture: Ports and Adapters', 'author', 'live', 145, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('categories', '9', 'articles', '019f0a63-7fe7-7f84-9b23-0603fcc7155e', 'en', '{"locale": "en"}', 'Hexagonal Architecture: Ports and Adapters', 'categories', 'live', 146, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '44', 'articles', '019f0a63-7fe7-7f84-9b23-0603fcc7155e', 'en', '{"locale": "en"}', 'Hexagonal Architecture: Ports and Adapters', 'tags', 'live', 147, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '45', 'articles', '019f0a63-7fe7-7f84-9b23-0603fcc7155e', 'en', '{"locale": "en"}', 'Hexagonal Architecture: Ports and Adapters', 'tags', 'live', 148, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '43', 'articles', '019f0a63-7fe7-7f84-9b23-0603fcc7155e', 'en', '{"locale": "en"}', 'Hexagonal Architecture: Ports and Adapters', 'tags', 'live', 149, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('users', '4', 'articles', '019f0a63-7fe7-7f84-9b23-0603fcc7155e', 'en', '{"locale": "en"}', 'Hexagonal Architecture: Ports and Adapters', 'settings.author', 'live', 150, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('contacts', '4', 'articles', '019f0a63-7fe7-7f84-9b23-0603fcc7155e', 'en', '{"locale": "en"}', 'Hexagonal Architecture: Ports and Adapters', 'author', 'draft', 151, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('categories', '9', 'articles', '019f0a63-7fe7-7f84-9b23-0603fcc7155e', 'en', '{"locale": "en"}', 'Hexagonal Architecture: Ports and Adapters', 'categories', 'draft', 152, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '44', 'articles', '019f0a63-7fe7-7f84-9b23-0603fcc7155e', 'en', '{"locale": "en"}', 'Hexagonal Architecture: Ports and Adapters', 'tags', 'draft', 153, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '45', 'articles', '019f0a63-7fe7-7f84-9b23-0603fcc7155e', 'en', '{"locale": "en"}', 'Hexagonal Architecture: Ports and Adapters', 'tags', 'draft', 154, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '43', 'articles', '019f0a63-7fe7-7f84-9b23-0603fcc7155e', 'en', '{"locale": "en"}', 'Hexagonal Architecture: Ports and Adapters', 'tags', 'draft', 155, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('users', '4', 'articles', '019f0a63-7fe7-7f84-9b23-0603fcc7155e', 'en', '{"locale": "en"}', 'Hexagonal Architecture: Ports and Adapters', 'settings.author', 'draft', 156, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('contacts', '3', 'articles', '019f0a63-8011-7c5b-9a45-6195911b5536', 'en', '{"locale": "en"}', 'Clean Architecture: The Dependency Rule', 'author', 'live', 163, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('categories', '9', 'articles', '019f0a63-8011-7c5b-9a45-6195911b5536', 'en', '{"locale": "en"}', 'Clean Architecture: The Dependency Rule', 'categories', 'live', 164, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '45', 'articles', '019f0a63-8011-7c5b-9a45-6195911b5536', 'en', '{"locale": "en"}', 'Clean Architecture: The Dependency Rule', 'tags', 'live', 165, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '43', 'articles', '019f0a63-8011-7c5b-9a45-6195911b5536', 'en', '{"locale": "en"}', 'Clean Architecture: The Dependency Rule', 'tags', 'live', 166, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '39', 'articles', '019f0a63-8011-7c5b-9a45-6195911b5536', 'en', '{"locale": "en"}', 'Clean Architecture: The Dependency Rule', 'tags', 'live', 167, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('users', '3', 'articles', '019f0a63-8011-7c5b-9a45-6195911b5536', 'en', '{"locale": "en"}', 'Clean Architecture: The Dependency Rule', 'settings.author', 'live', 168, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('contacts', '3', 'articles', '019f0a63-8011-7c5b-9a45-6195911b5536', 'en', '{"locale": "en"}', 'Clean Architecture: The Dependency Rule', 'author', 'draft', 169, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('categories', '9', 'articles', '019f0a63-8011-7c5b-9a45-6195911b5536', 'en', '{"locale": "en"}', 'Clean Architecture: The Dependency Rule', 'categories', 'draft', 170, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '45', 'articles', '019f0a63-8011-7c5b-9a45-6195911b5536', 'en', '{"locale": "en"}', 'Clean Architecture: The Dependency Rule', 'tags', 'draft', 171, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '43', 'articles', '019f0a63-8011-7c5b-9a45-6195911b5536', 'en', '{"locale": "en"}', 'Clean Architecture: The Dependency Rule', 'tags', 'draft', 172, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '39', 'articles', '019f0a63-8011-7c5b-9a45-6195911b5536', 'en', '{"locale": "en"}', 'Clean Architecture: The Dependency Rule', 'tags', 'draft', 173, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('users', '3', 'articles', '019f0a63-8011-7c5b-9a45-6195911b5536', 'en', '{"locale": "en"}', 'Clean Architecture: The Dependency Rule', 'settings.author', 'draft', 174, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('contacts', '4', 'articles', '019f0a63-803d-758c-a68a-55f5ee38d8b5', 'en', '{"locale": "en"}', 'Monolith vs Microservices: When to Split', 'author', 'live', 181, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('categories', '9', 'articles', '019f0a63-803d-758c-a68a-55f5ee38d8b5', 'en', '{"locale": "en"}', 'Monolith vs Microservices: When to Split', 'categories', 'live', 182, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '37', 'articles', '019f0a63-803d-758c-a68a-55f5ee38d8b5', 'en', '{"locale": "en"}', 'Monolith vs Microservices: When to Split', 'tags', 'live', 183, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '33', 'articles', '019f0a63-803d-758c-a68a-55f5ee38d8b5', 'en', '{"locale": "en"}', 'Monolith vs Microservices: When to Split', 'tags', 'live', 184, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '38', 'articles', '019f0a63-803d-758c-a68a-55f5ee38d8b5', 'en', '{"locale": "en"}', 'Monolith vs Microservices: When to Split', 'tags', 'live', 185, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('users', '4', 'articles', '019f0a63-803d-758c-a68a-55f5ee38d8b5', 'en', '{"locale": "en"}', 'Monolith vs Microservices: When to Split', 'settings.author', 'live', 186, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('contacts', '4', 'articles', '019f0a63-803d-758c-a68a-55f5ee38d8b5', 'en', '{"locale": "en"}', 'Monolith vs Microservices: When to Split', 'author', 'draft', 187, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('categories', '9', 'articles', '019f0a63-803d-758c-a68a-55f5ee38d8b5', 'en', '{"locale": "en"}', 'Monolith vs Microservices: When to Split', 'categories', 'draft', 188, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '37', 'articles', '019f0a63-803d-758c-a68a-55f5ee38d8b5', 'en', '{"locale": "en"}', 'Monolith vs Microservices: When to Split', 'tags', 'draft', 189, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '33', 'articles', '019f0a63-803d-758c-a68a-55f5ee38d8b5', 'en', '{"locale": "en"}', 'Monolith vs Microservices: When to Split', 'tags', 'draft', 190, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '38', 'articles', '019f0a63-803d-758c-a68a-55f5ee38d8b5', 'en', '{"locale": "en"}', 'Monolith vs Microservices: When to Split', 'tags', 'draft', 191, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('users', '4', 'articles', '019f0a63-803d-758c-a68a-55f5ee38d8b5', 'en', '{"locale": "en"}', 'Monolith vs Microservices: When to Split', 'settings.author', 'draft', 192, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('contacts', '3', 'articles', '019f0a63-806b-75d3-9bb4-31d0fdf95812', 'en', '{"locale": "en"}', 'The API Gateway Pattern', 'author', 'live', 198, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('categories', '9', 'articles', '019f0a63-806b-75d3-9bb4-31d0fdf95812', 'en', '{"locale": "en"}', 'The API Gateway Pattern', 'categories', 'live', 199, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '52', 'articles', '019f0a63-806b-75d3-9bb4-31d0fdf95812', 'en', '{"locale": "en"}', 'The API Gateway Pattern', 'tags', 'live', 200, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '33', 'articles', '019f0a63-806b-75d3-9bb4-31d0fdf95812', 'en', '{"locale": "en"}', 'The API Gateway Pattern', 'tags', 'live', 201, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('users', '3', 'articles', '019f0a63-806b-75d3-9bb4-31d0fdf95812', 'en', '{"locale": "en"}', 'The API Gateway Pattern', 'settings.author', 'live', 202, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('contacts', '3', 'articles', '019f0a63-806b-75d3-9bb4-31d0fdf95812', 'en', '{"locale": "en"}', 'The API Gateway Pattern', 'author', 'draft', 203, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('categories', '9', 'articles', '019f0a63-806b-75d3-9bb4-31d0fdf95812', 'en', '{"locale": "en"}', 'The API Gateway Pattern', 'categories', 'draft', 204, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '52', 'articles', '019f0a63-806b-75d3-9bb4-31d0fdf95812', 'en', '{"locale": "en"}', 'The API Gateway Pattern', 'tags', 'draft', 205, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('tags', '33', 'articles', '019f0a63-806b-75d3-9bb4-31d0fdf95812', 'en', '{"locale": "en"}', 'The API Gateway Pattern', 'tags', 'draft', 206, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('users', '3', 'articles', '019f0a63-806b-75d3-9bb4-31d0fdf95812', 'en', '{"locale": "en"}', 'The API Gateway Pattern', 'settings.author', 'draft', 207, '2026-06-27 18:42:00', '2026-06-27 18:42:00');
INSERT INTO public.re_references VALUES ('contacts', '4', 'articles', '019f0a63-80a8-73fa-ad9e-30557ace8490', 'en', '{"locale": "en"}', 'The Saga Pattern: Distributed Transactions Without 2PC', 'author', 'live', 214, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('categories', '10', 'articles', '019f0a63-80a8-73fa-ad9e-30557ace8490', 'en', '{"locale": "en"}', 'The Saga Pattern: Distributed Transactions Without 2PC', 'categories', 'live', 215, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('tags', '34', 'articles', '019f0a63-80a8-73fa-ad9e-30557ace8490', 'en', '{"locale": "en"}', 'The Saga Pattern: Distributed Transactions Without 2PC', 'tags', 'live', 216, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-7ec1-797f-9a50-9fd0ee001098', 'pages', '019f0a63-826d-77e6-adcf-e37b657311ed', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Jane Kowalski', 'articles', 'draft', 452, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-7f13-76a6-9820-09063579be68', 'pages', '019f0a63-826d-77e6-adcf-e37b657311ed', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Jane Kowalski', 'articles', 'draft', 453, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('tags', '33', 'articles', '019f0a63-80a8-73fa-ad9e-30557ace8490', 'en', '{"locale": "en"}', 'The Saga Pattern: Distributed Transactions Without 2PC', 'tags', 'live', 217, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('tags', '38', 'articles', '019f0a63-80a8-73fa-ad9e-30557ace8490', 'en', '{"locale": "en"}', 'The Saga Pattern: Distributed Transactions Without 2PC', 'tags', 'live', 218, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('users', '4', 'articles', '019f0a63-80a8-73fa-ad9e-30557ace8490', 'en', '{"locale": "en"}', 'The Saga Pattern: Distributed Transactions Without 2PC', 'settings.author', 'live', 219, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('contacts', '4', 'articles', '019f0a63-80a8-73fa-ad9e-30557ace8490', 'en', '{"locale": "en"}', 'The Saga Pattern: Distributed Transactions Without 2PC', 'author', 'draft', 220, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('categories', '10', 'articles', '019f0a63-80a8-73fa-ad9e-30557ace8490', 'en', '{"locale": "en"}', 'The Saga Pattern: Distributed Transactions Without 2PC', 'categories', 'draft', 221, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('tags', '34', 'articles', '019f0a63-80a8-73fa-ad9e-30557ace8490', 'en', '{"locale": "en"}', 'The Saga Pattern: Distributed Transactions Without 2PC', 'tags', 'draft', 222, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('tags', '33', 'articles', '019f0a63-80a8-73fa-ad9e-30557ace8490', 'en', '{"locale": "en"}', 'The Saga Pattern: Distributed Transactions Without 2PC', 'tags', 'draft', 223, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('tags', '38', 'articles', '019f0a63-80a8-73fa-ad9e-30557ace8490', 'en', '{"locale": "en"}', 'The Saga Pattern: Distributed Transactions Without 2PC', 'tags', 'draft', 224, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('users', '4', 'articles', '019f0a63-80a8-73fa-ad9e-30557ace8490', 'en', '{"locale": "en"}', 'The Saga Pattern: Distributed Transactions Without 2PC', 'settings.author', 'draft', 225, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('contacts', '3', 'articles', '019f0a63-80e4-7806-83b8-8991df317fa6', 'en', '{"locale": "en"}', 'The Circuit Breaker Pattern', 'author', 'live', 232, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('categories', '10', 'articles', '019f0a63-80e4-7806-83b8-8991df317fa6', 'en', '{"locale": "en"}', 'The Circuit Breaker Pattern', 'categories', 'live', 233, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('tags', '46', 'articles', '019f0a63-80e4-7806-83b8-8991df317fa6', 'en', '{"locale": "en"}', 'The Circuit Breaker Pattern', 'tags', 'live', 234, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('tags', '33', 'articles', '019f0a63-80e4-7806-83b8-8991df317fa6', 'en', '{"locale": "en"}', 'The Circuit Breaker Pattern', 'tags', 'live', 235, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('tags', '38', 'articles', '019f0a63-80e4-7806-83b8-8991df317fa6', 'en', '{"locale": "en"}', 'The Circuit Breaker Pattern', 'tags', 'live', 236, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('users', '3', 'articles', '019f0a63-80e4-7806-83b8-8991df317fa6', 'en', '{"locale": "en"}', 'The Circuit Breaker Pattern', 'settings.author', 'live', 237, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('contacts', '3', 'articles', '019f0a63-80e4-7806-83b8-8991df317fa6', 'en', '{"locale": "en"}', 'The Circuit Breaker Pattern', 'author', 'draft', 238, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('categories', '10', 'articles', '019f0a63-80e4-7806-83b8-8991df317fa6', 'en', '{"locale": "en"}', 'The Circuit Breaker Pattern', 'categories', 'draft', 239, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('tags', '46', 'articles', '019f0a63-80e4-7806-83b8-8991df317fa6', 'en', '{"locale": "en"}', 'The Circuit Breaker Pattern', 'tags', 'draft', 240, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('tags', '33', 'articles', '019f0a63-80e4-7806-83b8-8991df317fa6', 'en', '{"locale": "en"}', 'The Circuit Breaker Pattern', 'tags', 'draft', 241, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('tags', '38', 'articles', '019f0a63-80e4-7806-83b8-8991df317fa6', 'en', '{"locale": "en"}', 'The Circuit Breaker Pattern', 'tags', 'draft', 242, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('users', '3', 'articles', '019f0a63-80e4-7806-83b8-8991df317fa6', 'en', '{"locale": "en"}', 'The Circuit Breaker Pattern', 'settings.author', 'draft', 243, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('contacts', '4', 'articles', '019f0a63-811e-7863-bee3-31d130b66430', 'en', '{"locale": "en"}', 'The Outbox Pattern for Reliable Messaging', 'author', 'live', 250, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('categories', '10', 'articles', '019f0a63-811e-7863-bee3-31d130b66430', 'en', '{"locale": "en"}', 'The Outbox Pattern for Reliable Messaging', 'categories', 'live', 251, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('tags', '35', 'articles', '019f0a63-811e-7863-bee3-31d130b66430', 'en', '{"locale": "en"}', 'The Outbox Pattern for Reliable Messaging', 'tags', 'live', 252, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('tags', '31', 'articles', '019f0a63-811e-7863-bee3-31d130b66430', 'en', '{"locale": "en"}', 'The Outbox Pattern for Reliable Messaging', 'tags', 'live', 253, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('tags', '38', 'articles', '019f0a63-811e-7863-bee3-31d130b66430', 'en', '{"locale": "en"}', 'The Outbox Pattern for Reliable Messaging', 'tags', 'live', 254, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('users', '4', 'articles', '019f0a63-811e-7863-bee3-31d130b66430', 'en', '{"locale": "en"}', 'The Outbox Pattern for Reliable Messaging', 'settings.author', 'live', 255, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('contacts', '4', 'articles', '019f0a63-811e-7863-bee3-31d130b66430', 'en', '{"locale": "en"}', 'The Outbox Pattern for Reliable Messaging', 'author', 'draft', 256, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('categories', '10', 'articles', '019f0a63-811e-7863-bee3-31d130b66430', 'en', '{"locale": "en"}', 'The Outbox Pattern for Reliable Messaging', 'categories', 'draft', 257, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('tags', '35', 'articles', '019f0a63-811e-7863-bee3-31d130b66430', 'en', '{"locale": "en"}', 'The Outbox Pattern for Reliable Messaging', 'tags', 'draft', 258, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('tags', '31', 'articles', '019f0a63-811e-7863-bee3-31d130b66430', 'en', '{"locale": "en"}', 'The Outbox Pattern for Reliable Messaging', 'tags', 'draft', 259, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('tags', '38', 'articles', '019f0a63-811e-7863-bee3-31d130b66430', 'en', '{"locale": "en"}', 'The Outbox Pattern for Reliable Messaging', 'tags', 'draft', 260, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('users', '4', 'articles', '019f0a63-811e-7863-bee3-31d130b66430', 'en', '{"locale": "en"}', 'The Outbox Pattern for Reliable Messaging', 'settings.author', 'draft', 261, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('contacts', '3', 'articles', '019f0a63-8150-7804-9c6f-f6c154f95cd1', 'en', '{"locale": "en"}', 'The Repository Pattern', 'author', 'live', 268, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('categories', '7', 'articles', '019f0a63-8150-7804-9c6f-f6c154f95cd1', 'en', '{"locale": "en"}', 'The Repository Pattern', 'categories', 'live', 269, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('tags', '47', 'articles', '019f0a63-8150-7804-9c6f-f6c154f95cd1', 'en', '{"locale": "en"}', 'The Repository Pattern', 'tags', 'live', 270, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('tags', '43', 'articles', '019f0a63-8150-7804-9c6f-f6c154f95cd1', 'en', '{"locale": "en"}', 'The Repository Pattern', 'tags', 'live', 271, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('tags', '39', 'articles', '019f0a63-8150-7804-9c6f-f6c154f95cd1', 'en', '{"locale": "en"}', 'The Repository Pattern', 'tags', 'live', 272, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('users', '3', 'articles', '019f0a63-8150-7804-9c6f-f6c154f95cd1', 'en', '{"locale": "en"}', 'The Repository Pattern', 'settings.author', 'live', 273, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('contacts', '3', 'articles', '019f0a63-8150-7804-9c6f-f6c154f95cd1', 'en', '{"locale": "en"}', 'The Repository Pattern', 'author', 'draft', 274, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('categories', '7', 'articles', '019f0a63-8150-7804-9c6f-f6c154f95cd1', 'en', '{"locale": "en"}', 'The Repository Pattern', 'categories', 'draft', 275, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('tags', '47', 'articles', '019f0a63-8150-7804-9c6f-f6c154f95cd1', 'en', '{"locale": "en"}', 'The Repository Pattern', 'tags', 'draft', 276, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('tags', '43', 'articles', '019f0a63-8150-7804-9c6f-f6c154f95cd1', 'en', '{"locale": "en"}', 'The Repository Pattern', 'tags', 'draft', 277, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('tags', '39', 'articles', '019f0a63-8150-7804-9c6f-f6c154f95cd1', 'en', '{"locale": "en"}', 'The Repository Pattern', 'tags', 'draft', 278, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('users', '3', 'articles', '019f0a63-8150-7804-9c6f-f6c154f95cd1', 'en', '{"locale": "en"}', 'The Repository Pattern', 'settings.author', 'draft', 279, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('contacts', '4', 'articles', '019f0a63-8184-76a6-979c-4683b7807a4f', 'en', '{"locale": "en"}', 'The Factory Pattern: Centralising Object Creation', 'author', 'live', 285, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('categories', '7', 'articles', '019f0a63-8184-76a6-979c-4683b7807a4f', 'en', '{"locale": "en"}', 'The Factory Pattern: Centralising Object Creation', 'categories', 'live', 286, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('tags', '48', 'articles', '019f0a63-8184-76a6-979c-4683b7807a4f', 'en', '{"locale": "en"}', 'The Factory Pattern: Centralising Object Creation', 'tags', 'live', 287, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('tags', '43', 'articles', '019f0a63-8184-76a6-979c-4683b7807a4f', 'en', '{"locale": "en"}', 'The Factory Pattern: Centralising Object Creation', 'tags', 'live', 288, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('users', '4', 'articles', '019f0a63-8184-76a6-979c-4683b7807a4f', 'en', '{"locale": "en"}', 'The Factory Pattern: Centralising Object Creation', 'settings.author', 'live', 289, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('contacts', '4', 'articles', '019f0a63-8184-76a6-979c-4683b7807a4f', 'en', '{"locale": "en"}', 'The Factory Pattern: Centralising Object Creation', 'author', 'draft', 290, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('categories', '7', 'articles', '019f0a63-8184-76a6-979c-4683b7807a4f', 'en', '{"locale": "en"}', 'The Factory Pattern: Centralising Object Creation', 'categories', 'draft', 291, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('tags', '48', 'articles', '019f0a63-8184-76a6-979c-4683b7807a4f', 'en', '{"locale": "en"}', 'The Factory Pattern: Centralising Object Creation', 'tags', 'draft', 292, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('tags', '43', 'articles', '019f0a63-8184-76a6-979c-4683b7807a4f', 'en', '{"locale": "en"}', 'The Factory Pattern: Centralising Object Creation', 'tags', 'draft', 293, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('users', '4', 'articles', '019f0a63-8184-76a6-979c-4683b7807a4f', 'en', '{"locale": "en"}', 'The Factory Pattern: Centralising Object Creation', 'settings.author', 'draft', 294, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('contacts', '3', 'articles', '019f0a63-81b0-7060-8257-0ddd2bb95a71', 'en', '{"locale": "en"}', 'The Strategy Pattern: Encapsulating Algorithms', 'author', 'live', 300, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('categories', '7', 'articles', '019f0a63-81b0-7060-8257-0ddd2bb95a71', 'en', '{"locale": "en"}', 'The Strategy Pattern: Encapsulating Algorithms', 'categories', 'live', 301, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('tags', '49', 'articles', '019f0a63-81b0-7060-8257-0ddd2bb95a71', 'en', '{"locale": "en"}', 'The Strategy Pattern: Encapsulating Algorithms', 'tags', 'live', 302, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('tags', '43', 'articles', '019f0a63-81b0-7060-8257-0ddd2bb95a71', 'en', '{"locale": "en"}', 'The Strategy Pattern: Encapsulating Algorithms', 'tags', 'live', 303, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('users', '3', 'articles', '019f0a63-81b0-7060-8257-0ddd2bb95a71', 'en', '{"locale": "en"}', 'The Strategy Pattern: Encapsulating Algorithms', 'settings.author', 'live', 304, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('contacts', '3', 'articles', '019f0a63-81b0-7060-8257-0ddd2bb95a71', 'en', '{"locale": "en"}', 'The Strategy Pattern: Encapsulating Algorithms', 'author', 'draft', 305, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('categories', '7', 'articles', '019f0a63-81b0-7060-8257-0ddd2bb95a71', 'en', '{"locale": "en"}', 'The Strategy Pattern: Encapsulating Algorithms', 'categories', 'draft', 306, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('tags', '49', 'articles', '019f0a63-81b0-7060-8257-0ddd2bb95a71', 'en', '{"locale": "en"}', 'The Strategy Pattern: Encapsulating Algorithms', 'tags', 'draft', 307, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('tags', '43', 'articles', '019f0a63-81b0-7060-8257-0ddd2bb95a71', 'en', '{"locale": "en"}', 'The Strategy Pattern: Encapsulating Algorithms', 'tags', 'draft', 308, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('users', '3', 'articles', '019f0a63-81b0-7060-8257-0ddd2bb95a71', 'en', '{"locale": "en"}', 'The Strategy Pattern: Encapsulating Algorithms', 'settings.author', 'draft', 309, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('contacts', '4', 'articles', '019f0a63-81dc-7e9b-9d96-64555bce8199', 'en', '{"locale": "en"}', 'The Observer Pattern and Event-Driven Design', 'author', 'live', 316, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('categories', '7', 'articles', '019f0a63-81dc-7e9b-9d96-64555bce8199', 'en', '{"locale": "en"}', 'The Observer Pattern and Event-Driven Design', 'categories', 'live', 317, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('tags', '50', 'articles', '019f0a63-81dc-7e9b-9d96-64555bce8199', 'en', '{"locale": "en"}', 'The Observer Pattern and Event-Driven Design', 'tags', 'live', 318, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('tags', '31', 'articles', '019f0a63-81dc-7e9b-9d96-64555bce8199', 'en', '{"locale": "en"}', 'The Observer Pattern and Event-Driven Design', 'tags', 'live', 319, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('tags', '43', 'articles', '019f0a63-81dc-7e9b-9d96-64555bce8199', 'en', '{"locale": "en"}', 'The Observer Pattern and Event-Driven Design', 'tags', 'live', 320, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('users', '4', 'articles', '019f0a63-81dc-7e9b-9d96-64555bce8199', 'en', '{"locale": "en"}', 'The Observer Pattern and Event-Driven Design', 'settings.author', 'live', 321, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('contacts', '4', 'articles', '019f0a63-81dc-7e9b-9d96-64555bce8199', 'en', '{"locale": "en"}', 'The Observer Pattern and Event-Driven Design', 'author', 'draft', 322, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('categories', '7', 'articles', '019f0a63-81dc-7e9b-9d96-64555bce8199', 'en', '{"locale": "en"}', 'The Observer Pattern and Event-Driven Design', 'categories', 'draft', 323, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('tags', '50', 'articles', '019f0a63-81dc-7e9b-9d96-64555bce8199', 'en', '{"locale": "en"}', 'The Observer Pattern and Event-Driven Design', 'tags', 'draft', 324, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('tags', '31', 'articles', '019f0a63-81dc-7e9b-9d96-64555bce8199', 'en', '{"locale": "en"}', 'The Observer Pattern and Event-Driven Design', 'tags', 'draft', 325, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('tags', '43', 'articles', '019f0a63-81dc-7e9b-9d96-64555bce8199', 'en', '{"locale": "en"}', 'The Observer Pattern and Event-Driven Design', 'tags', 'draft', 326, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('users', '4', 'articles', '019f0a63-81dc-7e9b-9d96-64555bce8199', 'en', '{"locale": "en"}', 'The Observer Pattern and Event-Driven Design', 'settings.author', 'draft', 327, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('contacts', '3', 'articles', '019f0a63-820c-7902-9100-98c04b1f89bd', 'en', '{"locale": "en"}', 'Dependency Injection and IoC Containers', 'author', 'live', 334, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('categories', '7', 'articles', '019f0a63-820c-7902-9100-98c04b1f89bd', 'en', '{"locale": "en"}', 'Dependency Injection and IoC Containers', 'categories', 'live', 335, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('tags', '51', 'articles', '019f0a63-820c-7902-9100-98c04b1f89bd', 'en', '{"locale": "en"}', 'Dependency Injection and IoC Containers', 'tags', 'live', 336, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('tags', '43', 'articles', '019f0a63-820c-7902-9100-98c04b1f89bd', 'en', '{"locale": "en"}', 'Dependency Injection and IoC Containers', 'tags', 'live', 337, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('tags', '45', 'articles', '019f0a63-820c-7902-9100-98c04b1f89bd', 'en', '{"locale": "en"}', 'Dependency Injection and IoC Containers', 'tags', 'live', 338, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('users', '3', 'articles', '019f0a63-820c-7902-9100-98c04b1f89bd', 'en', '{"locale": "en"}', 'Dependency Injection and IoC Containers', 'settings.author', 'live', 339, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('contacts', '3', 'articles', '019f0a63-820c-7902-9100-98c04b1f89bd', 'en', '{"locale": "en"}', 'Dependency Injection and IoC Containers', 'author', 'draft', 340, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('categories', '7', 'articles', '019f0a63-820c-7902-9100-98c04b1f89bd', 'en', '{"locale": "en"}', 'Dependency Injection and IoC Containers', 'categories', 'draft', 341, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('tags', '51', 'articles', '019f0a63-820c-7902-9100-98c04b1f89bd', 'en', '{"locale": "en"}', 'Dependency Injection and IoC Containers', 'tags', 'draft', 342, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('tags', '43', 'articles', '019f0a63-820c-7902-9100-98c04b1f89bd', 'en', '{"locale": "en"}', 'Dependency Injection and IoC Containers', 'tags', 'draft', 343, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('tags', '45', 'articles', '019f0a63-820c-7902-9100-98c04b1f89bd', 'en', '{"locale": "en"}', 'Dependency Injection and IoC Containers', 'tags', 'draft', 344, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('users', '3', 'articles', '019f0a63-820c-7902-9100-98c04b1f89bd', 'en', '{"locale": "en"}', 'Dependency Injection and IoC Containers', 'settings.author', 'draft', 345, '2026-06-27 18:42:01', '2026-06-27 18:42:01');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-7f62-72e1-8f42-8c89ac4ed8c8', 'pages', '019f0a63-826d-77e6-adcf-e37b657311ed', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Jane Kowalski', 'articles', 'draft', 454, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-7fba-7c70-b040-3e7e9ce94909', 'pages', '019f0a63-826d-77e6-adcf-e37b657311ed', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Jane Kowalski', 'articles', 'draft', 455, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-8011-7c5b-9a45-6195911b5536', 'pages', '019f0a63-826d-77e6-adcf-e37b657311ed', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Jane Kowalski', 'articles', 'draft', 456, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-806b-75d3-9bb4-31d0fdf95812', 'pages', '019f0a63-826d-77e6-adcf-e37b657311ed', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Jane Kowalski', 'articles', 'draft', 457, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-80e4-7806-83b8-8991df317fa6', 'pages', '019f0a63-826d-77e6-adcf-e37b657311ed', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Jane Kowalski', 'articles', 'draft', 458, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-8150-7804-9c6f-f6c154f95cd1', 'pages', '019f0a63-826d-77e6-adcf-e37b657311ed', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Jane Kowalski', 'articles', 'draft', 459, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-81b0-7060-8257-0ddd2bb95a71', 'pages', '019f0a63-826d-77e6-adcf-e37b657311ed', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Jane Kowalski', 'articles', 'draft', 460, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-820c-7902-9100-98c04b1f89bd', 'pages', '019f0a63-826d-77e6-adcf-e37b657311ed', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Jane Kowalski', 'articles', 'draft', 461, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-7ec1-797f-9a50-9fd0ee001098', 'pages', '019f0a63-826d-77e6-adcf-e37b657311ed', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Jane Kowalski', 'articles', 'live', 462, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-7f13-76a6-9820-09063579be68', 'pages', '019f0a63-826d-77e6-adcf-e37b657311ed', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Jane Kowalski', 'articles', 'live', 463, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-7f62-72e1-8f42-8c89ac4ed8c8', 'pages', '019f0a63-826d-77e6-adcf-e37b657311ed', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Jane Kowalski', 'articles', 'live', 464, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-7fba-7c70-b040-3e7e9ce94909', 'pages', '019f0a63-826d-77e6-adcf-e37b657311ed', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Jane Kowalski', 'articles', 'live', 465, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-8011-7c5b-9a45-6195911b5536', 'pages', '019f0a63-826d-77e6-adcf-e37b657311ed', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Jane Kowalski', 'articles', 'live', 466, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-806b-75d3-9bb4-31d0fdf95812', 'pages', '019f0a63-826d-77e6-adcf-e37b657311ed', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Jane Kowalski', 'articles', 'live', 467, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-80e4-7806-83b8-8991df317fa6', 'pages', '019f0a63-826d-77e6-adcf-e37b657311ed', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Jane Kowalski', 'articles', 'live', 468, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-8150-7804-9c6f-f6c154f95cd1', 'pages', '019f0a63-826d-77e6-adcf-e37b657311ed', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Jane Kowalski', 'articles', 'live', 469, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-81b0-7060-8257-0ddd2bb95a71', 'pages', '019f0a63-826d-77e6-adcf-e37b657311ed', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Jane Kowalski', 'articles', 'live', 470, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-820c-7902-9100-98c04b1f89bd', 'pages', '019f0a63-826d-77e6-adcf-e37b657311ed', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Jane Kowalski', 'articles', 'live', 471, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('pages', '019f0a63-823f-7d92-94b7-223065cae0d8', 'pages', '019f0a71-f47f-7c8e-9018-5bfe524ddb81', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Authors', 'authors', 'live', 474, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('pages', '019f0a63-826d-77e6-adcf-e37b657311ed', 'pages', '019f0a71-f47f-7c8e-9018-5bfe524ddb81', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Authors', 'authors', 'live', 475, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('pages', '019f0a63-823f-7d92-94b7-223065cae0d8', 'pages', '019f0a71-f47f-7c8e-9018-5bfe524ddb81', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Authors', 'authors', 'draft', 476, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('pages', '019f0a63-826d-77e6-adcf-e37b657311ed', 'pages', '019f0a71-f47f-7c8e-9018-5bfe524ddb81', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Authors', 'authors', 'draft', 477, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-7da5-7277-98ce-4c75280acfbf', 'pages', '019f0a94-9d57-7cad-b9d7-fb66234cc944', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Distributed Systems Fundamentals', 'articles', 'live', 483, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-7ec1-797f-9a50-9fd0ee001098', 'pages', '019f0a94-9d57-7cad-b9d7-fb66234cc944', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Distributed Systems Fundamentals', 'articles', 'live', 484, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-80e4-7806-83b8-8991df317fa6', 'pages', '019f0a94-9d57-7cad-b9d7-fb66234cc944', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Distributed Systems Fundamentals', 'articles', 'live', 485, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-80a8-73fa-ad9e-30557ace8490', 'pages', '019f0a94-9d57-7cad-b9d7-fb66234cc944', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Distributed Systems Fundamentals', 'articles', 'live', 486, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-811e-7863-bee3-31d130b66430', 'pages', '019f0a94-9d57-7cad-b9d7-fb66234cc944', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Distributed Systems Fundamentals', 'articles', 'live', 487, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-7da5-7277-98ce-4c75280acfbf', 'pages', '019f0a94-9d57-7cad-b9d7-fb66234cc944', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Distributed Systems Fundamentals', 'articles', 'draft', 488, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-7ec1-797f-9a50-9fd0ee001098', 'pages', '019f0a94-9d57-7cad-b9d7-fb66234cc944', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Distributed Systems Fundamentals', 'articles', 'draft', 489, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-80e4-7806-83b8-8991df317fa6', 'pages', '019f0a94-9d57-7cad-b9d7-fb66234cc944', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Distributed Systems Fundamentals', 'articles', 'draft', 490, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-80a8-73fa-ad9e-30557ace8490', 'pages', '019f0a94-9d57-7cad-b9d7-fb66234cc944', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Distributed Systems Fundamentals', 'articles', 'draft', 491, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-811e-7863-bee3-31d130b66430', 'pages', '019f0a94-9d57-7cad-b9d7-fb66234cc944', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Distributed Systems Fundamentals', 'articles', 'draft', 492, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-7eec-7e3e-922e-19b253d0ba27', 'pages', '019f0a94-9d85-74e2-9529-c565160fb66d', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Domain-Driven Design', 'articles', 'live', 499, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-7f13-76a6-9820-09063579be68', 'pages', '019f0a94-9d85-74e2-9529-c565160fb66d', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Domain-Driven Design', 'articles', 'live', 500, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-7f3b-7053-816a-4e409ce7fff1', 'pages', '019f0a94-9d85-74e2-9529-c565160fb66d', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Domain-Driven Design', 'articles', 'live', 501, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-7f62-72e1-8f42-8c89ac4ed8c8', 'pages', '019f0a94-9d85-74e2-9529-c565160fb66d', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Domain-Driven Design', 'articles', 'live', 502, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-7f89-7c70-83fa-c4d99f423e05', 'pages', '019f0a94-9d85-74e2-9529-c565160fb66d', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Domain-Driven Design', 'articles', 'live', 503, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-8150-7804-9c6f-f6c154f95cd1', 'pages', '019f0a94-9d85-74e2-9529-c565160fb66d', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Domain-Driven Design', 'articles', 'live', 504, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-7eec-7e3e-922e-19b253d0ba27', 'pages', '019f0a94-9d85-74e2-9529-c565160fb66d', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Domain-Driven Design', 'articles', 'draft', 505, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-7f13-76a6-9820-09063579be68', 'pages', '019f0a94-9d85-74e2-9529-c565160fb66d', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Domain-Driven Design', 'articles', 'draft', 506, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-7f3b-7053-816a-4e409ce7fff1', 'pages', '019f0a94-9d85-74e2-9529-c565160fb66d', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Domain-Driven Design', 'articles', 'draft', 507, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-7f62-72e1-8f42-8c89ac4ed8c8', 'pages', '019f0a94-9d85-74e2-9529-c565160fb66d', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Domain-Driven Design', 'articles', 'draft', 508, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-7f89-7c70-83fa-c4d99f423e05', 'pages', '019f0a94-9d85-74e2-9529-c565160fb66d', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Domain-Driven Design', 'articles', 'draft', 509, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-8150-7804-9c6f-f6c154f95cd1', 'pages', '019f0a94-9d85-74e2-9529-c565160fb66d', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Domain-Driven Design', 'articles', 'draft', 510, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-7fe7-7f84-9b23-0603fcc7155e', 'pages', '019f0a94-9daf-7dc1-b7cd-8354981cfe04', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Architecture Patterns', 'articles', 'live', 516, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-8011-7c5b-9a45-6195911b5536', 'pages', '019f0a94-9daf-7dc1-b7cd-8354981cfe04', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Architecture Patterns', 'articles', 'live', 517, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-7fba-7c70-b040-3e7e9ce94909', 'pages', '019f0a94-9daf-7dc1-b7cd-8354981cfe04', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Architecture Patterns', 'articles', 'live', 518, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-803d-758c-a68a-55f5ee38d8b5', 'pages', '019f0a94-9daf-7dc1-b7cd-8354981cfe04', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Architecture Patterns', 'articles', 'live', 519, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-806b-75d3-9bb4-31d0fdf95812', 'pages', '019f0a94-9daf-7dc1-b7cd-8354981cfe04', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Architecture Patterns', 'articles', 'live', 520, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-7fe7-7f84-9b23-0603fcc7155e', 'pages', '019f0a94-9daf-7dc1-b7cd-8354981cfe04', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Architecture Patterns', 'articles', 'draft', 521, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-8011-7c5b-9a45-6195911b5536', 'pages', '019f0a94-9daf-7dc1-b7cd-8354981cfe04', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Architecture Patterns', 'articles', 'draft', 522, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-7fba-7c70-b040-3e7e9ce94909', 'pages', '019f0a94-9daf-7dc1-b7cd-8354981cfe04', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Architecture Patterns', 'articles', 'draft', 523, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-803d-758c-a68a-55f5ee38d8b5', 'pages', '019f0a94-9daf-7dc1-b7cd-8354981cfe04', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Architecture Patterns', 'articles', 'draft', 524, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('articles', '019f0a63-806b-75d3-9bb4-31d0fdf95812', 'pages', '019f0a94-9daf-7dc1-b7cd-8354981cfe04', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Architecture Patterns', 'articles', 'draft', 525, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('pages', '019f0a94-9d57-7cad-b9d7-fb66234cc944', 'pages', '019f0a94-9dd7-7c35-935d-5f56d43baf7e', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Learning Paths', 'paths', 'live', 529, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('pages', '019f0a94-9d85-74e2-9529-c565160fb66d', 'pages', '019f0a94-9dd7-7c35-935d-5f56d43baf7e', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Learning Paths', 'paths', 'live', 530, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('pages', '019f0a94-9daf-7dc1-b7cd-8354981cfe04', 'pages', '019f0a94-9dd7-7c35-935d-5f56d43baf7e', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Learning Paths', 'paths', 'live', 531, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('pages', '019f0a94-9d57-7cad-b9d7-fb66234cc944', 'pages', '019f0a94-9dd7-7c35-935d-5f56d43baf7e', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Learning Paths', 'paths', 'draft', 532, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('pages', '019f0a94-9d85-74e2-9529-c565160fb66d', 'pages', '019f0a94-9dd7-7c35-935d-5f56d43baf7e', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Learning Paths', 'paths', 'draft', 533, '2026-06-27 19:35:39', '2026-06-27 19:35:39');
INSERT INTO public.re_references VALUES ('pages', '019f0a94-9daf-7dc1-b7cd-8354981cfe04', 'pages', '019f0a94-9dd7-7c35-935d-5f56d43baf7e', 'en', '{"locale": "en", "webspace": "architecture-hub"}', 'Learning Paths', 'paths', 'draft', 534, '2026-06-27 19:35:39', '2026-06-27 19:35:39');


--
-- Data for Name: se_roles; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.se_roles VALUES ('User', NULL, 'Sulu', false, 2, '2026-06-27 18:41:53', '2026-06-27 18:41:53', NULL, NULL);


--
-- Data for Name: se_access_controls; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: se_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.se_permissions VALUES ('sulu.contact.people', 127, 17, 2);
INSERT INTO public.se_permissions VALUES ('sulu.contact.organizations', 127, 18, 2);
INSERT INTO public.se_permissions VALUES ('sulu.media.collections', 127, 19, 2);
INSERT INTO public.se_permissions VALUES ('sulu.media.system_collections', 127, 20, 2);
INSERT INTO public.se_permissions VALUES ('sulu.settings.categories', 127, 21, 2);
INSERT INTO public.se_permissions VALUES ('sulu.settings.tags', 127, 22, 2);
INSERT INTO public.se_permissions VALUES ('sulu.webspaces.architecture-hub.analytics', 127, 23, 2);
INSERT INTO public.se_permissions VALUES ('sulu.webspaces.architecture-hub', 127, 24, 2);
INSERT INTO public.se_permissions VALUES ('sulu.webspaces.architecture-hub.custom-urls', 127, 25, 2);
INSERT INTO public.se_permissions VALUES ('sulu.activities.activities', 127, 26, 2);
INSERT INTO public.se_permissions VALUES ('sulu.trash.trash', 127, 27, 2);
INSERT INTO public.se_permissions VALUES ('sulu.references.references', 127, 28, 2);
INSERT INTO public.se_permissions VALUES ('sulu.article.articles', 127, 29, 2);
INSERT INTO public.se_permissions VALUES ('sulu.snippet.snippets', 127, 30, 2);
INSERT INTO public.se_permissions VALUES ('sulu.security.roles', 127, 31, 2);
INSERT INTO public.se_permissions VALUES ('sulu.security.users', 127, 32, 2);


--
-- Data for Name: se_role_settings; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: se_user_roles; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.se_user_roles VALUES ('["en"]', 2, 2, 2);


--
-- Data for Name: se_user_settings; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: se_user_two_factors; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: sn_snippets; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: sn_snippet_area; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: sn_snippet_dimension_contents; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: sn_snippet_dimension_content_excerpt_categories; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: sn_snippet_dimension_content_excerpt_tags; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: tr_trash_items; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: tr_trash_item_translations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: we_analytics; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: we_domains; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: we_analytics_domains; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Name: ac_activities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ac_activities_id_seq', 152, true);


--
-- Name: ar_article_dimension_content_additional_webspaces_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ar_article_dimension_content_additional_webspaces_id_seq', 1, false);


--
-- Name: ar_article_dimension_contents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ar_article_dimension_contents_id_seq', 120, true);


--
-- Name: ca_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ca_categories_id_seq', 10, true);


--
-- Name: ca_category_translation_medias_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ca_category_translation_medias_id_seq', 1, false);


--
-- Name: ca_category_translations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ca_category_translations_id_seq', 10, true);


--
-- Name: ca_keywords_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ca_keywords_id_seq', 1, false);


--
-- Name: co_account_addresses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.co_account_addresses_id_seq', 1, false);


--
-- Name: co_account_contacts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.co_account_contacts_id_seq', 1, false);


--
-- Name: co_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.co_accounts_id_seq', 1, false);


--
-- Name: co_address_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.co_address_types_id_seq', 1, false);


--
-- Name: co_addresses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.co_addresses_id_seq', 1, false);


--
-- Name: co_bank_account_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.co_bank_account_id_seq', 1, false);


--
-- Name: co_contact_addresses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.co_contact_addresses_id_seq', 1, false);


--
-- Name: co_contact_locales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.co_contact_locales_id_seq', 1, false);


--
-- Name: co_contact_titles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.co_contact_titles_id_seq', 1, false);


--
-- Name: co_contacts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.co_contacts_id_seq', 4, true);


--
-- Name: co_email_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.co_email_types_id_seq', 1, false);


--
-- Name: co_emails_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.co_emails_id_seq', 1, false);


--
-- Name: co_fax_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.co_fax_types_id_seq', 1, false);


--
-- Name: co_faxes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.co_faxes_id_seq', 1, false);


--
-- Name: co_notes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.co_notes_id_seq', 1, false);


--
-- Name: co_phone_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.co_phone_types_id_seq', 1, false);


--
-- Name: co_phones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.co_phones_id_seq', 1, false);


--
-- Name: co_positions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.co_positions_id_seq', 1, false);


--
-- Name: co_social_media_profile_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.co_social_media_profile_types_id_seq', 1, false);


--
-- Name: co_social_media_profiles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.co_social_media_profiles_id_seq', 1, false);


--
-- Name: co_url_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.co_url_types_id_seq', 1, false);


--
-- Name: co_urls_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.co_urls_id_seq', 1, false);


--
-- Name: me_collection_meta_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.me_collection_meta_id_seq', 22, true);


--
-- Name: me_collection_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.me_collection_types_id_seq', 1, false);


--
-- Name: me_collections_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.me_collections_id_seq', 12, true);


--
-- Name: me_file_version_meta_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.me_file_version_meta_id_seq', 1, false);


--
-- Name: me_file_versions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.me_file_versions_id_seq', 1, false);


--
-- Name: me_files_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.me_files_id_seq', 1, false);


--
-- Name: me_media_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.me_media_id_seq', 1, false);


--
-- Name: pa_page_dimension_content_navigation_contexts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pa_page_dimension_content_navigation_contexts_id_seq', 3, true);


--
-- Name: pa_page_dimension_contents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pa_page_dimension_contents_id_seq', 64, true);


--
-- Name: pr_preview_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pr_preview_links_id_seq', 1, false);


--
-- Name: re_references_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.re_references_id_seq', 534, true);


--
-- Name: ro_routes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ro_routes_id_seq', 29, true);


--
-- Name: se_access_controls_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.se_access_controls_id_seq', 1, false);


--
-- Name: se_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.se_permissions_id_seq', 32, true);


--
-- Name: se_role_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.se_role_settings_id_seq', 1, false);


--
-- Name: se_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.se_roles_id_seq', 2, true);


--
-- Name: se_user_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.se_user_roles_id_seq', 2, true);


--
-- Name: se_user_two_factors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.se_user_two_factors_id_seq', 1, false);


--
-- Name: se_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.se_users_id_seq', 2, true);


--
-- Name: sn_snippet_dimension_contents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sn_snippet_dimension_contents_id_seq', 1, false);


--
-- Name: ta_tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ta_tags_id_seq', 52, true);


--
-- Name: tr_trash_item_translations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tr_trash_item_translations_id_seq', 1, false);


--
-- Name: tr_trash_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tr_trash_items_id_seq', 1, false);


--
-- Name: we_analytics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.we_analytics_id_seq', 1, false);


--
-- Name: we_domains_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.we_domains_id_seq', 1, false);


--
-- PostgreSQL database dump complete
--

\unrestrict G0vmWqXIGidXA9bHOroSXrSpnp57sIBEDCKMZD74CW2vGmTl55rshjhGJOS6ixb



SET session_replication_role = 'origin';
